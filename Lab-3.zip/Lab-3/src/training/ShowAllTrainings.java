package training;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Training;
import service.Service;
import service.ServiceImpl;

@WebServlet("/ShowAllTrainings")
public class ShowAllTrainings extends HttpServlet {
	Service service = new ServiceImpl();
	List<Training> trainings = new ArrayList<>();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		trainings = service.getTrainings();
		int trainingId;
		String trainingName;
		int availableSeats;
		String name = request.getParameter("name");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.println("<table>");
		pw.println("<tr><th>Training Id</th><th>Training Name</th><th>Available Seats</th><th></th></tr>");
		for(Training t:trainings)
		{
			trainingId = t.getTrainingId();
			trainingName = t.getTrainingName();
			availableSeats = t.getAvailableSeats();
			pw.println("<tr><td>"+trainingId+"</td><td>"+trainingName+"</td><td>"+availableSeats+"</td><td><a href='Enroll?d="+trainingId+"'>Enroll</a></td></tr>");
			
		}
		pw.println("</table>");
			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
