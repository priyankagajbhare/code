package training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Training;
import service.Service;
import service.ServiceImpl;

@WebServlet("/Enroll")
public class Enroll extends HttpServlet {
	Service service = new ServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int enrollId = Integer.parseInt(request.getParameter("d"));
		
		int enrollResult = service.enroll(enrollId);
		Training fetchedTraining = service.getTraining(enrollId);
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		if(enrollResult == 1)
		{
			pw.println("Hi you have successfully enrolled for "+ fetchedTraining.getTrainingName() + " training.<br>");
			pw.println("Available seats left for this course "+fetchedTraining.getAvailableSeats()+"<br>");
			pw.println("<a href='ShowAllTrainings'>Go back</a><br>");
		}
		
		else if(enrollResult == -2)
		{
			pw.println("No seats available for "+ fetchedTraining.getTrainingName() + " training.<br>");
			pw.println("<a href='ShowAllTrainings'>Go back</a><br>");
		}
		else if(enrollResult == -1)
		{
			pw.println("Invalid Training ID");
			pw.println("<a href='ShowAllTrainings'>Go back</a><br>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
