package service;

import java.util.List;

import dao.Dao;
import dao.DaoImpl;
import dto.Training;

public class ServiceImpl implements Service {
	Dao dao = new DaoImpl();
	
	public List<Training> getTrainings()
	{
		return dao.readTrainings();
	}

	@Override
	public int enroll(int enrollId) {
		return dao.add(enrollId);
	}

	@Override
	public Training getTraining(int enrollId) {
		return dao.readTraining(enrollId);
	}
}
