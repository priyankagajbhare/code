package service;

import java.util.List;

import dto.Training;

public interface Service {
	public List<Training> getTrainings();
	public int enroll(int enrollId);
	public Training getTraining(int enrollId);
}
