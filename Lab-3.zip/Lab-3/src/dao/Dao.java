package dao;

import java.util.List;

import dto.Training;

public interface Dao {
	public List<Training> readTrainings();
	public int add(int enrollId);
	public Training readTraining(int enrollId);
}
