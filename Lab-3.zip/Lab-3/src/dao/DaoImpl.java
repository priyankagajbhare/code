package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.Training;

public class DaoImpl implements Dao {
	private Connection conn;
	private Statement stmt;
	//private ResultSet rs;
	
	private void openConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:orcl11g", "lab2ctrg1", "lab2coracle");
		conn.setAutoCommit(false);
	}
	
	private void closeConnection() throws SQLException {
		conn.close();
	}
	
	@Override
	public List<Training> readTrainings() {
		List<Training> trainings = new ArrayList();
		try {
			openConnection();
			String query = "select * from training";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
		
			
			while(rs.next())
			{
				int trainingId = rs.getInt("trainingid");
				String trainingName = rs.getString("trainingname");
				int availableSeats = rs.getInt("availableseats");
				Training t = new Training(trainingId, trainingName, availableSeats);
				trainings.add(t);
			}
			
			conn.commit();
			stmt.close();
			closeConnection();
		}
		catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("SQLException");
			e.printStackTrace();
		}
		return trainings;
	}

	@Override
	public int add(int enrollId) {
		try {
			openConnection();
			String query = "select availableseats from training where trainingid="+enrollId;
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
		
			if(rs == null)
				return -1;
			if(rs != null)
			{
				rs.next();
				int availableSeats = rs.getInt("availableseats");
				if(availableSeats > 0)
				{
					availableSeats = availableSeats - 1;
					query = "update training set availableseats="+availableSeats+" where trainingid="+enrollId;
					stmt.execute(query);
					conn.commit();
					stmt.close();
					closeConnection();
					return 1;
				}
				else
					return -2;
			}
			conn.commit();
			stmt.close();
			closeConnection();
			
		}
		catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("SQLException");
			e.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public Training readTraining(int enrollId) {
		Training t = null;
		try {
			openConnection();
			String query = "select * from training where trainingid="+enrollId;
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
		
			rs.next();
		
			int trainingId = rs.getInt("trainingid");
			String trainingName = rs.getString("trainingname");
			int availableSeats = rs.getInt("availableseats");
			t = new Training(trainingId, trainingName, availableSeats);
			
			
			conn.commit();
			stmt.close();
			closeConnection();
		}
		catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("SQLException");
			e.printStackTrace();
		}
		
		return t;
	}

}
