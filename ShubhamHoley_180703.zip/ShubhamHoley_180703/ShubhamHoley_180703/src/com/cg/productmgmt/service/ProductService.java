package com.cg.productmgmt.service;

import java.util.Map;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {

	ProductDao dao = new ProductDao();

	public int updateProducts(String Category, int hike) throws ProductException {

		return dao.updateProducts(Category, hike);

	}

	public Map<String, Integer> getProductDetails() throws ProductException {

		Map<String, Integer> map;

		map = dao.getProductDetails();

		return map;

	}

	@Override
	public Map<String, Integer> getproductdetails() throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

}
