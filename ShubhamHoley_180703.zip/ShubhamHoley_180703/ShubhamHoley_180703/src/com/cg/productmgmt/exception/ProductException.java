package com.cg.productmgmt.exception;

public class ProductException extends Exception {

}
