package com.cg.productmgmt.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client {

	public static void main(String[] args) {

		ProductService service = new ProductService();

		int i; // integer variable to input choice from user

		Scanner sc = new Scanner(System.in);

		do {

			System.out.println("1. Update Product Price");

			System.out.println("2. Exit");

			System.out.print("Enter your choice: ");

			i = sc.nextInt();

			switch (i) {

			case 1:

				System.out.print("Enter the Product Category: ");

				String Category = sc.next();

				System.out.println("Enter hike Rate: ");

				int hike = sc.nextInt();

				if (0 > hike)

					try {

						throw new ProductException();

					} catch (ProductException pe) {

						break;

					}

				try {

					int result = service.updateProducts(Category, hike);

					if (result == 1)

						System.out.println("Price Updated");

					else

						System.out.println("Price Not Updated");

				} catch (ProductException pe) {

					pe.printStackTrace();

				}

				System.out.println("Updated Details are:");

				try {

					Map<String, Integer> map = service.getProductDetails();

					Iterator itr = map.keySet().iterator();

					for (String key : map.keySet()) {

						System.out.print("Product Name:" + key);

						System.out.println("\t\tProduct Price:" + map.get(key));

					}

				} catch (ProductException pe) {

					pe.printStackTrace();

				}

				break;

			case 2:

				break;

			default:

				System.out.println("Enter correct option");

			}

		} while (i != 2);

	}

}
