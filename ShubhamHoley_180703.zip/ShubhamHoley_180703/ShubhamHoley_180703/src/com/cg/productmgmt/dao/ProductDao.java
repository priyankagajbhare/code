package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;

public class ProductDao implements IProductDAO {

	// map for Category as key and Product Name as Value
	static Map<String, String> productDetails;

	// map for Product name as key and price as value
	static Map<String, Integer> salesDetails;

	static {
		productDetails = new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");

		salesDetails = new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);

	}

	public int updateProducts(String Category, int hike) throws ProductException {

		Iterator ite1 = productDetails.keySet().iterator();

		Iterator ite2 = salesDetails.keySet().iterator();

		int flag = 0;

		while (ite1.hasNext()) {

			String tempProductName = (String) ite1.next();

			// System.out.println(tempProductName);

			String productCategory = productDetails.get(tempProductName);

			if (productCategory.equals(Category)) {

				while (ite2.hasNext()) {

					if (tempProductName.equals(ite2.next())) {

						// System.out.println(tempProductName);

						int price = salesDetails.get(tempProductName);

						int hikedPrice = price + (price * 10) / 100;

						salesDetails.put(tempProductName, hikedPrice);

						flag++;

					}

				}

			}

		}

		if (flag == 0)

			return 0;

		else

			return 1;

	}

	public Map<String, Integer> getProductDetails() throws ProductException {

		return salesDetails;

	}

}
