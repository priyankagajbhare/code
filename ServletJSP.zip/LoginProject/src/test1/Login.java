package test1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test1.do")
public class Login extends HttpServlet {
  	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		if(user.equals("admin") && pass.equals("admin123")){
			pw.println("<h2>You are Successfully logged in.");
		}else{
			pw.println("<h2>Failed to login.");
		}
		pw.println("</body>");
		pw.println("</html>");
	}

}
