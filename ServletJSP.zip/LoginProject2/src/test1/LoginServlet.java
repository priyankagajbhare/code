package test1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/test1.do")
public class LoginServlet extends HttpServlet {
  	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.println("<html>");
		pw.println("<body>");
		if(user.equals("admin") && pass.equals("admin123")){
			RequestDispatcher rd = request.getRequestDispatcher("Success.jsp");
			rd.forward(request, response);
		}else{
			response.sendRedirect("Error.jsp");
		}
		pw.println("</body>");
		pw.println("</html>");
	}

}
