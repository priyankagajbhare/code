package com.capgemini.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.capgemini.dao.OrderDao;
import com.capgemini.dto.Order;
import com.capgemini.exceptions.OrderException;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceImplTest {
	private OrderServiceImpl impl;
	private Order order;
	@Mock
	private OrderDao dao;

	@Before
	public void setUp() {
		impl = new OrderServiceImpl();
		order = new Order(1001, "Confirmed");
		impl.setDao(dao);
	}

	@Test
	public void testPlaceOrderShouldReturnTrue() throws OrderException, SQLException {
		when(dao.createOrder(order)).thenReturn(1);
		boolean result = impl.placeOrder(order);
		assertTrue(result);
		verify(dao, times(1)).createOrder(order);
	}

	@Test
	public void testPlaceOrderShouldReturnFalse() throws OrderException, SQLException {
		when(dao.createOrder(order)).thenReturn(-1);
		boolean result = impl.placeOrder(order);
		assertFalse(result);
	}
	
	@Test(expected=OrderException.class)
	public void testPlaceOrderShouldThrowOrderException() throws OrderException, SQLException{
		when(dao.createOrder(order)).thenThrow(SQLException.class);
		impl.placeOrder(order);

	} 
}
