package com.capgemini.dto;

public class Order {
	private int orderId;
	private String orderSatus;
	
	public Order(int orderId, String orderSatus) {
		super();
		this.orderId = orderId;
		this.orderSatus = orderSatus;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderSatus() {
		return orderSatus;
	}

	public void setOrderSatus(String orderSatus) {
		this.orderSatus = orderSatus;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderSatus=" + orderSatus + "]";
	}
	
}
