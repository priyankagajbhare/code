package com.capgemini.service;

import java.sql.SQLException;

import com.capgemini.dao.OrderDao;
import com.capgemini.dto.Order;
import com.capgemini.exceptions.OrderException;

public class OrderServiceImpl implements OrderService{
	private OrderDao dao;
	@Override
	public boolean placeOrder(Order order) throws OrderException {
		try{
			int result = dao.createOrder(order);
			if(result > 0)
				return true;
		}
		catch(SQLException e){
			throw new OrderException("Problem in placing an order.");
		}
		return false;
	}
	@Override
	public boolean cancelOrder(int orderId) throws OrderException {
		try {
				Order order = dao.readOrder(orderId);
				order.setOrderSatus("Cancelled");
				int result = dao.updateOrder(order);
				if(result > 0)
					return true;
			}
		catch(SQLException e) {
				throw new OrderException("Order is cancelled,");
		}
		return false;
	}
	@Override
	public boolean deleteOrder(int orderId) throws OrderException {
		try {
			int result = dao.deleteOrder(orderId);
			if(result > 0)
				return true;
		}
		catch (SQLException e) {
			throw new OrderException("Problem in deleting order.");
		}
		return false;
	}
	public OrderDao getDao() {
		return dao;
	}
	public void setDao(OrderDao dao) {
		this.dao = dao;
	}

}
