package com.capgemini.exceptions;

public class OrderException extends Exception {

	public OrderException(String string) {
		super(string);
	}

}
