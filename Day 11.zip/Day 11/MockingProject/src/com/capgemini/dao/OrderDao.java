package com.capgemini.dao;

import java.sql.SQLException;

import com.capgemini.dto.Order;

public interface OrderDao {
	public int createOrder(Order order) throws SQLException;
	public Order readOrder(int orderId) throws SQLException;
	public int updateOrder(Order order) throws SQLException;
	public int deleteOrder(int orderId) throws SQLException;
}
