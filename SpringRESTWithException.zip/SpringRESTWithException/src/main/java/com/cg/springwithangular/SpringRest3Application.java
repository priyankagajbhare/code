package com.cg.springwithangular;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRest3Application {
	public static void main(String[] args) {
		SpringApplication.run(SpringRest3Application.class, args);
	}
}
