package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");  // case sensitive
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:orcl11g", "lab2ctrg12", "lab2coracle");
			Statement stmt = conn.createStatement();
			String query = "select * from emp";
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				int empno = rs.getInt("empno");
				String ename = rs.getString("ename");
				double sal = rs.getDouble("sal");

				System.out.println(empno + ", " + ename + ", " + sal);
			}
			rs.close();
			stmt.close();
			conn.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}