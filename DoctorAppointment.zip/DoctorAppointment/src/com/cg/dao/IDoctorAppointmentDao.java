package com.cg.dao;

import com.cg.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {
	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointemnt);

	DoctorAppointment getAppointmentDetails(int appointmentID);
}
