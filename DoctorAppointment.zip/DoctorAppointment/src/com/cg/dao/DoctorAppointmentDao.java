package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao{
	private static Map<Integer, DoctorAppointment> dA = new HashMap<Integer, DoctorAppointment>();
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointemnt) {
		int appointmentId = (int) (1000+(Math.random()*(2000-1000)));
		doctorAppointemnt.setAppointmentId(appointmentId);
		dA.put(doctorAppointemnt.getAppointmentId(), doctorAppointemnt);
		return doctorAppointemnt.getAppointmentId();
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentID) {
		if(dA.containsKey(appointmentID))
			return dA.get(appointmentID);
		return null;
	}

}
