package com.cg.service;

import com.cg.bean.DoctorAppointment;
import com.cg.dao.DoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService{
	DoctorAppointmentDao dao = new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointemnt) {
		int result = dao.addDoctorAppointmentDetails(doctorAppointemnt);
		return result;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentID) {
		DoctorAppointment dA = dao.getAppointmentDetails(appointmentID);
		return dA;
	}

}
