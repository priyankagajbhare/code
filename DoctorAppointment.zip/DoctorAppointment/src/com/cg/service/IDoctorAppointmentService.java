package com.cg.service;

import com.cg.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointemnt);
	DoctorAppointment getAppointmentDetails(int appointmentID);
}
