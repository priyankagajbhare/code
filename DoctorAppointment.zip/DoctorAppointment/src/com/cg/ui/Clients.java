package com.cg.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.bean.DoctorAppointment;
import com.cg.service.DoctorAppointmentService;

public class Clients {
	public static void main(String[] args) {

		DoctorAppointmentService service = new DoctorAppointmentService();
		int ch;
		Scanner Sc = new Scanner(System.in);
		do {
			System.out.println("1. Book Doctor Appointment");
			System.out.println("2. View Doctor Appointment");
			System.out.println("3. Exit");
			ch = Sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter name of patient:");
				String name = Sc.next();
				System.out.println("Enter phone number:");
				String phone = Sc.next();
				System.out.println("Enter email:");
				String email = Sc.next();
				System.out.println("Enter age:");
				int age = Sc.nextInt();
				System.out.println("Enter gender:");
				String gender = Sc.next();
				String problem = null;
				int id = 0;
				LocalDate date = java.time.LocalDate.now();
				String doctor = null;
				String appointmentStatus = "DISAPPROVED";
				DoctorAppointment dA = new DoctorAppointment(id, name, phone, email, gender, date, age, problem, doctor,
						appointmentStatus);
				do {
					System.out.println("Enter Problem:");
					problem = Sc.next();
					if (problem.equalsIgnoreCase("heart") == true) {
						appointmentStatus = "APPROVED";
						doctor = "Dr. Brijesh Kumar";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else if (problem.equalsIgnoreCase("gynecology") == true) {
						doctor = "Dr. Sharda Singh";
						appointmentStatus = "APPROVED";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else if (problem.equalsIgnoreCase("diabetes") == true) {
						doctor = "Dr. Heena Khan";
						appointmentStatus = "APPROVED";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else if (problem.equalsIgnoreCase("ent") == true) {
						doctor = "Dr. Paras Mal";
						appointmentStatus = "APPROVED";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else if (problem.equalsIgnoreCase("Bone") == true) {
						doctor = "Dr. Renuka Kher";
						appointmentStatus = "APPROVED";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else if (problem.equalsIgnoreCase("dermatology") == true) {
						doctor = "Dr. Kanika Kapoor";
						appointmentStatus = "APPROVED";
						id = service.addDoctorAppointmentDetails(dA);
						System.out.println("Appointment ID : " + dA.getAppointmentId());
						break;
					} else {
						System.out.println("Invalid problem. Please enter a valid problem.");

					}
				} while (problem.equalsIgnoreCase("heart") == false || problem.equalsIgnoreCase("gynecology") == false
						|| problem.equalsIgnoreCase("diabetes") == false || problem.equalsIgnoreCase("ent") == false
						|| problem.equalsIgnoreCase("Bone") == false
						|| problem.equalsIgnoreCase("dermatology") == false);

				dA.setDoctorName(doctor);
				dA.setAppointmentStatus(appointmentStatus);
				break;
			case 2:
				System.out.println("Enter appointment Id:");
				id = Sc.nextInt();
				dA = service.getAppointmentDetails(id);
				if (dA == null)
					System.out.println("Appointment Not Found");
				else
					System.out.println(dA);
				break;
			}
		} while (ch != 3);
	}

}
