package lib2;

public class Book
{
	private String bookName;
	private String bookAuthor;
	private double bookPrice;
	
	public void getBookData(String name, String author, double price)
	{
		bookName = name;
		bookAuthor = author;
		bookPrice = price;
	}
	public void showBookData()
	{
		System.out.println("Book Name: "+bookName);
		System.out.println("Book Author: "+bookAuthor);
		System.out.println("Book Price: "+bookPrice);
		
	}
}

class BookDemo
{
	public static void main(String[] args) 
	{
		Book book1 = new Book();
		Book book2 = new Book();
		book1.getBookData("JAVA", "CAY Horstman", 550.50);
		book1.showBookData();
		
		book2.getBookData("C", "RS Kanetkar", 180.20);
		book2.showBookData();
	}	
}

