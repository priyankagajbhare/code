package lib;

public class Book {
	String bookName;
	String bookAuthor;
	double bookPrice;
	

}
/*
class BookDemo{
	public static void main(String[] args) {
		Book book1 = new Book();
		book1.bookName = "Java";
		book1.bookAuthor = "Cay Horstman";
		book1.bookPrice = 550.50;
		
		System.out.println("Book Name: "+book1.bookName);
		System.out.println("Book Author: "+book1.bookAuthor);
		System.out.println("Book Price "+book1.bookPrice);
	}
}
*/


class BookDemo{
	public static void main(String[] args) {
		Book book1 = null;
		book1.bookName = "Java";
		book1.bookAuthor = "Cay Horstman";
		book1.bookPrice = 550.50;
		
		System.out.println("Book Name: "+book1.bookName);
		System.out.println("Book Author: "+book1.bookAuthor);
		System.out.println("Book Price "+book1.bookPrice);
	}
	
}









