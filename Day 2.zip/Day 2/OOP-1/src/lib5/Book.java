package lib5;

public class Book {
	private String bookName;
	private String bookAuthor;
	private double bookPrice;
	
	public Book()
	{
		this("unknown-book", "unknown-author", -1);
	}
	public Book(String bookName, String bookAuthor, double bookPrice)
	{
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
		
	}
	public void display()
	{
		System.out.println("Book Name: "+bookName);
		System.out.println("Book Author: "+bookAuthor);
		System.out.println("Book Price: "+bookPrice);
	}
	public static void main(String[] args) {
		Book book1 = new Book("JAVA", "C.H", 550.50);
		book1.display();
		Book book2 = new Book();
		book2.display();

	}
}
