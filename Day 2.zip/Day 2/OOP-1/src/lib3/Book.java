package lib3;

public class Book{
	private String bookName;
	private String bookAuthor;
	private double bookPrice;
	private static double discount;
	
	public static void setDiscount(double d)
	{
		Book.discount = d;
	}
	public void getBookData(String name, String author, double price)
	{
		bookName = name;
		bookAuthor = author;
		bookPrice = price;
	}
	public void showBookData()
	{
		System.out.println("Book Name: "+bookName);
		System.out.println("Book Author: "+bookAuthor);
		System.out.println("Book Price: "+bookPrice);
		
	}
	
	public void calculatePrice(){
		double price;
		price = bookPrice - bookPrice*(Book.discount/100);
		System.out.println("Discount Price: "+price);
	}
}

class BookDemo
{
	public static void main(String[] args) 
	{
		Book book1 = new Book();
		Book book2 = new Book();
		
		Book.setDiscount(10);
		
		book1.getBookData("JAVA", "CAY Horstman", 550.50);
		book1.showBookData();
		book1.calculatePrice();
		
		book2.getBookData("C", "RS Kanetkar", 180.20);
		book2.showBookData();
		book2.calculatePrice();
	}	
}

