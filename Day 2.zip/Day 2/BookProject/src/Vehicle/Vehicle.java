package Vehicle;

public class Vehicle {
	private String regno;
	private String brand;
	private double price;
	private double mileage;
	
	public Vehicle(String regno, String brand, double price, double mileage){
		this.regno = regno;
		this.brand = brand;
		this.price = price;
		this.mileage = mileage;
	}
	public void display(){
		System.out.println("Regno: "+regno);
		System.out.println("Brand: "+brand);
		System.out.println("Price: "+price);
		System.out.println("Mileage: "+mileage);
	}
	public double returnPrice(){
		return price;
	}
	public double returnMileage(){
		return mileage;
	}
public static void main(String[] args) {
	Vehicle v1 = new Vehicle("10121", "Jaguar", 2500000.021, 12.2);
	v1.returnPrice();
	Vehicle v2 = new Vehicle("15421", "Jaguar", 5000000.021, 16.7);
	v2.returnPrice();
	
	if(v1.returnPrice() > v2.returnPrice()){
		v2.display();
	}
	else{
		v1.display();
	}
	 
	if(v1.returnMileage()>v2.returnMileage()){
		v1.display();
	}
	else{
		v2.display();
	}
}
}
