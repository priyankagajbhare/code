package library;

public class Book {
	private String isbn;
	private String title;
	private String author;
	private double price;
	
	public Book(String isbn, String title, String author, double price){
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
	}
	public void displayDetails(){
		System.out.println("Isbn: "+isbn);
		System.out.println("Title: "+title);
		System.out.println("Author: "+author);
		System.out.println("Price: "+price);
		System.out.println("Price to Pay: "+discountedPrice(10));
	}
	public double discountedPrice(double discount){
		double priceToPay = price - (price * (discount/100));
		return priceToPay;
	}
	public static void main(String[] args) {
		Book book1 = new Book("112545343","Java Volume - 1","C.H.", 550.50);
		book1.displayDetails();
	}
}
