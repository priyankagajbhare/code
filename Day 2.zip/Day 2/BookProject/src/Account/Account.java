package Account;

public class Account {
	private int AccNo;
	private String AccHolderName;
	private double balance;
	
	public Account(int AccNo, String AccHolderName, double balance){
		this.AccNo = AccNo;
		this.AccHolderName = AccHolderName;
		this.balance = balance;
	}
	
	public double deposite(double deposite){
		balance = balance + deposite;
		return balance;
	}
	public double withdraw(double withdraw){
		balance = balance - withdraw;
		return balance;
	}
	public void displayDetails(){
		System.out.println("Acc Number: "+AccNo);
		System.out.println("Cust Name: "+AccHolderName);
		System.out.println("Current Balance: "+balance);
	}
	public static void main(String[] args) {
		Account a1 = new Account(1235412852, "Javed Habib", 200.22);
		a1.deposite(50032);
		a1.displayDetails();
		
		Account a2 = new Account(1543655466, "Abhinav Bajaj", 50021.51);
		a2.withdraw(500);
		a2.displayDetails();
	}

}
