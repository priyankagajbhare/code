import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlbumService } from '../album.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private _service:AlbumService) { }

  ngOnInit() {
  }
  getData(form)
  {
    this._service.putAlbum(form);
    //this._service.router.navigate(['/list']);
  }
}
