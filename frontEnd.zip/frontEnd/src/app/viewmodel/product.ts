export class Product {
    productId:number;
    productName:string;
    productRating:number;
    catrgory:string;
    productDescription:string;
    productQuantity:number;
    }