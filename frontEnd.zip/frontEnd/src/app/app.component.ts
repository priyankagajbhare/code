﻿import { Component } from '@angular/core';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.css']
})

export class AppComponent {
    title = ' Angular 6';
    name:string = 'Kedar'
    firstName:string = 'Kedar'
    lastName:string = 'Dhotre'
    gender:string = 'Male'
    age:string = '24'
 }