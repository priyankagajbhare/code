import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  //form variable
  form : FormGroup;
  constructor() { }

  ngOnInit() {
    //For loading form when page loads in ngOninit
    this.form = new FormGroup({
      name : new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z ]+')]),//input with validations
      address : new FormControl('',[Validators.required]),//input with validations
      pincode : new FormControl('',[Validators.required,Validators.pattern("[0-9]*"),Validators.minLength(6),Validators.maxLength(6)])//input with validations
    })
  }

}
