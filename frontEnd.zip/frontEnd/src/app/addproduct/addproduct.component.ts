import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  form : FormGroup;
  constructor(private router:Router, private _service:ProductService) { }

  ngOnInit() {
     //For loading form when page loads in ngOninit
     this.form = new FormGroup({
      productId : new FormControl('',[Validators.required]),//input with validations
      productName : new FormControl('',[Validators.required]),//input with validations
      productRating : new FormControl('',[Validators.required]),//input with validations
      catrgory : new FormControl('',[Validators.required]),//input with validations
      productDescription : new FormControl('',[Validators.required]),//input with validations
      productQuantity : new FormControl('',[Validators.required]),//input with validations
    })
  }

  addProduct(frm){
    this._service.addProduct(frm.value).subscribe(data =>{
      this.router.navigate(['']);
    })
  }

}
