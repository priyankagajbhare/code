import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../viewmodel/product';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  productList:Product[];
  constructor(private _productService:ProductService) { }

  ngOnInit() {
    this._productService.getProducts().subscribe(data =>{
      this.productList = data;
    })
  }

  // Delete User
  deleteProduct(product: Product): void {
    let result = confirm("Do you want to delete Product?");
    if (result) {
      this._productService.deleteProduct(product.productId)
        .subscribe(data => {
          this.productList = this.productList.filter
            (p => p !== product);
        })
    }
  }

}
