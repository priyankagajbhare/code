import { Injectable } from '@angular/core';
import { Product } from '../viewmodel/product';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
productList:Product[];
baseUrl = "http://localhost:8080/getAll"
postUrl = "http://localhost:8080/addproduct"
deleteUrl = "http://localhost:8080/"
  constructor(private http:HttpClient) { }

  getProducts(){
    return this.http.get<Product[]>(this.baseUrl);
  }

  addProduct(product:Product){
    return this.http.post(this.postUrl, product)
  }

  deleteProduct(id: number){
    return this.http.delete(this.deleteUrl + "/" + id);
  }

}
