﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';;
import { LoginComponent } from './login/login.component';
import { InventoryComponent } from './inventory/inventory.component';
import { HttpClientModule } from '@angular/common/http';;
import { AddproductComponent } from './addproduct/addproduct.component'

const appRoutes:Routes = [
    { path: '', component: InventoryComponent},//empty path
    { path: 'addproduct', component: AddproductComponent}
]

@NgModule({
    imports: [
        BrowserModule,
        RouterModule.forRoot(appRoutes),
        FormsModule,
        ReactiveFormsModule, //Reactive form
        HttpClientModule
    ],
    declarations: [
        AppComponent,
        LoginComponent,
        InventoryComponent,
        AddproductComponent],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }