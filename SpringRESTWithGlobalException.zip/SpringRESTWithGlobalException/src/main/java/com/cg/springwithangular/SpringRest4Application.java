package com.cg.springwithangular;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRest4Application {
	public static void main(String[] args) {
		SpringApplication.run(SpringRest4Application.class, args);
	}
}
