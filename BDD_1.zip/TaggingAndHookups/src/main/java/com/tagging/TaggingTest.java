package com.tagging;

import cucumber.api.java.en.*;

public class TaggingTest {
	

	@Given("This is valid logging")
	public void this_is_valid_logging() {
		
	}

	@Given("This is invalid logging")
	public void this_is_invalid_logging() {
	    
	}

	@Given("I logged using skip sign in button")
	public void i_logged_using_skip_sign_in_button() {
	    
	}

	@Given("make registry with all the fields")
	public void make_registry_with_all_the_fields() {
	    
	}

	@Given("make registry with mandatory fields")
	public void make_registry_with_mandatory_fields() {
	    
	}

	@Given("verify webtable page open")
	public void verify_webtable_page_open() {
	    
	}

	@Given("verify we are at swith tab")
	public void verify_we_are_at_swith_tab() {
	    
	}

	@Given("verify widget tab is open")
	public void verify_widget_tab_is_open() {
	    
	}

	@Given("verify interaction tab is open")
	public void verify_interaction_tab_is_open() {
	    
	}

	@Given("verify video tab is open")
	public void verify_video_tab_is_open() {
	    
	}

	@Given("verify WYSIWYG")
	public void verify_WYSIWYG() {
	    
	}

	@Given("verify More")
	public void verify_More() {
	    
	}

	@Given("verify practice site")
	public void verify_practice_site() {
	    
	}
}
