package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/*@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\resources\\tagging.feature",
							glue = {"com.tagging"}, 
							monochrome = true, 
							dryRun=false,
							//tags = {"@SmokeTest"},
							//tags = {"@RegressionTest"},
							//tags = {"@E2ETest"},
							//tags = {"@SmokeTest","@RegressionTest"},    //-------->>> And Condition
							//tags = {"@SmokeTest, @RegressionTest,"},    //-------->>> OR Condition
							tags = {"not @SmokeTest"}                     //-------->>> Ignore some tests
							) */

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\resources\\taggedhooks.feature",
							glue = {"com.taggedhooks"}, 
							monochrome = true, 
							dryRun=false
							)
public class TestRunner {
							                   

}
