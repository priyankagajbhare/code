package com.workflow;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.applicationobjects.LoginPageAO;
import com.library.LoginPageInitialization;

import cucumber.api.java.en.*;

public class VerifyLoginPageWithRegistryTest {
	WebDriver driver;
	String url="http://demo.automationtesting.in/Index.html";
	
	LoginPageAO loginPageAO;
	
	@Given("login with valid url")
	public void login_with_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter valid username")
	public void enter_valid_username() {
		//driver.findElement(By.id("email")).sendKeys("shubham@gmail.com");
		//loginPageAO = new LoginPageAO(driver);
		//loginPageAO.getText_LoginPage_UserName().sendKeys("shubham@gmail.com");
		System.out.println("Writing into pagefactory - username");
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		//driver.findElement(By.id("enterimg")).click();
		//loginPageAO = new LoginPageAO(driver);
		//loginPageAO.getButton_LoginPage_Submit().click();
		System.out.println("Writing into pagefactory - click button");
	}

	@Then("verify welcome page")
	public void verify_welcome_page() {
		LoginPageInitialization loginPageInitialization = PageFactory.initElements(driver, LoginPageInitialization.class);
		loginPageInitialization.loginWithValidCredentials("shubham@gmail.com");
		String expectedText="Automation Demo Site ";
		String actualText = driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).getText();
		if(expectedText.contains(actualText))
			System.out.println("We are at Register page");
		else
			System.out.println("Register page not open");
	}

	@Then("enter firstname of user")
	public void enter_firstname_of_user() {
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Shubham");
	}

	@Then("enter lastname of user")
	public void enter_lastname_of_user() {
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Holey");
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
}
