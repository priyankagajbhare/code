package com.applicationobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageAO {
	WebDriver driver;
	
	public LoginPageAO(WebDriver driver) {
		this.driver = driver;
	}
	
	//user name
	By userName = By.id("email");
	public WebElement getText_LoginPage_UserName() {
		return driver.findElement(userName);
	}
	
	//submit
	By submit = By.id("enterimg");
	public WebElement getButton_LoginPage_Submit() {
		return driver.findElement(submit);
	}
}
