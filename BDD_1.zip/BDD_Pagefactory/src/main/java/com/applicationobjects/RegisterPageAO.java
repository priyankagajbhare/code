package com.applicationobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterPageAO {
	WebDriver driver;

	public RegisterPageAO(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	// firstName
	By firstName = By.xpath("//input[@placeholder='First Name']");

	public WebElement getText_RegisterPage_FirstName() {
		return driver.findElement(firstName);
	}

	// lastName
	By lastName = By.xpath("//input[@placeholder='Last Name']");

	public WebElement getText_RegisterPage_LastName() {
		return driver.findElement(lastName);
	}
}
