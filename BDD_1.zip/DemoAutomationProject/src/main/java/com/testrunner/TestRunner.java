package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/*//Test #1
@RunWith(Cucumber.class)
@CucumberOptions(features = "featurefile", glue = "", monochrome = true)
public class TestRunner {

}
*/

//Test #2
@RunWith(Cucumber.class)
@CucumberOptions(features = "featurefile\\googlesearchpage.feature", glue = "com.googlesearch", monochrome = true, dryRun=false)
public class TestRunner {

}
