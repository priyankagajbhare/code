package com.googlesearch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.*;

public class VerifyGoogleTextBoxIsWorking {
	WebDriver driver;

	@Then("search for the value {string}.")
	public void search_for_the_value(String searchValue) {
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("I am Indian");
	}

	@Then("click on the search button.")
	public void click_on_the_search_button() {
		driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).click();
		System.out.println("Search Button is Present");
	}
}
