package com.googlesearch;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;

public class VerifyGoogleSearchPage {
	
	WebDriver driver;
		
	@Given("launch chrome browser.")
	public void launch_chrome_browser() {
	    System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
	    driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		System.out.println("Browser is opened");
	}


	@When("open google home page")
	public void open_google_home_page() {
	    driver.get("https://www.google.com/");
	    System.out.println("Home page is opened");
	}

	@Then("verify search text box is present")
	public void verify_search_text_box_is_present() {
	   if(driver.findElement(By.xpath("//input[@name='q']")).isDisplayed());
	   System.out.println("Text Box is Present");
	}

	@Then("verify google saerch button is present")
	public void verify_google_saerch_button_is_present() {
	    driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).isDisplayed();
	    System.out.println("Search Button is Present");
	}

	@Then("verify I am feeling lucky button is present")
	public void verify_I_am_feeling_lucky_button_is_present() {
		driver.findElement(By.xpath("//input[@name='btnI']")).isDisplayed();
		System.out.println("I'm Feeling Lucky Button is Present");
	}

	@Then("close the chrome browser.")
	public void close_the_chrome_browser() {
		System.out.println("Quiting...");
	    driver.quit();
	}
}
