package com.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;

public class LoginTest {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";

	@Given("navigate through valid url")
	public void navigate_through_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\Shubham\\\\BDD\\\\SeleniumJar\\\\Driver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter the valid username.")
	public void enter_the_valid_username() {
		driver.findElement(By.id("email")).sendKeys("shubham12@gmail.com");
	}

	@Then("click on submit button.")
	public void click_on_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("verify login successfull.")
	public void verify_login_successfull() {
		String expectedResult = "Register";
		String actualResult = driver.findElement(By.xpath("//h2[text()='Register']")).getText();
		if (expectedResult.contains(actualResult))
			System.out.println("We are at Welcome page");
		else
			System.out.println("Unable to Login");
	}

	@Then("close the browser.")
	public void close_the_browser() {
		driver.quit();
	}
	
	@Then("click on skip sign sign in button.")
	public void click_on_skip_sign_in_button() {
		// click on submit button
		driver.findElement(By.id("btn2")).click();
	}
	
	@Then("verify title of the page.")
	public void verify_title_of_the_page() {
		//verify title
		String expectedResult = "Register";
		String actualResult = driver.getTitle();
		Assert.assertEquals("title matched", expectedResult, actualResult);
		System.out.println("Title of the page is "+actualResult);
	}
}
