package com.applicationobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterPage {
	
	WebDriver driver;
	public RegisterPage(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public WebElement getText_Register_FirstName() {
		return driver.findElement(By.xpath("//input[@placeholder='First Name']"));
	}
	
	public WebElement getText_Register_LastName() {
		return driver.findElement(By.xpath("//input[@placeholder='Last Name']"));
	}
	
	public WebElement getText_Register_EmailAddress() {
		return driver.findElement(By.xpath("//input[@type='email']"));
	}
	
	public WebElement getText_Register_Telephone() {
		return driver.findElement(By.xpath("//input[@type='tel']"));
	}
	
	public WebElement getRadioButton_Register_Male() {
		return driver.findElement(By.xpath("//input[@value='Male']"));
	}
	
	public WebElement getDropdown_Register_Country() {
		//return driver.findElement(By.xpath("//option[@value='India']"));
		return driver.findElement(By.id("countries")).findElement(By.xpath("//option[@value='India'"));
	}
	
	public WebElement getDropdown_Register_Year() {
		//return driver.findElement(By.id("yearbox"));
		return driver.findElement(By.id("yearbox")).findElement(By.xpath("//option[@value='1983'"));
		
	}
	
	public WebElement getDropdown_Register_Month() {
		//return driver.findElement(By.xpath("//select[@placeholder='Month']"));
		return driver.findElement(By.xpath("//select[@placeholder='Month'")).findElement(By.xpath("//option[@value='June'"));
		
	}
	
	public WebElement getDropdown_Register_Day() {
		//return driver.findElement(By.id("daybox"));
		return driver.findElement(By.id("daybox")).findElement(By.xpath("//option[@value='20'"));
		
	}
	
	public WebElement getText_Register_Password() {
		return driver.findElement(By.id("firstpassword"));
	}
	
	public WebElement getText_Register_ConfirmPassword() {
		return driver.findElement(By.id("secondpassword"));
	}
	
	public WebElement getButton_Register_SubmitRegisterPage() {
		return driver.findElement(By.id("submitbtn"));
	}
}
