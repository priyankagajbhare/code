package com.teardown;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

public class Teardown {
	WebDriver driver;

	public Teardown(WebDriver driver) {
		this.driver = driver;
	}

	public void getCloseBrowser(String verificationErrors) {
		driver.quit();
		if (!verificationErrors.equals(""))
			Assert.fail();
	}
}
