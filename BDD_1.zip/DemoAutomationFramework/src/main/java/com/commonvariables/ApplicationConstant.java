package com.commonvariables;

public class ApplicationConstant {
	public String userName = "saikiran@gmail.com";
	public String firstName = "Mantu";
	public String lastName = "Kumaiir";
	public String emailAddress = "mantu123@gmail.com";
	public String phoneNumber = "9012356789";
	public String password = "Abcd@12345";
	public String confirmPassword = "Abcd@12345";
	
}
