package com.applicationobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentDetailsObject {
	WebDriver driver;

	public PaymentDetailsObject(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	By pageTitle = By.xpath("//h4[text()='Step 2: Payment Details']");
	public WebElement getText_UserInformation_Title() {
		return driver.findElement(pageTitle);
	}
	
	By cardHolderName = By.id("txtCardholderName");
	public WebElement getText_PaymentDetails_CardHolderName() {
		return driver.findElement(cardHolderName);
	}
	
	By debitCardName = By.id("txtDebit");
	public WebElement getText_PaymentDetails_DebitCardName() {
		return driver.findElement(debitCardName);
	}
	
	By cVV = By.id("txtCvv");
	public WebElement getText_PaymentDetails_CVV() {
		return driver.findElement(cVV);
	}
		
	By month = By.id("txtMonth");
	public WebElement getText_PaymentDetails_Month() {
		return driver.findElement(month);
	}
	
	
	By year = By.id("txtYear");
	public WebElement getText_PaymentDetails_Year() {
		return driver.findElement(year);
	}
	
	By button = By.id("btnPayment");
	public WebElement getText_PaymentDetails_Button() {
		return driver.findElement(button);
	}
}
