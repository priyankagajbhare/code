package com.applicationobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UserInformationObjects {
	WebDriver driver;

	public UserInformationObjects(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	By pageTitle = By.xpath("//td[text()='PERSONAL INFORMATION']");
	public WebElement getText_UserInformation_Title() {
		return driver.findElement(pageTitle);
	}
	
	By userName = By.id("txtName");
	public WebElement getText_UserInformation_userName() {
		return driver.findElement(userName);
	}
	
	By firstName = By.id("txtFirstName");
	public WebElement getText_UserInformation_firstName() {
		return driver.findElement(firstName);
	}
	
	By lastName = By.id("txtLastName");
	public WebElement getText_UserInformation_lastName() {
		return driver.findElement(lastName);
	}
	
	By fatherName = By.id("txtFatherName");
	public WebElement getText_UserInformation_fatherName() {
		return driver.findElement(fatherName);
	}
	
	By dOB = By.id("txtDOB");
	public WebElement getText_UserInformation_dOB() {
		return driver.findElement(dOB);
	}
	
	By gender = By.id("rdbMale");
	public WebElement getText_UserInformation_gender() {
		return driver.findElement(gender);
	}
	
	By mobileNo = By.id("txtMobileNo");
	public WebElement getText_UserInformation_mobileNo() {
		return driver.findElement(mobileNo);
	}
	
	By emailId = By.id("txtEmail");
	public WebElement getText_UserInformation_emailId() {
		return driver.findElement(emailId);
	}
	
	By landLine = By.id("txtLndLine");
	public WebElement getText_UserInformation_landLine() {
		return driver.findElement(landLine);
	}
	
	By communication = By.id("rdbResAddress");
	public WebElement getText_UserInformation_communication() {
		return driver.findElement(communication);
	}
	By resideneceAddress = By.id("txtAResidenceAdd");
	public WebElement getText_UserInformation_resideneceAddress() {
		return driver.findElement(resideneceAddress);
	}
	
	By submitButton = By.id("btnSubmit");
	public WebElement getText_UserInformation_submitButton() {
		return driver.findElement(submitButton);
	}
	
}
