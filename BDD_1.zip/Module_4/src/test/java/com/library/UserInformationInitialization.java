package com.library;

import org.openqa.selenium.WebDriver;

import com.applicationobjects.UserInformationObjects;

public class UserInformationInitialization extends UserInformationObjects{

	public UserInformationInitialization(WebDriver driver) {
		super(driver);
	}

	public void getTitle(){
		getText_UserInformation_Title();
	}
		
	public void getUserName(String Name){
		getText_UserInformation_userName().sendKeys(Name);
	}
	
	
	public void getFirstName(String firstName){
		getText_UserInformation_firstName().sendKeys(firstName);
	}
	
	public void getLastName(String lastName){
		getText_UserInformation_lastName().sendKeys(lastName);
	}
	
	public void getFatherName(String fatherName){
		getText_UserInformation_fatherName().sendKeys(fatherName);
	}
		
	public void getDateOfBirth(String dOB){
		getText_UserInformation_dOB().sendKeys(dOB);
	}
	
	public void getGender(){
		getText_UserInformation_gender().click();;
	}
	
	public void getMobileNo(String mobileNo){
		getText_UserInformation_mobileNo().sendKeys(mobileNo);
	}
	
	public void getEmailId(String emailId){
		getText_UserInformation_emailId().sendKeys(emailId);
	}
	
	public void getLandline(String landLine){
		getText_UserInformation_landLine().sendKeys(landLine);
	}
	
	public void getCommunication(){
		getText_UserInformation_communication().click();
	}
	public void getResideneceAddress(String address){
		getText_UserInformation_resideneceAddress().sendKeys(address);
	}
	
	public void getSubmitBitton(){
		getText_UserInformation_submitButton().click();
	}
	
	
}
