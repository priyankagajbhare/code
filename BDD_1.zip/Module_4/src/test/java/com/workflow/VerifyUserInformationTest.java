package com.workflow;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.library.UserInformationInitialization;

import cucumber.api.java.en.*;

public class VerifyUserInformationTest {
	
	WebDriver driver;
	String url = "file:///D:/Shubham/BDD/UserInformation.html";
	private String verificationError="";
	
	@Given("launch the browser")
	public void launch_the_browser() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\Shubham\\\\BDD\\\\SeleniumJar\\\\Driver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get(url);
	}
	
	@Then("verify the title of the page")
	public void verify_the_title_of_the_page() throws ElementNotInteractableException {
		/*UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getTitle("PERSONAL INFORMATION");*/
	}

	@Then("enter valid applicant name")
	public void enter_valid_applicant_name() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getUserName("Shubham Holey");
	}

	@Then("ensure that the alert box display the message {string} upon no clicking on the submit without entering any data in the textbox")
	public void ensure_that_the_alert_box_display_the_message_upon_no_clicking_on_the_submit_without_entering_any_data_in_the_textbox(String string) {
		
		
	}
	
	@Then("enter firstname of user")
	public void enter_firstname_of_user() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getFirstName("Shubham");
	}
	
	@Then("enter lastname of user")
	public void enter_lastname_of_user() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getLastName("Holey");
	}

	@Then("enter father name of user")
	public void enter_father_name_of_user() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getFatherName("Prakashrao");
	}

	@Then("enter Date of Birth")
	public void enter_Date_of_Birth() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getDateOfBirth("12-06-1995");
	}

	@Then("ensure {string} format for the Date of Birth")
	public void ensure_format_for_the_Date_of_Birth(String string) {
	}

	@Then("Ensure alert box displays Error message {string} for user entered date not in format {string}")
	public void ensure_alert_box_displays_Error_message_for_user_entered_date_not_in_format(String string, String string2) {
	}

	@Then("select the Gender")
	public void select_the_Gender() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getGender();
	}

	@Then("verify the Gender alert box")
	public void verify_the_Gender_alert_box() {
	}

	@Then("enter mobile number")
	public void enter_mobile_number() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getMobileNo("9879879874");
	}

	@Then("ensure	the alert box displays message")
	public void ensure_the_alert_box_displays_message() {
	}

	@Then("enter {int} digit mobile number")
	public void enter_digit_mobile_number(Integer int1) {
	}

	@Then("ensure the alert box displays the message {string}")
	public void ensure_the_alert_box_displays_the_message(String string) {
	}

	@Then("enter email Id")
	public void enter_email_Id() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getEmailId("shubham@gmail.com");
	}

	@Then("ensure the alert box for the Email Id")
	public void ensure_the_alert_box_for_the_Email_Id() {
	}

	@Then("enter the landline")
	public void enter_the_landline() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getLandline("021789452");
	}

	@Then("ensure the alert box for landline")
	public void ensure_the_alert_box_for_landline() {
	}

	@Then("select the Communication")
	public void select_the_Communication() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getCommunication();
	}

	@Then("ensure the alert box for communication")
	public void ensure_the_alert_box_for_communication() {
	}
	
	@Then("enter residence adrress")
	public void enter_residence_adrress() {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getResideneceAddress("Pune");
	}

	@Then("click the submit button")
	public void click_the_submit_button() throws InterruptedException {
		UserInformationInitialization userInfoInit = PageFactory.initElements(driver, UserInformationInitialization.class);
		userInfoInit.getSubmitBitton();
		Alert alert = driver.switchTo().alert();
        Thread.sleep(500);
        String alertMessage = alert.getText();
        alert.accept();
        Thread.sleep(500);
        if (driver.findElements(By.id("btnSubmit")).size() > 0)
            System.out.println("Alert: "+alertMessage);
		
	}

	@Then("ensure the alert box displays message {string} on entering all valid data")
	public void ensure_the_alert_box_displays_message_on_entering_all_valid_data(String string) {
		
	}

	@Then("verify the next page")
	public void verify_the_next_page() {
		
	}
	
}
