package com.workflow;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;

public class VerifyPaymentDetails {
	WebDriver driver;
	String url = "file:///D:/Shubham/BDD/PaymentDetails.html";
	private String verificationError="";
	
	@Given("verify title of page")
	public void verify_title_of_page() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\Shubham\\\\BDD\\\\SeleniumJar\\\\Driver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter the card holder name")
	public void enter_the_card_holder_name() {
	
	}

	@Then("ensure the alert box")
	public void ensure_the_alert_box() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("enter the debit card number")
	public void enter_the_debit_card_number() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("enter card expiration month")
	public void enter_card_expiration_month() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("enter card expiration year")
	public void enter_card_expiration_year() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("click on {string} button")
	public void click_on_button(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}
}
