package com.demoautomation;

import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyRegisterTitle {
	WebDriver driver;
	String url = "";
	private String verificationError="";

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		url = "http://demo.automationtesting.in/Index.html";
	}

	@Test
	public void verifyRegisterTitle() throws InterruptedException {
		String expectedTitle = "Register";
		driver.get(url);
		driver.findElement(By.id("email")).sendKeys("shubham@gmail.com");  // statement 1
		Thread.sleep(5000);
		driver.findElement(By.id("enterimg")).click();  // statement 2
		
		//Get the title of the screen
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title matched", expectedTitle, actualTitle);
		System.out.println("Title of the Application : " +actualTitle);
	}
	
	@Test
	public void verifySkipSignInButton() {
		driver.get(url);
		//Verify skip Sing-in and click
		if(driver.findElement(By.id("btn2")).isDisplayed()) {
			driver.findElement(By.id("btn2")).click();
		}
		
		//verify Automation Demo Site text is present
		String expectedText="Automation Demo Site ";
		String actualText = driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).getText();
		if(expectedText.contains(actualText))
			System.out.println("We are at Register page");
		else
			System.out.println("Register page not open");
		
		//verify Radio button
		if(driver.findElement(By.xpath("//input[@value='Male']")).isDisplayed()) {
			System.out.println("Male object is identified on screen");
		}else {
			System.out.println("Male radio object is not identified.");
		}
	}
	
	@Test
	public void fillFormWithMandatoryValueAndVerifyWebtableTitle() {
		try {
		driver.get(url);
		
		//click on submit button
		driver.findElement(By.id("btn2")).click();
		
		//Enter First Name
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Shubham");
		
		//Enter Last Name
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Holey");
		
		//Enter Email address
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("shubham12@gmail.com");
		
		//Enter phone number
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys("7527797694");
		
		//Enter the Gender
		driver.findElement(By.xpath("//input[@value='Male']")).click();
		
		//Enter the Gender
		WebElement country = driver.findElement(By.id("countries"));
		country.findElement(By.xpath("//option[@value='India']")).click();
		
		//Enter the DOB
		WebElement year = driver.findElement(By.id("yearbox"));
		year.findElement(By.xpath("//option[@value='1995']")).click();
				
		WebElement month = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		month.findElement(By.xpath("//option[@value='June']")).click();
		
		WebElement day = driver.findElement(By.id("daybox"));
		day.findElement(By.xpath("//option[@value='12']")).click();
		
		//Enter Password
		driver.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys("Shubham12");
		
		//Enter Confirm Password
		driver.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys("Shubham12");
		
		//Click on Submit Button
		driver.findElement(By.id("submitbtn")).click();
		Thread.sleep(10000);
		//Get the Title
		if(driver.getTitle().equals("Web Table")) {
			System.out.println("Form filled successfully");
		}else {
			System.out.println("Form not filled");
	}}catch(Exception e) {
		verificationError = e.getMessage();
		System.out.println("Failed because of "+verificationError);
	}
	}
	
	@After
	public void tierDown() {
		driver.quit();
		//end verification
		if(!verificationError.equals(""))
			Assert.fail();
		}
}
