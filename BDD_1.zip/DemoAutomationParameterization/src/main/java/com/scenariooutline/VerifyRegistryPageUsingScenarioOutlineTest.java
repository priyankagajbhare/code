package com.scenariooutline;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;

public class VerifyRegistryPageUsingScenarioOutlineTest {

	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate to demoautomation site")
	public void navigate_to_demoautomation_site() {
		System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter {string} username field")
	public void enter_username_field(String username) {
		driver.findElement(By.id("email")).sendKeys(username);
	}
	
	@Then("click on submit buttton")
	public void click_on_submit_buttton() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter {string} firstname field")
	public void enter_firstname_field(String firstname) {
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(firstname);
	}

	@Then("enter {string} lastname field")
	public void enter_lastname_field(String lastname) {
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastname);
	}

	@Then("enter {string} address of the user")
	public void enter_address_of_the_user(String address) {
	    driver.findElement(By.xpath("//textarea[@class='form-control ng-pristine ng-untouched ng-valid']")).sendKeys(address);
	}
	
	@Then("close the browser.")
	public void close_the_browser() {
	    driver.quit();
	}
	
}