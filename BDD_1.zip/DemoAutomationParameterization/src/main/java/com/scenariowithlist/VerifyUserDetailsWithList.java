package com.scenariowithlist;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;
import io.cucumber.datatable.DataTable;

public class VerifyUserDetailsWithList {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate to valid url")
	public void navigate_to_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	    
	}

	@Then("enter valid username")
	public void enter_valid_username(DataTable credential) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    
		//get data
	    List<List<String>> data = credential.cells();
	    driver.findElement(By.id("email")).sendKeys(data.get(0).get(0));
	}

	@Then("click the submit button")
	public void click_the_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter user detail fields")
	public void enter_user_detail_fields(DataTable userDetails) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	   
		//get List
		 List<List<String>> userData = userDetails.cells();
		
				//Enter First Name
				driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(userData.get(0).get(0));
				
				//Enter Last Name
				driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(userData.get(0).get(0));
				
				//Enter Email address
				driver.findElement(By.xpath("//input[@type='email']")).sendKeys(userData.get(0).get(0));
				
				//Enter phone number
				driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(userData.get(0).get(0));
	    
	}

	@Then("close browser")
	public void close_browser() {
		driver.quit();
	}
}
