package com.scenariowithmap;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;
import io.cucumber.datatable.DataTable;

public class VerifyUserDetailsWithMapping {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";

	@Given("navigate to the url")
	public void navigate_to_the_url()  {
		System.setProperty("webdriver.chrome.driver", "D:\\Shubham\\BDD\\SeleniumJar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);

	}

	@Then("enter the {string}")
	public void enter_the(String username) {
		driver.findElement(By.id("email")).sendKeys(username);
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter valid user details")
	public void enter_valid_user_details(DataTable dataMaps) {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
		// Map<K, List<V>>. E,K,V must be a String, Integer, Float,
		// Double, Byte, Short, Long, BigInteger or BigDecimal.
		//
		for (Map<Object, Object> values : dataMaps.asMaps(String.class, String.class)) {

			// Enter First Name
			driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(values.get("FirstName").toString());

			// Enter Last Name
			driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(values.get("LastName").toString());

			// Enter Email address
			driver.findElement(By.xpath("//input[@type='email']")).sendKeys(values.get("EmailAddress").toString());

			// Enter phone number
			driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(values.get("PhoneNumber").toString());

			// Enter Password
			driver.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys(values.get("Password").toString());

			// Enter Confirm Password
			driver.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys(values.get("ConfirmPassword").toString());

			// Click on Submit Button
			driver.findElement(By.id("Button1")).click();
			
		}

	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
}
