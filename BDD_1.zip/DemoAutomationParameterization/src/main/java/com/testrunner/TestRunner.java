package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/*//Test #1
@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\resource\\scenariowithexamplekeyword.feature", 
				  glue = "", 
				  monochrome = true, 
				  dryRun=false, 
				  plugin= {"pretty", "html:target/cucumber-html-report", 
						  "json:target/cucumber-json",
						  "pretty:target/cucumber-pretty.txt",
						  "usage:target/cucumber-usage.json",
						  "junit:target/cucumber-junitresults.xml"})*/

/*//Test #2
@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\resource\\listwithtestdata.feature", 
				  glue = "", 
				  monochrome = true, 
				  dryRun=false, 
				  plugin= {"pretty", "html:target/cucumber-html-report", 
						  "json:target/cucumber-json",
						  "pretty:target/cucumber-pretty.txt",
						  "usage:target/cucumber-usage.json",
						  "junit:target/cucumber-junitresults.xml"})*/

/*//Test #3
//Running both the above test cases
@RunWith(Cucumber.class)
@CucumberOptions(features = {
							 "src\\main\\java\\resource\\scenariowithexamplekeyword.feature", 
							 "src\\main\\java\\resource\\listwithtestdata.feature"
							},
				  glue = {"com.scenariooutline","com.scenariowithlist"}, 
				  monochrome = true, 
				  dryRun=false, 
				  plugin= {"pretty", "html:target/cucumber-html-report", 
						  "json:target/cucumber-json",
						  "pretty:target/cucumber-pretty.txt",
						  "usage:target/cucumber-usage.json",
						  "junit:target/cucumber-junitresults.xml"})*/

//Test #4
@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\resource\\mapwithtestdata.feature", 
				  glue = "com.scenariowithmap", 
				  monochrome = true, 
				  dryRun=true, 
				  plugin= {"pretty", "html:target/cucumber-html-report", 
						  "json:target/cucumber-json",
						  "pretty:target/cucumber-pretty.txt",
						  "usage:target/cucumber-usage.json",
						  "junit:target/cucumber-junitresults.xml"},
				  strict=false             //if the value is "true" then it will fail to run
				  )

public class TestRunner {

}
