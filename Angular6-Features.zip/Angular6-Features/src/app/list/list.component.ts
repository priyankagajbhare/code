import { Component, OnInit } from '@angular/core';
import { AlbumService } from '../album.service';
import { Album } from 'src/viewmodel/album';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  albums : Album[]=[];
  constructor(private _eventlist: AlbumService) { }
  deleteFromService(event: Album){
    this._eventlist.deleteEvent(event);
  }
  ngOnInit() {
    this.albums=this._eventlist.getEvent();
  }
}
