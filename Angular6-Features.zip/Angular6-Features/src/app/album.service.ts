import { Injectable } from '@angular/core';
import { Album } from 'src/viewmodel/album';

@Injectable({
  providedIn: 'root'
})
export class AlbumService {
  //Array of type Album
  albums: Album[] =[
    {
      id: 1101, title:'Lemonade', artist:'Beyonce', price:249
    } 
   ];
   
  constructor() {}

  getEvent():Album[] {
    return this.albums;
  } 
  putAlbum(event1: Album)
  {
      this.albums.push(event1);
  }

  // Function to delete the album
  deleteEvent(event: Album) {
    let i = this.albums.indexOf(event)
    this.albums.splice(i,1);
  }
}
