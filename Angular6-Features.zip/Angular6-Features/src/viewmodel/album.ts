//Album class
export class Album {
    id: number;
    title: string;
    artist: string;
    price: number;
}