package com.cg.parallelproject.bean;

import javax.persistence.*;

@Entity
@Table(name = "customer")

public class Customer {
	@Id
	@Column(name = "accno")
	private long AcNO;
	@Column(name = "pin")
	private int pin;
	@Column(name = "name")
	private String name;

	public Customer(long AcNO, int pin, String name, long phone_number, String address, int balance) {
		this.AcNO = AcNO;
		this.pin = pin;
		this.name = name;
		this.phone_number = phone_number;
		this.address = address;
		this.balance = balance;
	}

	@Column(name = "phonenumber")
	private long phone_number;
	@Column(name = "address")
	private String address;
	@Column(name = "balance")
	private int balance = 500;

	public long getAcNO() {
		return AcNO;
	}

	public void setAcNO(long acNO) {
		AcNO = acNO;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(long phone_number) {
		this.phone_number = phone_number;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [AcNO=" + AcNO + ", pin=" + pin + ", name=" + name + ", phone_number=" + phone_number
				+ ", address=" + address + ", balance=" + balance + "]";
	}

	public Customer() {

	}

}
