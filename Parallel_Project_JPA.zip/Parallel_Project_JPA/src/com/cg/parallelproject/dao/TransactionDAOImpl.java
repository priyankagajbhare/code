package com.cg.parallelproject.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.util.JPAUtil;

public class TransactionDAOImpl implements iTransactionDAO {
	EntityManager em = null;
	EntityTransaction tran = null;

	public TransactionDAOImpl() {
		em = JPAUtil.getEntitymanager();
		tran = em.getTransaction();
	}

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		tran.begin();
		em.persist(trans);
		tran.commit();

		return trans;
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {
		TypedQuery tq = em.createQuery("Select tran from Transaction tran where acno='" + acno + "", Transaction.class);
		ArrayList cusList = (ArrayList) tq.getResultList();
		return cusList;
	}
}