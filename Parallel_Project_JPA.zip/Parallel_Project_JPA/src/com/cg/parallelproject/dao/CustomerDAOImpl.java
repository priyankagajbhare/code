package com.cg.parallelproject.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.util.JPAUtil;

public class CustomerDAOImpl<Transaction> implements iCustomerDAO {
	EntityManager em = null;
	EntityTransaction trans = null;

	public CustomerDAOImpl() {
		em = JPAUtil.getEntitymanager();
		trans = em.getTransaction();
	}

	@Override
	public Customer createAccount(Customer cust) throws CustomerException {
		trans.begin();
		em.persist(cust);
		trans.commit();
		System.out.println(cust);
		System.out.println("Account Successfully created");

		return cust;

	}

	@Override
	public Customer AddMoney(long acc, int pin, int balance) throws CustomerException {
		Customer cust2 = em.find(Customer.class, acc);

		int currentbalance = cust2.getBalance();
		int totalbalance = currentbalance + balance;
		cust2.setBalance(totalbalance);
		trans.begin();
		em.merge(cust2);
		trans.commit();
		System.out.println(totalbalance);
		return cust2;
	}

	@Override
	public Customer TransferMoney(long acc, long acc1, int balance) throws CustomerException {
		Customer cus = em.find(Customer.class, acc);
		Customer cus1 = em.find(Customer.class, acc1);

		if (cus.getBalance() < balance) {
			System.out.println("Enter amount less than  " + cus.getBalance());
		} else {
			int acc1currentbalance = cus.getBalance() - balance;
			cus.setBalance(acc1currentbalance);
			trans.begin();
			em.merge(cus);
			trans.commit();
			int acc2currentbalance = cus1.getBalance() + balance;
			cus1.setBalance(acc2currentbalance);
			trans.begin();
			em.merge(cus1);
			trans.commit();
		}
		return cus1;
	}

	@Override
	public ArrayList<Customer> getAccountList() throws CustomerException {
		// TODO Auto-generated method stub
		TypedQuery tq = em.createQuery("Select cus from Customer cus", Customer.class);
		ArrayList cusList = (ArrayList) tq.getResultList();
		return cusList;
	}

	@Override
	public Customer getAccount(long acc) throws CustomerException {
		Customer cust = em.find(Customer.class, acc);
		return cust;

	}

	@Override
	public Customer withdraw(long acc, int amount) throws CustomerException {
		Customer cus = em.find(Customer.class, acc);
		int balance = cus.getBalance();
		int availbalance = balance - amount;
		cus.setBalance(availbalance);
		trans.begin();
		em.merge(cus);
		trans.commit();
		return cus;

	}

}
