package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import com.capgemini.dto.Employee;

public class EmployeeDB {
	// IN - Memory Database
	ArrayList<Employee> list = new ArrayList<Employee>();

	public boolean addEmployee(Employee emp) {
		boolean result = list.add(emp);
		return result;
	}

	public List<Employee> getAllEmployees() {
		return list;
	}

	public boolean deleteEmployee(int empId) {
		Iterator<Employee> itr = list.iterator();
		while (itr.hasNext()) {
			Employee emp = itr.next();
			if (emp.getEmpId() == empId) {
				// itr.remove();
				list.remove(emp);
				return true;

			}
		}
		return false;
	}

	public Employee getEmployee(int empId) {
		Enumeration<Employee> enumeration = Collections.enumeration(list);
		while(enumeration.hasMoreElements()) {
			Employee emp = enumeration.nextElement();
			if(empId == emp.getEmpId()) {
				return emp;
			}
		}
		return null;
	}
	public double showPaySlip(int empId) 
	{
		Iterator<Employee> itr = list.iterator();
		while (itr.hasNext()) 
		{
			Employee emp = itr.next();
			if (emp.getEmpId() == empId) 
			{
				return emp.getEmpSalary();
			}
		}
		return 0.0;

	}
}
