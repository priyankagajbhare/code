package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	Map<Integer, Employee> database = new HashMap<>();
	
	@Override
	public boolean createEmployee(Employee emp) {
		return false;
	}

	@Override
	public Employee readEmployee(int empId) {

		return null;
	}

	@Override
	public boolean updateEmployeeSalary(int empId, double updatedSalay) {
		return false;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		return false;
	}
	

}
