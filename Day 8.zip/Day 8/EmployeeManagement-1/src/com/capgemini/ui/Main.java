package com.capgemini.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.dao.EmployeeDB;
import com.capgemini.dto.Employee;

public class Main {
	private static Scanner sc;
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		EmployeeDB db = new EmployeeDB();
		loop:
		while (true) {
			System.out.println("1. Add Employee Details");
			System.out.println("2. View All Employees");
			System.out.println("3. Delete Employee Details.");
			System.out.println("4. View Salary Slip");
			System.out.println("5. Exit.");

			System.out.println("Enter Your Choice:");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter empId: ");
				int id = sc.nextInt();
				System.out.println("Enter empName: ");
				String name = sc.next();
				System.out.println("Enter empSalary: ");
				double salary = sc.nextDouble();
				Employee emp = new Employee(id, name, salary);

				boolean result = db.addEmployee(emp);
				if (result) {
					System.out.println("Employee added.");
				} else {
					System.out.println("Employee not added.");
				}
				db.addEmployee(emp);

				break;
			case 2:
				List<Employee> list = db.getAllEmployees();
				System.out.println(list);
				break;
			case 3:
				System.out.println("Enter the empId you want to delete:");
				id = sc.nextInt();
				result = db.deleteEmployee(id);
				if(result) {
					System.out.println("Employee deleted.");
				}else {
					System.out.println("Employee not deleted.");
				}
				break ;
				
			case 4:
				System.out.println("Enter the empId, if you want to see the Salary Slip:");
				id = sc.nextInt();
				salary = db.showPaySlip(id);
				if(salary == 0.0)
				{
					System.out.println("Employee Not Found");					
				}else
				{
					System.out.println("Employee Salary Slip is: "+salary);
				}
				break ;
				
			case 5:

				break loop;
			}
			
		}
	}

}
