package com.capgemini;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<Object> list = new ArrayList<Object>(); 
		list.add(new Integer(1000));
		list.add("Capgemini");
		list.add("1000.2");
		list.add(1000);
		int a = 10000;
		list.add(a);
				
		list.add(1, "New Element");
		list.remove(1);
	
		System.out.println("Capacity: "+list.size());
		System.out.println(list.get(1));
		
//		System.out.println(list.toString());
		for(Object obj : list) {
			System.out.println(obj);
		}
	}

}
