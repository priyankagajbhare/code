package com.capgemini;

import java.util.HashSet;

public class EmployeeMain {
	public static void main(String[] args) {
		HashSet<Employee> set1 = new HashSet<Employee>();
		Employee e1 = new Employee(1001, "ABC", 15100);
		Employee e2 = new Employee(1001, "ABC", 15100);
		set1.add(e1);
		set1.add(e2);
		System.out.println(set1);
		System.out.println("Hashcode of e1 = "+e1.hashCode());
		System.out.println("Hashcode of e2 = "+e2.hashCode());

		
		HashSet<Integer> set2 = new HashSet<Integer>();
		Integer i1 = new Integer(1000);
		Integer i2 = new Integer(1000);
		set2.add(i1);
		set2.add(i2);
		System.out.println(set2);
		System.out.println("Hashcode of i1 = "+i1.hashCode());
		System.out.println("Hashcode of i2 = "+i2.hashCode());

	}
}
