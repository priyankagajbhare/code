package com.capgemini;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<Object> set = new HashSet<Object>();
		set.add(100);
		Integer i = new Integer(100);
		Integer i1 = new Integer(100);

		set.add(i);
		set.add("A");
		set.add("B");
		set.add("C");
		set.add("D");
		set.add("E");
		set.add("C");
		set.add("F");

		System.out.println(set.add("C"));
		System.out.println(set.add(i1));
		//System.out.println(set);
		Iterator<Object> itr = set.iterator();
		while(itr.hasNext()) {
			Object obj = itr.next();
			System.out.println(obj);
		}
	}

}
