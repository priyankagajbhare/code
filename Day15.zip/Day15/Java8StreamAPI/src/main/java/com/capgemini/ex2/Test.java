package com.capgemini.ex2;

import java.util.Arrays;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		Integer arrInteger[] = new Integer[] { 10, 15, 64, 5, 65, 100, 20, 25 };
		Stream<Integer> result = Arrays.stream(arrInteger);

		long evencount = result
				.filter((Integer element) -> element % 2 == 0)
				.count();
		System.out.println("Even number count: " + evencount);

	}

}
