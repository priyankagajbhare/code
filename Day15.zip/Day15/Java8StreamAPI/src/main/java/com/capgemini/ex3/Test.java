package com.capgemini.ex3;

import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<Integer> listInteger = Arrays.asList(10, 15, 9, 8, 9, 5, 80, 14, 18, 75, 64, 80, 5);
		listInteger
			.stream()
			.distinct()
			.filter((Integer e) -> e % 2 == 1 )
			.forEach((Integer e) -> System.out.println(e));
	}

}
