package com.capgemini.ex1;

import java.util.Arrays;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		Stream<Integer> result = Stream.of (2,5,10,44,77,20,45,32);
		long c = result.count();
		System.out.println("Number of elements present: "+c);
		
		Integer arrInteger[] = new Integer[] {2,5,10,44,77,20,45,32};
		Stream<Integer> result2 = Arrays.stream(arrInteger);
		result2.forEach(element -> System.out.print(element*2 + " "));
	}

}
