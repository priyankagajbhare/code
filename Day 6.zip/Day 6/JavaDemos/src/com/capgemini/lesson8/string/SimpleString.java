package com.capgemini.lesson8.string;

class SimpleString  {

   public static void main(String args[])  {

     // Simple String Operations
      char c[] = {'J', 'a', 'v', 'a'};
      String s1 = new String(c);
      String s2 = new String(s1); 

      System.out.println(s1);
      System.out.println(s2);
      System.out.println(s2.hashCode());
      System.out.println(s1.hashCode());
      System.out.println("Length of string: "+s1.length());
      System.out.println("index of v is: "+s2.indexOf('v'));



      // Using concatenation to prevent long lines.
      String longStr = "This could have been "
      		+ "a very long line that would have "
      		+ "wrapped around. But string "
      		+ "concatenation prevents this.";

       System.out.println(longStr);
       String stringArray[] = longStr.split("\\. ");
       for(String s : stringArray ){
    	   System.out.println(s);
       }
   }
}
