package com.capgemini.lesson13;

@FunctionalInterface
public interface MaxFinder {
	
	public int maximum(int num1,int num2);
	
}
