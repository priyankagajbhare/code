package com.capgemini.lesson10.runnable;

public class MyRunnable implements Runnable {
	private int number;

	public MyRunnable() {
	}

	public MyRunnable(int n) {
		this.number = n;
	}

	@Override
	public synchronized void run() {

		System.out.println("Thread start:::" + Thread.currentThread().getName());

		for (int row = 2; row < number; row++) {
			for (int num = 1; num <= 10; num++)
				System.out.print(row * num + " ");

			System.out.println("");
		}

		System.out.println("Thread ended:::" + Thread.currentThread().getName());

	}

}
