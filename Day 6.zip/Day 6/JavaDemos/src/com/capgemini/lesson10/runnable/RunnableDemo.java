package com.capgemini.lesson10.runnable;

public class RunnableDemo {

	public static void main(String[] args) {
		MyRunnable task = new MyRunnable(5);
		Thread fstThread = new Thread(task);
		fstThread.start();

		Thread secondThread = new Thread(task);
		secondThread.start();
	}

}
