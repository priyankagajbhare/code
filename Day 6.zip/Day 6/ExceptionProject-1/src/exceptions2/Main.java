package exceptions2;

import java.util.Scanner;

public class Main {
//	static{
//		System.out.println("Static block executed");
//	}
	
	public static void getDetails(int age) {
		if(age >= 0 && age <= 100)
		{
			System.out.println("Valid Age = "+age);
		}
		else
		{
			AgeException e = new AgeException(age);
			throw e;
		}
	}
	public static void main(String[] args) {
		System.out.println("Start of the main.");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Age.");
		int age = sc.nextInt();
		Main.getDetails(age);
			System.out.println("End of the main.");
	}

}
