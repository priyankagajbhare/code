package exceptions2;

public class AgeException extends RuntimeException {
	static{
		System.out.println("Static block executed");
	}
	private int age;
	public AgeException(int age){
		this.age = age;
	}
	@Override
	public String toString(){
		return "Invallid Age= "+age;
	}
}
