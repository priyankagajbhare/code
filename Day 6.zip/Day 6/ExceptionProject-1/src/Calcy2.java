public class Calcy2
{
	public static void main(String param[])
	{
		System.out.println("Start of the program");
		int number1, number2, sum;
		try
		{// open db connection
			number1 = Integer.parseInt(param[0]);
			number2 = Integer.parseInt(param[1]);
			sum = number1 + number2;
			System.out.println("Sum of numbers "+sum);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.err.println("Please pass two command line arguments.");
		}
		catch(NumberFormatException e)
		{
			System.err.println("Please pass two interger parameters.");
		}
		finally
		{// close db connection
			System.out.println("Finally block will be execute always.");
		}
		System.out.println("End of the program");
	}
}