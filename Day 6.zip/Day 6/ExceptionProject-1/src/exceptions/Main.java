package exceptions;

import java.util.Scanner;

public class Main {
	public static void getDetails(int age) throws AgeException {
		if(age >= 0 && age <= 100)
		{
			System.out.println("Valid Age = "+age);
		}
		else
		{
			AgeException e = new AgeException(age);
			throw e;
		}
	}
	public static void main(String[] args) throws AgeException {
		System.out.println("Start of the main.");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Age.");
		int age = sc.nextInt();
		try
		{
		Main.getDetails(age);
		}catch (AgeException e){ 
			System.out.println((e.toString()));
		}
			System.out.println("End of the main.");
	}

}
