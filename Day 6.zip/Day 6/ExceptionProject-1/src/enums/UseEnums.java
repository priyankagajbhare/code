package enums;

enum Weekdays{
	MON, TUE, WED, THU, FRI;
}
public class UseEnums {
	public static void main(String[] args) {
		
		System.out.println(Weekdays.MON);
		System.out.println(Weekdays.TUE);
		System.out.println(Weekdays.WED);
		}
}
