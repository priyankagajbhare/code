package snippet;

public class Snippet {
	private static final String c = null;
}

