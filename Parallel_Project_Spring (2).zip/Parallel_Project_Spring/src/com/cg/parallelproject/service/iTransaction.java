package com.cg.parallelproject.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.exception.CustomerException;

public interface iTransaction {
	public Transaction addtransaction(Transaction trans) throws CustomerException;
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException ;
}
