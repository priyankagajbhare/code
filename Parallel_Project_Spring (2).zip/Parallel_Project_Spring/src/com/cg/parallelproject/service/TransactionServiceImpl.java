package com.cg.parallelproject.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.dao.TransactionDAOImpl;
import com.cg.parallelproject.dao.iTransactionDAO;
import com.cg.parallelproject.exception.CustomerException;

@Repository
@Transactional
public class TransactionServiceImpl implements iTransaction {

	@Autowired
	iTransactionDAO dao = null;

	public iTransactionDAO getDao() {
		return dao;
	}

	public void setDao(iTransactionDAO dao) {
		this.dao = dao;
	}

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		return dao.addtransaction(trans);
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {
		return dao.gettransaction(acno);
	}

}
