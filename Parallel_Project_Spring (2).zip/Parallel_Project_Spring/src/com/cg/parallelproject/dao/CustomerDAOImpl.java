package com.cg.parallelproject.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.exception.CustomerException;

@Repository
@Transactional
public class CustomerDAOImpl<Transaction> implements iCustomerDAO {

	@PersistenceContext
	EntityManager em = null;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public Customer createAccount(Customer cust) throws CustomerException {
		em.persist(cust);
		System.out.println(cust);
		System.out.println("Account Successfully created");

		return cust;

	}

	@Override
	public Customer AddMoney(long acc, int pin, int balance) throws CustomerException {
		Customer cust2 = em.find(Customer.class, acc);

		int currentbalance = cust2.getBalance();
		int totalbalance = currentbalance + balance;
		cust2.setBalance(totalbalance);

		System.out.println(totalbalance);
		return cust2;
	}

	@Override
	public Customer TransferMoney(long acc, long acc1, int balance) throws CustomerException {
		Customer cus = em.find(Customer.class, acc);
		Customer cus1 = em.find(Customer.class, acc1);

		if (cus.getBalance() < balance) {
			System.out.println("Enter amount less than  " + cus.getBalance());
		} else {
			int acc1currentbalance = cus.getBalance() - balance;
			cus.setBalance(acc1currentbalance);

			int acc2currentbalance = cus1.getBalance() + balance;
			cus1.setBalance(acc2currentbalance);

		}
		return cus1;
	}

	@Override
	public ArrayList<Customer> getAccountList() throws CustomerException {
		TypedQuery tq = em.createQuery("Select cus from Customer cus", Customer.class);
		ArrayList cusList = (ArrayList) tq.getResultList();
		return cusList;
	}

	@Override
	public Customer getAccount(long acc) throws CustomerException {
		Customer cust = em.find(Customer.class, acc);
		return cust;

	}

	@Override
	public Customer withdraw(long acc, int amount) throws CustomerException {
		Customer cus = em.find(Customer.class, acc);
		int balance = cus.getBalance();
		int availbalance = balance - amount;
		cus.setBalance(availbalance);

		return cus;

	}

}
