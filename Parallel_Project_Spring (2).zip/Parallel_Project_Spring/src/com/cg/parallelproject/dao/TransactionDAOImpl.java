package com.cg.parallelproject.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.exception.CustomerException;

@Repository
@Transactional
public class TransactionDAOImpl implements iTransactionDAO {
	@PersistenceContext
	EntityManager em = null;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {

		em.persist(trans);

		return trans;
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {

		TypedQuery tq = em.createQuery("Select tran from Transaction tran where acno='" + acno + "'",
				Transaction.class);
		ArrayList cusList = (ArrayList) tq.getResultList();
		return cusList;
	}
}