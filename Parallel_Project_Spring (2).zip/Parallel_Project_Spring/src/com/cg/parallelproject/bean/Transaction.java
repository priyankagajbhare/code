package com.cg.parallelproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "transactionid")
	private int transactionID;
	@Column(name = "type")
	private String type;

	@Column(name = "acno")
	private long acno;
	@Column(name = "amount")
	private int amount;

	public double getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getAcno() {
		return acno;
	}

	public void setAcno(long acno2) {
		this.acno = acno2;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionID=" + transactionID + ", type=" + type + ", acno=" + acno + ", amount="
				+ amount + "]";
	}

	public Transaction(int transactionID, String type, long acno, int amount) {
		super();
		this.transactionID = transactionID;
		this.type = type;
		this.acno = acno;
		this.amount = amount;
	}

	public Transaction() {
		super();
	}

}
