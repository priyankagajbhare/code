package com.cg.parallelproject.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.omg.IOP.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.service.iCustomerService;
import com.cg.parallelproject.service.iTransaction;

import sun.print.resources.serviceui;

@Controller
public class OperationController {

	@Autowired
	iCustomerService custser = null;

	@Autowired
	iTransaction transser = null;

	public iCustomerService getCustser() {
		return custser;
	}

	public void setCustser(iCustomerService custser) {
		this.custser = custser;
	}

	@RequestMapping(value = "AddMoney")
	public String AddMoney(@RequestParam("AcNo") Long id, Model model) {
		try {
			Customer cus = custser.getAccount(id);
			model.addAttribute("name", cus.getName());
			model.addAttribute("account", cus.getAcNO());
			model.addAttribute("balance", cus.getBalance());
			model.addAttribute("userObj", cus);
		} catch (CustomerException e) {
			e.printStackTrace();
		}
		return "Money";
	}

	@RequestMapping(value = "WithdrawMoney")
	public String Withdrawn(@RequestParam("AcNo") Long id, Model model) {

		try {
			Customer cus = custser.getAccount(id);
			model.addAttribute("name", cus.getName());
			model.addAttribute("account", cus.getAcNO());
			model.addAttribute("balance", cus.getBalance());
			model.addAttribute("userObj", cus);
		} catch (CustomerException e) {
			e.printStackTrace();
		}
		return "Withdraw";
	}

	@RequestMapping(value = "ShowBalance")
	public String ShowBalance(@RequestParam("AcNo") Long id, Model model) {

		try {
			Customer cust = custser.getAccount(id);
			model.addAttribute("UserListObj", cust);
			String msg = cust.getName() + " " + "your balance is:" + " " + cust.getBalance();
			model.addAttribute("balance", msg);
		} catch (CustomerException e) {
			e.printStackTrace();
		}

		return "ShowBalance";
	}

	@RequestMapping(value = "PrintTrans")
	public String transaction(@RequestParam("AcNo") Long id, Model model) {
		try {
			Customer cstr = new Customer();
			ArrayList<Transaction> clist = transser.gettransaction(id);
			model.addAttribute("list", clist);
			String msg = "Your transactions are";
			model.addAttribute("msgObj", msg);
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "Transaction";
	}

	@RequestMapping(value = "TransferMoney")
	public String transferMoney(@RequestParam("AcNo") Long id, Model model) {
		try {
			Customer cst = custser.getAccount(id);
			model.addAttribute("userObj", cst);
			model.addAttribute("name", cst.getName());
		} catch (CustomerException e) {
			e.printStackTrace();
		}

		return "Transfer";
	}

}
