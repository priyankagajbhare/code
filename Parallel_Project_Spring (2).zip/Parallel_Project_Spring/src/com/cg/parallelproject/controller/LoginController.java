package com.cg.parallelproject.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.service.iCustomerService;

@Controller

public class LoginController {
	@Autowired
	iCustomerService custser = null;

	public iCustomerService getCustser() {
		return custser;
	}

	public void setCustser(iCustomerService custser) {
		this.custser = custser;
	}

	@RequestMapping(value = "/Login")
	public String LoginPage(Model model) {

		Customer cust = new Customer();
		model.addAttribute("loginObj", cust);
		return "Login";
	}

	@RequestMapping(value = "validateUser", method = RequestMethod.POST)
	public String ValidateUser(@ModelAttribute("loginObj") @Valid Customer cus, BindingResult result, Model model) {

		try {
			Customer cust1;
			cust1 = custser.getAccount(cus.getAcNO());

			if (cust1 != null) {
				if (cust1.getPin() == (cus.getPin())) {
					String msg = "Welcome to payment wallet " + cust1.getName();
					model.addAttribute("account", cust1.getAcNO());
					model.addAttribute("MsgObj", msg);
					return "OperationPage";
				} else {
					String msg = "Please enter valid pin";
					model.addAttribute("MsgObj", msg);
					return "Login";
				}

			}
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String msg = "Plaese create your account";
		model.addAttribute("MsgObj", msg);
		return "Home";

	}
}
