package com.cg.parallelproject.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.service.iCustomerService;

@Controller

public class WelcomeController {
	@Autowired
	iCustomerService custser = null;

	@RequestMapping(value = "/ShowHomePage")
	public String HomePage() {
		return "Home";
	}

	@RequestMapping(value = "Back")
	public String BackPage() {
		return "OperationPage";
	}

	@RequestMapping(value = "/CreateAccount")

	public String CreateAccount(Model model) {
		Customer cust = new Customer();
		model.addAttribute("AccountObj", cust);
		return "Account";
	}

	@RequestMapping(value = "AccountDetails")
	public String addUser(@ModelAttribute("AccountObj") @Valid Customer cust, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "Account";
		} else {
			Customer cust1 = null;
			try {
				cust1 = custser.createAccount(cust);
				model.addAttribute("accnum", cust1.getAcNO());
				model.addAttribute("name", cust1.getName());
				model.addAttribute("address", cust1.getAddress());
				model.addAttribute("mobnum", cust1.getPhone_number());
				model.addAttribute("balance", cust1.getBalance());
			} catch (CustomerException e) {
				e.printStackTrace();
			}

			return "Details";
		}

	}
}
