package com.cg.parallelproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.bean.Transaction;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.service.iCustomerService;
import com.cg.parallelproject.service.iTransaction;

@Controller
public class FunctionController {

	@Autowired
	iCustomerService custser = null;

	@Autowired
	iTransaction transser = null;

	public iTransaction getTransser() {
		return transser;
	}

	public void setTransser(iTransaction transser) {
		this.transser = transser;
	}

	public iCustomerService getCustser() {
		return custser;
	}

	public void setCustser(iCustomerService custser) {
		this.custser = custser;
	}

	@RequestMapping(value = "/AddMoneyfunction")
	public String AddMoney(@ModelAttribute("userObj") Customer cus, BindingResult result, Model model) {

		try {
			Customer cust = custser.AddMoney(cus.getAcNO(), cus.getPin(), cus.getAmmount());
			Transaction trans = new Transaction();
			trans.setAcno(cus.getAcNO());
			trans.setAmount(cus.getAmmount());
			trans.setType("MoneyAdd");
			transser.addtransaction(trans);
			String moneyadd = cust.getName() + " " + "money is successfully added in your account";
			model.addAttribute("moneyadd", moneyadd);
			model.addAttribute("account", cust.getAcNO());
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "OperationPage";

	}

	@RequestMapping(value = "WithdrawMoneyfunction")
	public String withdrawMoney(@ModelAttribute("userObj") Customer cus, BindingResult result, Model model) {

		try {
			Customer cust = custser.withdraw(cus.getAcNO(), cus.getAmmount());
			Transaction trans = new Transaction();
			trans.setAcno(cus.getAcNO());
			trans.setAmount(cus.getAmmount());
			trans.setType("MoneyWithdrawn");
			transser.addtransaction(trans);
			String moneywithdraw = cust.getName() + " " + "money is successfully withdraw from your account";
			model.addAttribute("moneywithdraw", moneywithdraw);
			model.addAttribute("account", cust.getAcNO());
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "OperationPage";

	}

	@RequestMapping(value = "Transfer")
	public String Transaction(@ModelAttribute("userObj") Customer cus, BindingResult result, Model model) {

		try {
			Transaction trans = new Transaction();
			Customer cust = custser.TransferMoney(cus.getAcNO(), cus.getAccountNumber(), cus.getAmmount());
			String deposit = "Ammount is transfer to " + cus.getAccountNumber() + " " + " account";
			model.addAttribute("deposit", deposit);
			model.addAttribute("account", cus.getAcNO());
			trans.setAcno(cus.getAcNO());
			trans.setAmount(cus.getAmmount());
			trans.setType("Transfer");
			transser.addtransaction(trans);

		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "OperationPage";

	}
}
