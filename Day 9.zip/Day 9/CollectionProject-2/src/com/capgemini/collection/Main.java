package com.capgemini.collection;

import java.util.Iterator;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		TreeSet<Employee> ts = new TreeSet<>();
		
		Employee e1 = new Employee(102, "abc", 1000);
		Employee e2 = new Employee(101, "xyz", 2000);
		Employee e3 = new Employee(103, "xyz", 2000);

		ts.add(e1);
		ts.add(e2);
		ts.add(e3);

		Iterator<Employee> itr = ts.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
//			Employee emp = itr.next();
//			System.out.println(emp);
		}
	}

}
