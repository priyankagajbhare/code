package com.capgemini.collection2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {
	public static void main(String[] args) {
		ArrayList<Employee> list = new ArrayList<>();
		
		Employee e1 = new Employee(101, "Talha", 1000);
		Employee e2 = new Employee(102, "Shubham", 3000);
		Employee e3 = new Employee(103, "Aman", 2000);

		list.add(e1);
		list.add(e2);
		list.add(e3);
		
		Collections.sort(list, new SalarySorter());
		System.out.println(list);
		Collections.sort(list, new NameSorter());
		System.out.println(list);
	}

}
class SalarySorter implements Comparator<Employee>{
	@Override
	public int compare(Employee o1, Employee o2) {
		if (o1.getEmpSalary() > o2.getEmpSalary()) {
			return 1;
		}else {
			return -1;
		}
	}
}
class NameSorter implements Comparator<Employee>{
	@Override
	public int compare(Employee o1, Employee o2) {
			return o1.getEmpName().compareTo(o2.getEmpName());
	}
}
