package com.cg.parallelproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.parallelproject.bean.Customer;
import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.util.DButil;

public class CustomerDAOImpl implements iCustomerDAO {

	Connection conn = null;

	public CustomerDAOImpl() {

	}

	@Override
	public Customer createAccount(Customer cust1) throws CustomerException {

		conn = DButil.getConnection();
		System.out.println(cust1);
		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO customer VALUES(?,?,?,?,?)");
			pst.setLong(1, cust1.getAcNO());
			pst.setInt(2, cust1.getPin());
			pst.setString(3, cust1.getName());
			pst.setLong(4, cust1.getPhone_number());
			pst.setString(5, cust1.getAddress());
			pst.setInt(6, cust1.getBalance());
			System.out.println("Account Successfully created");
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new CustomerException("Problem in inserting product details" + e.getMessage());
		}

		return cust1;

	}

	@Override
	public Customer AddMoney(long acc, int pin, int balance) throws CustomerException {
		String sql = "select * from customer where accno=?";
		Customer cust1 = null;
		conn = DButil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, acc);
			ResultSet rst1 = pst.executeQuery();
			if (rst1.next()) {
				cust1 = new Customer();
				cust1.setAcNO(rst1.getLong("accno"));
				cust1.setAddress(rst1.getString("address"));
				cust1.setBalance(rst1.getInt("balance"));
				cust1.setName(rst1.getString("name"));
				cust1.setPhone_number(rst1.getLong("phonenumber"));
				cust1.setPin(rst1.getInt("pin"));
				PreparedStatement ps1 = conn.prepareStatement("update customer set balance=? where accno=?");
				int afterbalance = cust1.getBalance() + balance;
				System.out.println(afterbalance);
				ps1.setLong(2, acc);
				ps1.setInt(1, afterbalance);
				int count1 = ps1.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return cust1;
	}

	@Override
	public Customer TransferMoney(long acc, long acc1, int balance) throws CustomerException {
		String sql = "SELECT * from customer WHERE accno=?";
		Customer customer = null;
		Customer cust1 = null;
		conn = DButil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, acc);
			ResultSet rst = pst.executeQuery();
			PreparedStatement pst1 = conn.prepareStatement(sql);
			pst1.setLong(1, acc1);
			ResultSet rst1 = pst1.executeQuery();
			if (rst.next()) {
				cust1 = new Customer();
				cust1.setBalance(rst.getInt("balance"));
				PreparedStatement ps1 = conn.prepareStatement("update customer set balance=? where accno=?");
				int afterbalance = cust1.getBalance() - balance;

				ps1.setLong(2, acc);
				ps1.setInt(1, afterbalance);
				int count1 = ps1.executeUpdate();
				if (rst1.next()) {
					customer = new Customer();
					customer.setBalance(rst1.getInt("balance"));
					PreparedStatement ps2 = conn.prepareStatement("update customer set balance=? where accno=?");
					int afterbalance1 = customer.getBalance() + balance;
					System.out.println(afterbalance1);
					ps2.setLong(2, acc1);
					ps2.setInt(1, afterbalance1);
					int count2 = ps2.executeUpdate();
					System.out.println(count2);

				}
			}

		} catch (SQLException e) {

			throw new CustomerException(e.getMessage());
		}
		return cust1;
	}

	@Override
	public ArrayList<Customer> getAccountList() throws CustomerException {
		ArrayList<Customer> cust1 = new ArrayList<Customer>();
		conn = DButil.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery("select accno,name,address from customer");
			while (rst.next()) {
				Customer cust = new Customer();
				cust.setAcNO(rst.getLong("accno"));
				cust.setName(rst.getString("name"));
				cust.setAddress(rst.getString("address"));
				cust.setBalance(rst.getInt("balance"));
				cust1.add(cust);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return cust1;
	}

	@Override
	public Customer getAccount(long acc) throws CustomerException {
		//String sql = "SELECT * from customer WHERE accno=?";
		Customer cust1 = null;
		conn = DButil.getConnection();
		
		try {
			System.out.println(acc);
			PreparedStatement pst = conn.prepareStatement("SELECT * from customer WHERE accno=?");
			pst.setLong(1, acc);
			ResultSet rst = pst.executeQuery();
			if (rst.next()) {
				cust1 = new Customer();
				cust1.setAcNO(rst.getLong("accno"));
				cust1.setName(rst.getString("name"));
				cust1.setAddress(rst.getString("address"));
				cust1.setPhone_number(rst.getLong("phoneno"));
				cust1.setPin(rst.getShort("pin"));
				//cust1.setBalance(rst.getInt("balance"));
			}
		} catch (SQLException e) {

			throw new CustomerException(e.getMessage());
		}
		return cust1;
	}

	@Override
	public Customer withdraw(long acc, int amount) throws CustomerException {
		String sql = "SELECT * from customer WHERE accno=?";
		Customer customer = null;
		conn = DButil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, acc);
			ResultSet rst = pst.executeQuery();
			if (rst.next()) {
				customer = new Customer();
				customer.setBalance(rst.getInt("balance"));
				if (customer.getBalance() > amount) {
					int currentbalance = customer.getBalance() - amount;
					PreparedStatement ps = conn.prepareStatement("update customer set balance=? where accno=?");
					ps.setLong(2, acc);
					ps.setInt(1, currentbalance);
					int count = ps.executeUpdate();
					if (count == 0)
						throw new CustomerException("Customer not found");

				} else
					throw new CustomerException("Enter amount  less than  " + customer.getBalance());
			}
		} catch (SQLException e) {

			throw new CustomerException(e.getMessage());
		}
		return customer;
	}

}
