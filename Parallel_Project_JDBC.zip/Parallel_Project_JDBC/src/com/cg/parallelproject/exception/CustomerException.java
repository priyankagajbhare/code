package com.cg.parallelproject.exception;

public class CustomerException extends Exception {
	public CustomerException(){
		
	}
	public CustomerException(String s ) {
		super(s);
	}
}
