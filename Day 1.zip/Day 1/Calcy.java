public class Calcy
{
	public static void main(String param[])
	{
		int number1, number2, sum;
		number1 = 1000;
		number2 = 2000;
		sum = number1 + number2;
		System.out.println("Sum of numbers "+sum);
	}
}