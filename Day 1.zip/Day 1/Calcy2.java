public class Calcy2
{
	public static void main(String param[])
	{
		int number1, number2, sum;
		number1 = Integer.parseInt(param[0]);
		number2 = Integer.parseInt(param[1]);
		sum = number1 + number2;
		System.out.println("Sum of numbers "+sum);
	}
}