package example3;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Square {

	public static void main(String[] args) {
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the total numbers");
		int num = sc.nextInt();
		int arr[] = new int[num];
		System.out.println("Enter the numbers");
		for (int i = 0; i < num; i++) {
			arr[i] = sc.nextInt();
			hm.put(arr[i], (arr[i] * arr[i]));
		}
		for (Map.Entry entry : hm.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}

	}

}
