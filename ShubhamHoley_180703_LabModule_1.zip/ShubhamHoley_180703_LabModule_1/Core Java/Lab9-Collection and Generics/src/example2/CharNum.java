package example2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CharNum {
	static void charactercount(String inputstr) {
		HashMap<Character, Integer> charcountMap = new HashMap<Character, Integer>();
		char[] strArray = inputstr.toCharArray();
		for (char c : strArray) {
			if (charcountMap.containsKey(c)) {
				charcountMap.put(c, charcountMap.get(c) + 1);
			} else {
				charcountMap.put(c, 1);
			}
		}
		for (Map.Entry entry : charcountMap.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = sc.nextLine();
		charactercount(str);

	}

}
