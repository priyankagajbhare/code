package example4;

import java.util.function.Supplier;

public class Main {

	public static void main(String[] args) {

		Supplier<Employee> e = Employee::new;

		System.out.println(e.get().getEmpName());
		System.out.println(e.get().getEmpId());

		Employee obj = e.get();
		obj.setEmpName("Shubham");
		obj.setEmpId(180703);
		System.out.println(obj);

	}
}
