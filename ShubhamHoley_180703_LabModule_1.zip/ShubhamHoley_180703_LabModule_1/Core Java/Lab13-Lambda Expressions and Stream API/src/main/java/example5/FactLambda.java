package example5;

import java.util.Scanner;
import java.util.function.Function;

public class FactLambda {

		public static int fact(int a) {
		int i, fact = 1;
		// int number ;//It is the number to calculate factorial
		for (i = 1; i <= a; i++) {
			fact = fact * i;
		}

		return fact;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No.: ");
		int num = sc.nextInt();
		Function<Integer, Integer> obj = FactLambda::fact;
		int result = obj.apply(num);
		System.out.println("factorial of the number is " + result);

	}

}
