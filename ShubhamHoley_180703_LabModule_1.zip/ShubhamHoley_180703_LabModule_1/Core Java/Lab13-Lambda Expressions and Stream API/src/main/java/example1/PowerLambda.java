package example1;

import java.util.Scanner;
import java.util.function.BiFunction;

public class PowerLambda {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Base No. X: ");
		int x = sc.nextInt();

		System.out.println("Enter the exponent No. Y: ");
		int y = sc.nextInt();

		BiFunction<Integer, Integer, Integer> obj = (num1, num2) -> {
			return (int) Math.pow(x, y);
		};

		int result = obj.apply(x, y);
		System.out.println("X to the power Y (x^y) is: " + result);

	}
}
