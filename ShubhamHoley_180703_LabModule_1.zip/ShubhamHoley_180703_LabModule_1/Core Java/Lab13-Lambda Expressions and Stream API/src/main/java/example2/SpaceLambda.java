package example2;

import java.util.Scanner;
import java.util.function.Consumer;
import java.util.*;

public class SpaceLambda {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); // for getting input from user
		System.out.println("Enter a line of no with one space between each no");
		String s = sc.nextLine(); // Storing string in s

		// Applying lambda expression function
		Consumer<String> c = (String str) -> {
			System.out.println(str.replaceAll(""," " ).trim());
		};

		c.accept(s);
	}

}
