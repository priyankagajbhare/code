package example2;

//import java.util.Scanner;

public class SquareSum {
	public int calculateDifference(int n) {
		int sqrSum = 0, sum = 0, sumSqr = 0;
		for (int i = 1; i <= n; i++) {
			sqrSum += i * i;
		}
		for (int j = 1; j <= n; j++) {
			sum += j;
		}
		sumSqr = sum * sum;

		return sumSqr - sqrSum;
	}

	public static void main(String[] args) {
		//Scanner sc = new Scanner(System.in);
		// int n = sc.nextInt(); ---------------->>> for taking input from user
		SquareSum sq = new SquareSum();
		int result = sq.calculateDifference(10);
		System.out.println("Square sum and difference of first N natural No. is:  " + result);
	}
}
