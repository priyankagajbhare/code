package example3;

public class IncreasingNumber {

}
