package example5;

import java.util.Scanner;

public class Fact implements TestInterface{

	public static void main(String[] args) {
		Fact f=new Fact();
		TestInterface ti=f::fact;
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ti.fact(n);
	}

	@Override
	public void fact(int number) {
		int fact=1;
		for(int i=1;i<=number;i++)
		{
			fact=fact*i;
		}
		System.out.println(fact);
		
	}

}
