package example5;
@FunctionalInterface
public interface TestInterface {

	public void fact(int number);
}
