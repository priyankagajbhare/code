package example6;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Collectors.*;

public class EmployeeService {

	public static void main(String[] args) {
		
		EmployeeRepository er = new EmployeeRepository();
		List<Employee> emp = er.getEmployees();
		List<Department> dep=er.getDepartments();
		/*
		 * double sum = list.stream().collect(Collectors.summingDouble(a ->
		 * a.getSalary())); System.out.println("Sum of salary of all employees " + sum);
		 */

		//Map<Department, List<Employee>> depemp = emp.stream().collect(groupingBy(Employee::getDepartment));
		/*Set<Department> dept = depemp.keySet();
		dept.stream().forEach(e -> System.out.println(e.getDepartmentName()));*/
		
		//Map<Employee,Set<Employee>> obj=dep.stream().collect(Collectors.groupingBy(Department::, mapFactory, ));

		//Map<String, List<Department>> depemp1 = dep.stream().collect(Collectors.groupingBy(e->e.getDepartmentName()));
	//	System.out.println(depemp1);
		/*groupingBy(Department::getDepartmentName,mapping(Employee::getFirstName))*/
		

		//dep.sort(Department::getDepartmentName);
		
		
	}

}
