package example2;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class reversesort {
	public void array() {
		Scanner sc = new Scanner(System.in);
		ArrayList myarray = new ArrayList();
		System.out.println("Enter the number of Quantities");
		int n = sc.nextInt();
		System.out.println("Enter the Quantities");
		for (int i = 0; i < n; i++) {
			int a = sc.nextInt();
			myarray.add(a);

		}
		Collections.reverse(myarray);
		System.out.println(myarray);
		Collections.sort(myarray);
		System.out.println(myarray);

	}

	public static void main(String[] args) {
		reversesort ab = new reversesort();
		ab.array();
	}

}
