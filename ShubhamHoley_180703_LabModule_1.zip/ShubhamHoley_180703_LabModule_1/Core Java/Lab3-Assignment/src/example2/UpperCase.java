package example2;

import java.util.Arrays;
import java.util.Scanner;

public class UpperCase {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of string array: ");
		int n = sc.nextInt();
		String arr[] = new String[n];
		System.out.println("Enter the String: ");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.next();
		}
		for (int i = 0; i < n; i++) {
			arr[i] = arr[i].toLowerCase();
		}
		Arrays.sort(arr);
		if (n % 2 == 0) {
			for (int i = 0; i < n / 2; i++) {
				arr[i] = arr[i].toUpperCase();
			}
		} else {
			for (int i = 0; i < (n / 2)+1; i++) {
				arr[i] = arr[i].toUpperCase();
			}
			for (int i = 0; i < n; i++)
				System.out.println(" " + arr[i]);
		}
	}
}
