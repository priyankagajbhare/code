package example1;

public class SecondSmallestArray 
{	

	public static int getSecondSmallest(int [] a) 
	{
		
		int b =a.length;
		for (int i = 0; i < b; i++) 
		{
			for (int j=i+1; j<b; j++)
			{
				if (a[i] > a[j])
				{
					int c= a[i];
					a[i] = a[j];
					a[j] = c;
				}
			}
		}
		
		for(int i = 1; i<a.length; i++)
			if(a[i] != a[0])
				return a[i];
		return 0;
	}
	public static void main(String[] args) 
	{
	//BubbleSort ob = new BubbleSort();
	int a [] = {13, 11, 145, 45,78 ,1, 4, 5};
//	ob.bubbleSort(a);
	
	System.out.println("Second Smallest no. in an Array: "+getSecondSmallest(a));

	}
}

