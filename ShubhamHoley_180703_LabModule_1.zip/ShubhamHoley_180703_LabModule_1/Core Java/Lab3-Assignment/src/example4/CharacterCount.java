package example4;

import java.util.ArrayList;
import java.util.Scanner;

public class CharacterCount {
	public void Str() {
		Scanner sc = new Scanner(System.in);
		ArrayList myarray = new ArrayList();
		System.out.println("enter the characters");
		String n = sc.nextLine();
		char[] ch = n.toCharArray();
		for (int i = 0; i < n.length(); i++) {
			int a = sc.nextInt();
			myarray.add(a);
			{

			}
			for (int j = 0; j < n.length() - 1; j++) {
				if (ch[j] == ch[j + 1]) {
					int x = j;
					System.out.println(x);
				}
			}
		}
	}

	public static void main(String[] args) {
		CharacterCount sd = new CharacterCount();
		sd.Str();

	}

}