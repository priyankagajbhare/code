package example3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ReverseSort {
	public void array() {
		Scanner sc = new Scanner(System.in);
		ArrayList arr = new ArrayList();
		System.out.println("Enter the number of Quantities");
		int n = sc.nextInt();
		System.out.println("Enter the Quantities");
		for (int i = 0; i < n; i++) {
			int a = sc.nextInt();
			arr.add(a);

		}
		Collections.reverse(arr);
		System.out.println(arr);
		Collections.sort(arr);
		System.out.println(arr);

	}

	public static void main(String[] args) {
		ReverseSort rs = new ReverseSort();
		rs.array();
	}

}
