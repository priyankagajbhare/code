package item;

public class Video extends mediaitem {
	private String director;
	private String genre;
	private int released_year;

	Video(String director, String genre, int released_year) {
		this.director = director;
		this.genre = genre;
		this.released_year = released_year;

	}

	Video() {
		director = "Andrew";
		genre = "Adam";
		released_year = 2012;

	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getReleased_year() {
		return released_year;
	}

	public void setReleased_year(int released_year) {
		this.released_year = released_year;
	}

	@Override
	public String toString() {
		return "video [director=" + director + ", genre=" + genre + ", released_year=" + released_year + ", Runtime()="
				+ getRuntime() + ", Unique_id()=" + getUnique_id() + ", Num_of_copies()=" + getNum_of_copies()
				+ ", Title()=" + getTitle() + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Video kl = new Video();
		kl.setReleased_year(2025);
		kl.setTitle("Movie");
		System.out.println(kl);
	}
}
