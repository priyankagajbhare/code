package item;

public class CD extends mediaitem {
	private String artist;
	private String genre;
	CD(String artist,String genre){
		this.artist=artist;
		this.genre=genre;
		
	}
	CD(){
		artist= "Aron";
		genre= "Twinkle";
	}

	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	
	@Override
	public String toString() {
		return "CD [artist=" + artist + ", genre=" + genre + ", Runtime()=" + getRuntime() + ", Unique_id()="
				+ getUnique_id() + ", Num_of_copies()=" + getNum_of_copies() + ", Title()=" + getTitle() + "]";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CD li=new CD();
		li.setTitle("movie");

		System.out.println(li);
		
	}

}