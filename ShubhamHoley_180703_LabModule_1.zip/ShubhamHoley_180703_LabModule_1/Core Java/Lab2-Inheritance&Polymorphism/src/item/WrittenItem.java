package item;

abstract class WrittenItem extends Item {
	private String author;
	WrittenItem(String author){
		this.author=author;
	}
	WrittenItem(){
		author="Agrawal";
	}


	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	@Override
	public String toString() {
		return "WrittenItem [author=" + author + ", Unique_id()=" + getUnique_id() + ", Num_of_copies()="
				+ getNum_of_copies() + ", Title()=" + getTitle() + "]";
	}
	
}
