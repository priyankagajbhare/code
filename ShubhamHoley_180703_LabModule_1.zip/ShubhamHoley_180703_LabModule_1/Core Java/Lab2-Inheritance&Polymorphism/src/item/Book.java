package item;


public class Book extends WrittenItem {
	
	@Override
	public String toString() {
		return "Book [Author()=" + getAuthor() + ", Unique_id()=" + getUnique_id() + ", Num_of_copies()="
				+ getNum_of_copies() + ", Title()=" + getTitle() + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Book ef=new Book();
      ef.setAuthor("Andrew");
      System.out.println(ef);
	}

}
