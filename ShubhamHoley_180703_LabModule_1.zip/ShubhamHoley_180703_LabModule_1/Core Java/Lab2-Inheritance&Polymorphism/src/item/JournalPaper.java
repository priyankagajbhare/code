package item;

public class JournalPaper extends WrittenItem {
	private int published_year;
	JournalPaper(int published_year){
		this.published_year= published_year;
	}
	JournalPaper(){
		published_year=2016;
	}

	public int getPublished_year() {
		return published_year;
	}
	public void setPublished_year(int published_year) {
		this.published_year = published_year;
	}
	
	
	@Override
	public String toString() {
		return "journal [published_year=" + published_year + ", Author()=" + getAuthor() + ", Unique_id()="
				+ getUnique_id() + ", Num_of_copies()=" + getNum_of_copies() + ", Title()=" + getTitle() + "]";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JournalPaper gh= new JournalPaper();
		gh.setPublished_year(2020);
		System.out.println(gh);

	}

}
