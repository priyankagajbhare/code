package item;

abstract class Item {
	private int unique_id;
	private int num_of_copies;
	private String title; 
	
	Item(int unique_id,int num_of_copies,String title){
		this.unique_id=unique_id;
		this.num_of_copies=num_of_copies;
		this.title=title;
	}
	Item(){
		unique_id=10;
		num_of_copies=15;
		title="Study";
	}
	public int getUnique_id() {
		return unique_id;
	}

	public void setUnique_id(int unique_id) {
		this.unique_id = unique_id;
	}

	public int getNum_of_copies() {
		return num_of_copies;
	}

	public void setNum_of_copies(int num_of_copies) {
		this.num_of_copies = num_of_copies;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "Item [unique_id=" + unique_id + ", num_of_copies=" + num_of_copies + ", title=" + title + "]";
	}

	

}
