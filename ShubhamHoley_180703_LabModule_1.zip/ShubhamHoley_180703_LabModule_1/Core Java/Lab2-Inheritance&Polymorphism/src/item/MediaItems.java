package item;

abstract class mediaitem extends Item
{
	private int runtime;
	mediaitem(int runtime){
		this.runtime=runtime;
		
	}
	mediaitem(){
		runtime=120;
	}

	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
	@Override
	public String toString() {
		return "mediaitem [runtime=" + runtime + ", Unique_id()=" + getUnique_id() + ", Num_of_copies()="
				+ getNum_of_copies() + ", Title()=" + getTitle() + "]";
	}
	
	}