package example1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class CopyDataThread extends Thread {
	private FileInputStream fis;
	private FileOutputStream fos;
	
	public CopyDataThread(FileInputStream fis, FileOutputStream fos)
	{
		this.fis = fis;
		this.fos = fos;
	}
	
	public void run() {
		int count = 0;
		int ch;
		
		try {
			while((ch=fis.read()) != -1)
			{
				fos.write(ch);
				count++;
				if(count == 10)
				{
					System.out.println("10 characters are copied");
					count = 0;
					Thread.sleep(5000);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Successfully copied");
	}
}
