package example1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileProgram 
{
	public static void main(String[] args)  throws FileNotFoundException, IOException, InterruptedException {
		File readFile = new File("D:\\Jayant\\Java Examples\\Test.txt");
		File writeFile = new File("D:\\Jayant\\Java Examples\\Test2.txt");
		FileInputStream fis = new FileInputStream(readFile);
		FileOutputStream fos = new FileOutputStream(writeFile);
		
		CopyDataThread cd1 = new CopyDataThread(fis,fos);
		cd1.start();
	}
}
