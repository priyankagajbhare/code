package com.cg.eis.dao;

import java.util.ArrayList;
import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeDAOImpl implements EmployeeDAO {

	Map<Integer, Employee> employees = new HashMap<>();

	@Override
	public Employee AddEmployee(Employee emp) throws EmployeeException {
		if (emp == null)
			throw new NullPointerException();
		employees.put(emp.getEmpid(), emp);
		return emp;
	}

	@Override
	public ArrayList<Employee> getEmployeeList() throws EmployeeException {

		Collection<Employee> c1 = employees.values();
		ArrayList<Employee> list = new ArrayList<>(c1);

		return list;
	}

	@Override
	public Employee updateInsuranceScheme(int id) throws EmployeeException {

		return null;
	}

	@Override
	public Employee deleteEmployee(int empid) throws EmployeeException {
		Employee emp = employees.remove(empid);
		return emp;
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		Employee emp = employees.get(id);
		return emp;
	}

}
