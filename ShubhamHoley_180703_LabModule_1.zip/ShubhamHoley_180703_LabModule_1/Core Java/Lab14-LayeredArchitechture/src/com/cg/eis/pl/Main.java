package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.validation.Validator;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.EmployeeValidator;

public class Main {

	public static void main(String[] args) {
		String id;
		Scanner sc = new Scanner(System.in);
		EmployeeService service = new EmployeeServiceImpl();
		int option;
		EmployeeValidator validator = new EmployeeValidator();
		do {
			Employee emp = new Employee();
			System.out.println("1. Add Employee");
			System.out.println("2. Delete Employee");
			System.out.println("3. Update Insurance Scheme");
			System.out.println("4. Print Employee List");
			System.out.println("5. Exit");
			System.out.println("Enter option:->");
			option = sc.nextInt();
			switch (option) {
			case 1:
				try {

					System.out.println("Enter Employee id");
					id = sc.next();
					if (validator.validateEmpId(id) == false)
						throw new EmployeeException("Invalid Employee id ");

					System.out.println("Enter name");
					String name = sc.next();
					if (validator.validatename(name) == false)
						throw new EmployeeException("Invalid Employee name ");

					System.out.println("Enter salary");
					double salary = sc.nextDouble();

					Scanner sc1 = new Scanner(System.in);

					System.out.println("Enter designation");
					String desig = sc1.nextLine();
					if (validator.validatedesignation(desig) == false)

						throw new EmployeeException("Invalid Employee designation ");

					emp.setDesignation(desig);
					emp.setEmpid(Integer.parseInt(id));
					emp.setName(name);
					emp.setSalary(salary);

					emp = service.AddEmployee(emp);
					System.out.println("Employee added" + emp.getEmpid());
				} catch (EmployeeException e) {

					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter Employee ID");
				id = sc.next();
				try {

					emp = service.deleteEmployee(Integer.parseInt(id));
					System.out.println("Employee Deleted" + emp.getEmpid());
				} catch (EmployeeException e1) {

					System.out.println(e1.getMessage());
				}

				break;
			case 3:
				System.out.println("Enter the Employee ID");
				id = sc.next();
				try {
					emp = service.updateInsuranceScheme(Integer.parseInt(id));
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());

				}

				break;
			case 4:
				try {
					ArrayList<Employee> list = service.getEmployeeList();
					for (Employee e : list) {
						System.out.println(e);
					}
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 5:
				System.exit(0);
				break;

			}
		} while (option != 5);

	}
}
