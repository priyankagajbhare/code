package com.cg.eis.bean;

public class Employee {
	// Defining attributes of Employee class
	private int empid;
	private String name;
	private double salary;
	private String designation;
	private String InsuranceScheme;

	// calling getter and setter methods
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return InsuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		InsuranceScheme = insuranceScheme;
	}

	// calling to string method
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", InsuranceScheme=" + InsuranceScheme + "]";
	}

}
