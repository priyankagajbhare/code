package example1;

import java.util.Scanner;
import java.util.StringTokenizer;

public class LineOfInteger {

	public static void main(String[] args) {
		int n = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the values");
		String s = sc.nextLine();

		StringTokenizer st = new StringTokenizer(s);
		while (st.hasMoreTokens()) {

			n = n + Integer.parseInt(st.nextToken());
		}
		System.out.println("Sum of entered value is " + n);
	}
}
