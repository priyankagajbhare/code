package example6;

import java.util.Scanner;

public class Duration {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the year");
		int year = sc.nextInt();
		
		System.out.println("Enter the month");
		int month = sc.nextInt();
		
		System.out.println("Enter the day");
		int day = sc.nextInt();
		LocalDate systemdate = LocalDate.now();
		LocalDate date = LocalDate.of(year, month, day);
		Period diff = Period.between(date, systemdate);
		System.out.printf("difference is %d years. %d months. %d days\n\n", diff.getYears(), diff.getMonths(),
				diff.getDays());

	}

}
