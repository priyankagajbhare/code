package example6;

public class LocalDate {

	public static LocalDate now() {
		return null;
	}

	public static LocalDate of(int year, int month, int day) {
		
		return null;
	}

}
