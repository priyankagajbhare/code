package example6;

public class Period {

	public static Period between(LocalDate date, LocalDate systemdate) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getDays() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getYears() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getMonths() {
		// TODO Auto-generated method stub
		return null;
	}

}
