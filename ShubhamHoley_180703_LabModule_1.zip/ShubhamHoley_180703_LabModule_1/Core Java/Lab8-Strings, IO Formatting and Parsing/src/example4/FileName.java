package example4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileName {
	public static void main(String[] args) {
		final String filepath = "D:\\Shubham JAVA Example\\SH\\Lab 8 ex-2.txt";
		File f = new File("D:\\Shubham JAVA Example\\SH\\Lab 8 ex-2.txt");
		String n = f.getAbsolutePath();
		String ext = n.substring(n.lastIndexOf("."));
		int code = 0, chars = 0;
		try {
			FileInputStream fis = new FileInputStream(filepath);

			while (fis.available() != 0) {
				code = fis.read();
				if (code != 10)
					chars++;
			}

		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println(e);
		}
		if (f.exists() == true)
			System.out.println("The file exist");
		if (f.exists() == false)
			System.out.println("The file does not exist");
		if (f.canWrite() == true)
			System.out.println("The file is writtable");
		if (f.canWrite() == false)
			System.out.println("The file is not writtable");
		if (f.canRead() == true)
			System.out.println("The file is readable");
		if (f.canRead() == false)
			System.out.println("The file is not readable");
		System.out.println("Extension is" + ext);
		System.out.println("Length of file " + f.length());

	}
}
