package example7;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Validation {

	public static void main(String[] args) {
		Scanner Sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String str = Sc.nextLine();
		boolean flag = Pattern.matches("[A-z]{4,}_job", str);
		if (flag == true) {
			System.out.println("Valid name");
		} else {
			System.out.println("Invalid name");

		}

	}

}
