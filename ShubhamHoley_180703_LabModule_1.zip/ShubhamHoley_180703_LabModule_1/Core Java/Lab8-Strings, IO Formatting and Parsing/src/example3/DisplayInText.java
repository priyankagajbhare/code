package example3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DisplayInText {

	public static void main(String[] args) {
		final String filepath = "D:\\Shubham JAVA Example\\SH\\Lab 8 ex-2.txt";
		File f = new File("D:\\Shubham JAVA Example\\SH\\Lab 8 ex-2.txt");

		try {
			int c;
			int word = 0;
			int line = 1;
			FileInputStream fis = new FileInputStream(filepath);
			while (fis.available() != 0) {
				c = fis.read();
				if (c == 32)
					word++;
				if (c == 13) {
					line++;
					word++;
				}

			}
			System.out.println("total no. words " + word);
			System.out.println("total no. line " + line);
			System.out.println("total no. characters " + f.length());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}
}
