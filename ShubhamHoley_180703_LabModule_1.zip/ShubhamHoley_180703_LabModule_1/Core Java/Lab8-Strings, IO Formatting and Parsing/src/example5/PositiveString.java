package example5;

import java.util.Scanner;

public class PositiveString {
	public static void main(String[] args) {
		boolean flag = true;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		char ch[] = s.toCharArray();
		for (int i = 0; i <=s.length() - 1; i++) {
			char chr = s.charAt(i);
			if (chr > s.charAt(i + 1))
				flag = false;
		}
		if (flag = false) {
			System.out.println("The string is negative");
		} else {
			System.out.println("The string is positive");
		}
	}

}
