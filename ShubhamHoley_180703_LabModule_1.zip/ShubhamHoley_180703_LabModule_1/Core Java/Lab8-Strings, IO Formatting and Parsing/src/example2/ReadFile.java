package example2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		String str = null;
		final String filepath = "D:\\Shubham JAVA Example\\SH\\Lab 8 ex-2.txt";

		try {
			int linenumber = 1;
			FileReader fr;
			fr = new FileReader(filepath);
			BufferedReader br = new BufferedReader(fr);
			while ((str = br.readLine()) != null)

			{
				System.out.println(linenumber + " " + str);
				linenumber++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}