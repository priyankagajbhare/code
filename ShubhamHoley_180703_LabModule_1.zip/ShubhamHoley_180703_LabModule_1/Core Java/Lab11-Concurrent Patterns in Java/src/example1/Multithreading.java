package example1;

import java.io.IOException;

public class Multithreading {
	@SuppressWarnings("unused")
	public static void main(String[] args) throws IOException {

		FileProgram f = new FileProgram();
	}

}
