package example5;

import java.util.Scanner;

class Age extends Exception {
	Age() {
		System.out.println("Enter the valid age");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the age");
		int value = sc.nextInt();
		try {
			if (value <= 15) {
				throw new Age();
			} else {
				System.out.println("You are eligible");
			}
		} catch (Age a) {
		}

	}
}
