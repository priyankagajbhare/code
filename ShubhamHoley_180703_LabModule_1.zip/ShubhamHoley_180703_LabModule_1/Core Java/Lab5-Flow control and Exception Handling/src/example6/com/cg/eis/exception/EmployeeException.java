package example6.com.cg.eis.exception;

import java.util.Scanner;

class salary extends Exception {
	salary() {
		System.out.println("salary is below limit");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the salary");
		int sal = sc.nextInt();
		try {
			if (sal < 3000) {
				throw new salary();
			} else {
				System.out.println("You are eligible");
			}
		} catch (salary a) {
		}

	}
}