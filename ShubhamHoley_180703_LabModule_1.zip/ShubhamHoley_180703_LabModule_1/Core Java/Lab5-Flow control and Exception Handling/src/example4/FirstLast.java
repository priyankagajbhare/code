package example4;

import java.util.Scanner;

class FnameException extends Exception {
	FnameException() {
		System.out.println("Enter the valid first name");
	}
}

class LnameException extends Exception {
	LnameException() {
		System.out.println("Enter the valid last name");
	}

}

public class FirstLast {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first name");

		String fname = sc.nextLine();
		System.out.println("Enter the last name");
		String lname = sc.nextLine();
		try {
			if (fname.isEmpty()) {
				throw new FnameException();
			}
		} catch (FnameException a) {

		}

		try {
			if (lname.isEmpty()) {
				throw new LnameException();
			}
		} catch (LnameException b) {
		}
		if (fname.isEmpty() || lname.isEmpty()) {
			System.out.println("Invalid Name entered");
		} else {
			System.out.println("N"
					+ "ame is " + fname + " " + lname);
		}

	}
}