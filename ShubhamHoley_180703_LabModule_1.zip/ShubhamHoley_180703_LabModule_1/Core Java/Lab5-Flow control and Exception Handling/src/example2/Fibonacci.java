package example2;

public class Fibonacci {
	void fib1(int num) {
		int num1 = 0, num2 = 1, num3 = 0;
		System.out.print(num1 + " " + num2);
		for (int i = 2; i < num; i++) {
			num3 = num1 + num2;
			System.out.print(" " + num3);
			num1 = num2;
			num2 = num3;
		}
	}

	int num1 = 0, num2 = 1, num3 = 0;

	void fib2(int num5) {

		if (num5 > 0) {
			num3 = num1 + num2;
			num1 = num2;
			num2 = num3;
			System.out.print(" " + num3);
			fib2(num5 - 1);
		}
	}

	public static void main(String[] args) {
		Fibonacci fb = new Fibonacci();
		int num = 9;
		fb.fib1(num);
		System.out.print("\n");
		int num5 = 9;
		int n1 = 0, n2 = 1;
		System.out.print(n1 + " " + n2);
		fb.fib2(num5 - 2);
	}

}
