package example1;

import java.util.Scanner;

public class TrafficLight {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select your choice: \n1.Red \n2.Yellow \n3.Green");
		int lit = sc.nextInt();

		switch (lit) {
		case 1:
			System.out.println("Stop");
			break;
		case 2:
			System.out.println("Ready");
			break;
		case 3:
			System.out.println("Go");
			break;
		default:
			System.out.println("enter valid ");

		}
	}

}
