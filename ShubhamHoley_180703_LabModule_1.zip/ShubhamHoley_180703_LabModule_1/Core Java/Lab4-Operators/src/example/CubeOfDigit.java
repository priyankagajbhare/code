package example;

import java.util.Scanner;

public class CubeOfDigit {
	public static int Sum() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value");
		int n = sc.nextInt();
		int sum = 0;
		while (n > 0) {
		    int digit = n % 10;
		    sum += digit * digit * digit;
		    n /= 10;
		}
		return sum;
	}

	public static void main(String[] args) {
		CubeOfDigit c = new CubeOfDigit();
		System.out.println(c.Sum());

	}

}
