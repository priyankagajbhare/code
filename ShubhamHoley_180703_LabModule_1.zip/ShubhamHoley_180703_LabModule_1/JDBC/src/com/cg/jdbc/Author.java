package com.cg.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Author {

	private static Scanner sc;

	public static void main(String[] args) throws SQLException {
		sc = new Scanner(System.in);
		Connection con = DatabaseConnection.getConnection();
		int option;
		do {
			System.out.println("1.Insert");
			System.out.println("2.Update");
			System.out.println("3.Delete");
			option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Insert details in author table");
				String sql = "insert into author values(?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(1, 10);
				ps.setString(2, "Raiyan");
				ps.setString(3, "Roushan");
				ps.setString(4, "Hammad");
				ps.setString(5, "9856589650");
				int row = ps.executeUpdate();
				System.out.println(row + "row inserted");
				;
				break;
			case 2:
				System.out.println("Update Details");
				String sql1 = "update author set authorid=20 where authorid=?";
				PreparedStatement ps1 = con.prepareStatement(sql1, ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE);
				System.out.println("enter id which you want to update to 20");
				int id1 = sc.nextInt();
				ps1.setInt(1, id1);
				;
				int row1 = ps1.executeUpdate();
				System.out.println(row1 + "row updated");
				break;
			case 3:
				System.out.println("enter authorid to delete details....");
				;
				System.out.println("enter id which you want to delete");
				String sql2 = "delete from author whwre authorid=?";
				PreparedStatement ps3 = con.prepareStatement(sql2, ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE);
				int id3 = sc.nextInt();
				ps3.setInt(1, id3);
				;
				int row3 = ps3.executeUpdate();
				System.out.println(row3 + "row deleted");
				;
				break;
			case 4:
				System.exit(1);
			}
		} while (option != 4);
	}
}
