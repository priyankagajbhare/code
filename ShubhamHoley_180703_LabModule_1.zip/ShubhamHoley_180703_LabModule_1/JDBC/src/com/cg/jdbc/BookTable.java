package com.cg.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BookTable {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		Connection con = DatabaseConnection.getConnection();

		System.out.println("enter the book and author name");
		String book = sc.next();
		String author = sc.next();
		String createQuery3 = "insert into book_author_table(book,author)values(?,?)";
		PreparedStatement ps3 = con.prepareStatement(createQuery3);
		ps3.setString(1, book);
		ps3.setString(2, author);
		int row1 = ps3.executeUpdate();
		System.out.println(row1 + "row inserted");
		System.out.println("enter name");
		String name = sc.next();
		String createQuery4 = "insert into author_table values(s1_id.nextval,?)";
		PreparedStatement ps4 = con.prepareStatement(createQuery4);
		ps4.setString(1, name);
		ps4.executeUpdate();
		String c5 = "update book_author_table set price=2000 where author=?";
		PreparedStatement ps5 = con.prepareStatement(c5);
		ps5.setString(1, name);
		int row2 = ps5.executeUpdate();
		System.out.println(row2 + "row inserted");
		System.out.println("enter Isbn,title and author");

		String title = sc.next();
		String author1 = sc.next();
		String createQuery5 = "insert into book_table values(s1_isbn.nextval,?,?)";
		PreparedStatement ps6 = con.prepareStatement(createQuery5);
		ps6.setString(1, title);
		ps6.setString(2, author1);
		int row4 = ps6.executeUpdate();
		System.out.println(row4 + "row inserted");
	}

}
