package com.cg.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
	public static Connection getConnection() {

		String driver = null;
		String url = null;
		String user = null;
		String pwd = null;
		Connection conn = null;
		try {
			FileInputStream fis = new FileInputStream("./resources/dbconnection.properties");
			Properties pr = new Properties();
			pr.load(fis);
			driver = pr.getProperty("driver");
			user = pr.getProperty("user");
			pwd = pr.getProperty("pwd");
			url = pr.getProperty("url");
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
			System.out.println("connected to database");

		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	public static void main(String[] args) {
		getConnection();
	}
}
