package NaturalNumber;

public class NaturalNumber 
{
	public int calculateSum(int n)
	{
		int sum=0;
		for(int i=1; i<=n; i++)
		{
			if( (i % 3 == 0) || (i % 5 == 0) )
			{
				sum = sum + i;
			}
		}
		return sum;
	}
	public static void main(String[] args) {
		NaturalNumber obj = new NaturalNumber();
		obj.calculateSum(15);
		int result = obj.calculateSum(15);
		System.out.println("Sum of first 15 no. which are divisible by 3 or 5 is: "+result);
	}
}