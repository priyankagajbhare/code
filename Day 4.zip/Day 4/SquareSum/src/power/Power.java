package power;

public class Power {
	main()
}
