package test4;

import java.util.Scanner;

public class OverloadingTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Shape shape = new Shape();
		
		System.out.println("1. Area of Circle");
		System.out.println("2. Area of Rectangle");
		System.out.println("Enter your choice: ");
		int choice = sc.nextInt();
		switch(choice){
			case 1: 
				System.out.println("Enter Radius: ");
				int radius = sc.nextInt();
				double area1 = shape.area(radius);
				System.out.println("Area of Circle: "+area1);
				break;
				
			case 2:
				System.out.println("Enter Lenght and Breadth: ");
				int l = sc.nextInt();
				int b = sc.nextInt();
				double area2 = shape.area(l, b);
				System.out.println("Area of Rectangle: "+area2);
				break;
				
			default:
				System.out.println("Please enter valid choice");
	
				

				
		}
	}
	
}
