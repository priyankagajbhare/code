package test4;
class Shape{
	public double area(int radius){
		final float PI = 3.1F;
		double areaCircle = PI * radius * radius;
		return areaCircle;
	}
	public long area(int l, int b){
		long areaRect = l * b;
		return areaRect;
	}
}