package bank2;
class Account{
	public void display(){
		System.out.println("Account class display");
	}
}

class Saving extends Account{
	@Override
	public void display(){
		System.out.println("Saving class display");
	}
}
public class OverringingTest {
	public static void main(String[] args) {
		Account objRef = null;
		
		objRef = new Account();
		objRef.display();
		
		objRef = new Saving();
		objRef.display();
	}
}
