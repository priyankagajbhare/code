package test;

class A{
	int a;          //Data Member
	
	public void showA(){
		System.out.println("a="+a);
	}
}
class B extends A
{
	int b;
	public void showB(){
		System.out.println("a="+a);
		System.out.println("b="+b);
	}
}
public class Test {
	public static void main(String[] args) {
		A objA = new A();
		objA.a = 100;
		objA.showA();
		
		B objB = new B();
		objB.a = 200;
		objB.b = 300;
		objB.showB();
	}
}
