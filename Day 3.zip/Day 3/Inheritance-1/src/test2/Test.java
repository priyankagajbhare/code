package test2;
class A{
	private int a;
	A(){
		a = -1;
		System.out.println("a="+a);
	}
	A(int a){
		this.a = a;
		System.out.println("a="+a);
	}
}
class B extends A{
	private int b;
	B(){
		b = -1;
		System.out.println("b="+b);
	}
	B(int b){
		super(b);
		this.b = b;
		System.out.println("b="+b);
	}
}
public class Test {
	public static void main(String[] args) {
		//B objB1 = new B();
		B objB2 = new B(1002);

	}
}
