package bank;

public class Customer {
	private String firstName;
	private String lastName;
	
	private Account account; //cust has-a account
	
	public String getfirstName(){
		return firstName;
	}
	public String getlastName(){
		return lastName;
	}
	
	public Customer(String firstName, String lastName){
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Account getAccount(){
		return account;
	}
	public void setAccount(Account account){
		this.account = account;
	}
}
