package bank;

public class Account {
	private double balance;
	public Account(double balance){
		this.balance = balance;
	}
	public double getBalance(){
		return balance;
	}
	public void deposite(double amount){
		balance = balance + amount;
		System.out.println("Balance after depositing Rs. "+amount+"is = Rs. "+balance);
	}
	public void withdraw(double amount){
		balance = balance - amount;
		System.out.println("Balance after withdrawing Rs. "+amount+"is = Rs. "+balance);
	}
}


