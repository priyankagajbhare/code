package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService{
	PizzaOrderDAO dao = new PizzaOrderDAO();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int result = dao.placeOrder(customer, pizza);
		return result;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		PizzaOrder pizza = dao.getOrderDetails(orderId);
		return pizza;
	}

}
