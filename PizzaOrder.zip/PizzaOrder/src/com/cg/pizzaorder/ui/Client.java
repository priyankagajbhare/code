package com.cg.pizzaorder.ui;

import java.sql.Date;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	public static void main(String[] args) {
		PizzaOrderService service = new PizzaOrderService();
		int ch;
		Scanner Sc = new Scanner(System.in);
		do {
			System.out.println("1. Place Order");
			System.out.println("2. Display Order");
			System.out.println("3. Exit");
			ch = Sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter Customer Name: ");
				String custName = Sc.next();
				System.out.println("Enter Customer Address: ");
				String custAddress = Sc.next();
				System.out.println("Enter Phone No.: ");
				String custPhone = Sc.next();
				int toppings;
				int pizzaPrice = 350;
				do {
					System.out.println(
							"Enter the type of topping(1. Capsicum \t 2. Mushroom \t 3. Jalapeno \t 4. Paneer)");
					toppings = Sc.nextInt();
					if (toppings == 1)
						pizzaPrice += 30;
					else if (toppings == 2)
						pizzaPrice += 50;
					else if (toppings == 3)
						pizzaPrice += 70;
					else if (toppings == 4)
						pizzaPrice += 85;
					else
						System.out.println("Invalid choice. Please enter correct choice.");
				} while (toppings > 4 || toppings < 1);
				System.out.println("Price: " + pizzaPrice);
				System.out.println("Order Date: " + java.time.LocalDate.now());
				int custId = 0;
				int orderId = 0;
				Customer cust = new Customer(custId, custName, custAddress, custPhone);
				PizzaOrder order = new PizzaOrder(orderId, custId, pizzaPrice);
				order.setTotalPrice(pizzaPrice);
				try {
					orderId = service.placeOrder(cust, order);
					System.out.println("Pizza Order Sucessfully placed with order ID: " + orderId);
				} catch (PizzaException e) {
					e.printStackTrace();
				}
				break;

			case 2:
				System.out.println("Enter Order Id: ");
				orderId = Sc.nextInt();
				order = service.getOrderDetails(orderId);
				if (order == null)
					System.out.println("Order ID not found");
				else
					System.out.println(order);
				break;

			case 3:

				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
		} while (ch != 3);
	}
}
