package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO{
	private static Map<Integer, PizzaOrder> pizzaEntry = new HashMap<Integer, PizzaOrder>();
	private static Map<Integer, Customer> customerEntry = new HashMap<Integer, Customer>();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int orderid = (int)(100+(Math.random()*(200-100)));
		int customerid = (int)(1000+(Math.random()*(2000-1000)));
		customer.setCustId(customerid);
		pizza.setCustomerId(customerid);
		pizza.setOrderId(orderid);
		customerEntry.put(customer.getCustId(), customer);
		pizzaEntry.put(pizza.getOrderId(), pizza);
		return pizza.getOrderId();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		if(pizzaEntry.containsKey(orderId)) {
			return pizzaEntry.get(orderId);
		}
		return null;
	}

}
