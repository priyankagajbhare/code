package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyTest 
{

	public static void main(String[] args)
	{
		try
		{
			File file = new File("D:\\Shubham JAVA Example\\Day 7\\IOProject\\Test.txt");
			if (file.exists())
			{
				FileInputStream fis = new FileInputStream(file);
				FileOutputStream fos = new FileOutputStream("D:\\Shubham JAVA Example\\Day 7\\IOProject\\Test2.txt", true);
				int ch;
				while((ch = fis.read()) != -1)
				{
					fos.write(ch);
				}
				System.out.println("File Copied.");
				fis.close();
				fos.close();
			}
			else
			{
				System.out.println("File does not exists.");
			}
		}
		catch(FileNotFoundException e)
		{
			System.out.println("File not found at specified location.");
		}
		catch(IOException e)
		{
			System.out.println("Problem reading file.");
		}
	
	}
}
