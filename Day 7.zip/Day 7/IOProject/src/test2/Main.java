package test2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Employee emp = new Employee(180703, "Shubham", 16915);
		
		FileOutputStream fos = new FileOutputStream("D:\\Shubham JAVA Example\\Day 7\\IOProject\\TestSerialization.dat");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(emp);
		oos.close();
		fos.close();
		System.out.println("Serialization completed.");
		
		FileInputStream fis = new FileInputStream("D:\\Shubham JAVA Example\\Day 7\\IOProject\\TestSerialization.dat");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Employee emp1 = (Employee)ois.readObject();
		System.out.println(emp1);
		System.out.println("Deserialization completed.");
	}
}
