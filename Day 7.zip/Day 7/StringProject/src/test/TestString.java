package test;

public class TestString {
	public static void main(String[] args) {
		String str1 = "Capgemini";
		String str2 = "Capgemini";
		System.out.println("Hashcode for str1 = "+str1.hashCode());
		System.out.println("Hashcode for str2 = "+str2.hashCode());
		String str3 = new String("Capgemini");
		System.out.println("Hashcode for str3 = "+str3.hashCode());

		//String str4 = str1+str2;
		str3 = str3.concat("Pune");
		System.out.println("After concat hashcode for str3 = "+str3.hashCode());
	}

}
