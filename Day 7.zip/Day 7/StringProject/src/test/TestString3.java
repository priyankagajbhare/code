package test;

public class TestString3 {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		StringBuffer str1 = new StringBuffer("Capgemini");
		//String str1 = "Capgemini";
		
		for(int i=1; i<=100000; i++){
			str1 = str1.append(" World.!");
		}
		System.out.println(str1.substring(0, 50));
		System.out.println(str1);
		long endTime = System.currentTimeMillis();
		System.out.println("Execution time in milisecond: "+(endTime-startTime));
				

	}

}