package test;

//import java.io.BufferedReader;
//import java.io.InputStreamReader;
import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = new String();
		String rev = "";
		str = sc.next();
		for(int i=str.length()-1; i>=0; i--){
			rev = rev + str.charAt(i);
		}
		if(str.equals(rev)){
			System.out.println("String is Palindrome");
		}
		else{
			System.out.println("String is not Palindrome");
		}
	}

}
