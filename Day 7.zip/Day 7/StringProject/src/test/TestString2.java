package test;

public class TestString2 {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		String str1 = "Capgemini";
		
		for(int i=1; i<=10; i++){
			str1 = str1 + " World.!";
		}
		str1 = str1.substring(0, 50);
		System.out.println(str1);
		long endTime = System.currentTimeMillis();
		System.out.println("Execution time in milisecond: "+(endTime-startTime));
				

	}

}
