package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.StudentDao;
import com.capgemini.model.Student;

@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	private StudentDao dao;
		
	@Override
	public List<Student> getAllStudents() {
		return dao.readAllStudents();
	}

	@Override
	public boolean addStudent(Student student) {
		return dao.createStudent(student);
	}

}
