package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Student;

public interface StudentService {
	public List<Student> getAllStudents();
	public boolean addStudent(Student student);
}
