package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {
	static List<Student> students = new ArrayList<Student>();
	
	@Override
	public List<Student> readAllStudents() {
		return students;
	}

	@Override
	public boolean createStudent(Student student) {
		boolean flag = students.add(student);
		return flag;
	}
}
