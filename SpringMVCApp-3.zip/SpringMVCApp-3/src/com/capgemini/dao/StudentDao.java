package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Student;

public interface StudentDao {
	public List<Student> readAllStudents();
	public boolean createStudent(Student student);
}
