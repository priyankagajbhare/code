package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.model.Student;
import com.capgemini.service.StudentService;

@Controller
@RequestMapping("/student-module")
public class StudentController {
	@Autowired
	private StudentService service;

	@RequestMapping(value = "getAll", method = RequestMethod.GET)
	public String getAllStudents(Model model) {
		List<Student> students = service.getAllStudents();
		model.addAttribute("students", students);
		return "ListStudents";

	}

	@RequestMapping(value = "/showForm", method = RequestMethod.GET)
	public String showForm() {
		return "AddStudent";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String processStudentForm(@RequestParam("rollNumber") int rollNumber, 
									 @RequestParam("name")String name, 
									 @RequestParam("score")double score,
									 Model model) 
	{
		Student student = new Student();
		student.setRollNumber(rollNumber);
		student.setStudentName(name);
		student.setScore(score);
		
		System.out.println("Roll Number: "+rollNumber);
		System.out.println("Student Name: "+name);
		System.out.println("Score: "+score);

		service.addStudent(student);
		
		List<Student> students = service.getAllStudents();
		model.addAttribute("students", students);
		return "ListStudents";
	}
}
