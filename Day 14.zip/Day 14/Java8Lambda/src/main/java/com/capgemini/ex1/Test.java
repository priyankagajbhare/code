package com.capgemini.ex1;

public class Test {

	public static void main(String[] args) {
		// inner class
		FunInterface fi1 = new FunInterface() {

			@Override
			public void fun(String str) {
				System.out.println(str + " from inner class");
			}
		};
		fi1.fun("'Hello'");
		
		// outer class instance
		FunInterface fi2 = new Test1();
		fi2.fun("'Hello'");
		
		// Lambda expression
		FunInterface fi3 = (String str) -> {System.out.println(str + " from Lambda expression");};
		fi3.fun("'Hello'");
	}

}
class Test1 implements FunInterface{
	@Override
	public void fun(String str) {
		System.out.println(str + " from outer class");
	}
}
