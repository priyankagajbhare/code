package com.capgemini.ex5;

public class Test {

	public static void main(String[] args) {
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				printMessage("Hello from Inner class");
			}
		});
		t1.start();

		// Lambda Expression
		Thread t2 = new Thread(() -> printMessage("Hello from Lambda expression"));
		t2.start();
	
		//Method reference
		Thread t3 = new Thread(Test :: printMessage);
			t3.start();
	}

	public static void printMessage(String msg) {
		System.out.println("Message: " + msg);
	}
	public static void printMessage() {
		System.out.println("This method will call method reference ");
	}
}
