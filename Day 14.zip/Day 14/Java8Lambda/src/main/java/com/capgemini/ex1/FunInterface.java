package com.capgemini.ex1;

@FunctionalInterface
public interface FunInterface {
	public void fun(String str);
//	public void fun(String str);  --------------->>> (ERROR)there should be only one method
	
	
}
