package com.capgemini.ex2;

public interface ZeroParam {
	public abstract void display();
}
