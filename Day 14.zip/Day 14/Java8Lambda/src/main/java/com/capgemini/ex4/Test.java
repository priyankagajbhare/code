package com.capgemini.ex4;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		Employee e1 = new Employee(101, "ABC", 5000); // ------------->>> normal method
		Employee e3 = new Employee(103, "XYZ", 7000);
		List<Employee> employees = Arrays.asList(e1, new Employee(102, "DEF", 6000), e3);

		/*
		 * Iterator<Employee> itr = emp.iterator(); while (itr.hasNext()) {
		 * System.out.println(itr.next()); }
		 */

		Collections.sort(employees, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpName().compareTo(o2.getEmpName());
			}
		});

		Collections.sort(employees, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				if (o1.getEmpSalary() > o2.getEmpSalary()) {
					return 1;
				} else {
					return -1;
				}
			}
		});
		Iterator<Employee> itr3 = employees.iterator();
		System.out.println("Sorting by salary:");
		while(itr3.hasNext()) {
			System.out.println(itr3.next());
		}
	}

}
