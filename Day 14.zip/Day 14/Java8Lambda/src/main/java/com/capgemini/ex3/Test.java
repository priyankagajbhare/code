package com.capgemini.ex3;
@FunctionalInterface
interface OneParam{
	public void display(String str);
}

public class Test {
	public static void main(String[] args) {
		OneParam op1 = (String str) -> System.out.println(str + " from lambda expression 1");
		op1.display("'Hello'"); 
		
		OneParam op2 = (str) -> System.out.println(str + " from lambda expression 2");
		op2.display("'Hello'");
		
		OneParam op3 = str -> System.out.println(str + " from lambda expression 3");
		op3.display("'Hello'");

	}

}
