package com.capgemini.ex4;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test2 {
	public static void main(String[] args) {
		Employee e = new Employee(101, "ABC", 5000); // ------------->>> normal method
		Employee e3 = new Employee(103, "Shubham", 7000);
		List<Employee> employees = Arrays.asList(e, new Employee(102, "Sumit", 6000), e3);
		
		Collections.sort(employees, (Employee e1, Employee e2) -> e1.getEmpName().compareTo(e2.getEmpName()));
		System.out.println("Sorting on the basis of employee name: ");
		employees.forEach(emp -> System.out.println(emp));
		System.out.println("\nSorting on the basis of employee Salary: ");

		/* Collections.sort(employees, (e, e2) -> {return 1;}); */
		Collections.sort(employees, (e1, e2) -> e1.getEmpSalary() > e2.getEmpSalary() ? 1 : -1);  // --------------->>> using ternary operator
		employees.forEach(emp -> System.out.println(emp));
	}
}
