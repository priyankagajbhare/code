package com.capgemini.ex2;

public class Test {
	public static void main(String[] args) {
		ZeroParam zp1 = () -> {System.out.println("Zero param display method");};
		zp1.display();
		
		ZeroParam zp2 = () -> System.out.println("Zero param display method");
		zp2.display();
	}

}
