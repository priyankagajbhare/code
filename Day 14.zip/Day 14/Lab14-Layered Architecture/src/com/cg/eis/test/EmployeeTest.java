package com.cg.eis.test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import com.cg.eis.dao.EmployeeDAO;
import com.cg.eis.dao.EmployeeDAOImpl;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeValidator;

public class EmployeeTest {
	@Test
	public void testMethod1() {

		EmployeeValidator validator = new EmployeeValidator();

		String empid = "923404";
		boolean actual = validator.validateEmpId(empid);
		boolean expected = true;

		assertEquals(expected, actual);

	}

	@Test
	public void testMethod2() {

		EmployeeValidator validator = new EmployeeValidator();

		String empid = "92340423";
		boolean actual = validator.validateEmpId(empid);
		boolean expected = false;
		assertEquals(expected, actual);
	}

	@Test
	public void testMethod3() {

		EmployeeValidator validator = new EmployeeValidator();

		String empid = "ertr34";
		boolean actual = validator.validateEmpId(empid);
		boolean expected = false;
		assertEquals(expected, actual);
	}

}
