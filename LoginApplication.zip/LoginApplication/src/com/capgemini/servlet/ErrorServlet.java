package com.capgemini.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Error.view")
public class ErrorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("response.sendredirect is calling doGet of Error");
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		//String username = request.getParameter("username");
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<h1 style=\"text-align:center;\">Invalid Login</h1>");
		//pw.println("<h1 style=\"text-align:center;\">Invalid Login "+username+"</h1>");
		pw.println("<h3 style=\"text-align:center;\">Please <a href='Login.do'>try again</a></h3>");
		pw.println("</body>");
		pw.println("</html>");
	}

}
