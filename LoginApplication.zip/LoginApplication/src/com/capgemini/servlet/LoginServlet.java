package com.capgemini.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		RequestDispatcher rd;

		if(username.equals("capgemini") && password.equals("admin123"))
		{
			//response.sendRedirect("Success.view");
			rd = request.getRequestDispatcher("Success.view");
			rd.forward(request, response);
		}
		else
		{
			//response.sendRedirect("Error.view");
			rd = request.getRequestDispatcher("Error.view");
			rd.forward(request, response);
		}
	}
}
