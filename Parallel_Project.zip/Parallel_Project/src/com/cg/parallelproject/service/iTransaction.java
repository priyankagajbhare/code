package com.cg.parallelproject.service;

import java.util.List;

import com.cg.parallelproject.exception.CustomerException;
import com.parallelproject.bean.Transaction;

public interface iTransaction {
	public Transaction addtransaction(Transaction trans) throws CustomerException;
	public Transaction gettransaction(long acc ) throws CustomerException;
}
