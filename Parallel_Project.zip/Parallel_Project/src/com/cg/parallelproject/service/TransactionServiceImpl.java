package com.cg.parallelproject.service;

import java.util.List;

import com.cg.parallelproject.dao.TransactionDAOImpl;
import com.cg.parallelproject.dao.iTransactionDAO;
import com.cg.parallelproject.exception.CustomerException;
import com.parallelproject.bean.Transaction;

public class TransactionServiceImpl implements iTransaction {
	iTransactionDAO dao;

	public TransactionServiceImpl() {
		dao = new TransactionDAOImpl();
	}

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.addtransaction(trans);
	}

	@Override
	public Transaction gettransaction(long acc) throws CustomerException {
		return dao.gettransaction(acc);
	}

}
