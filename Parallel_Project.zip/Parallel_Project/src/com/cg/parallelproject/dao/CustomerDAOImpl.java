package com.cg.parallelproject.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.parallelproject.exception.CustomerException;
import com.parallelproject.bean.Customer;

public class CustomerDAOImpl<Transaction> implements iCustomerDAO {
	private static Map<Long, Customer> customer = new HashMap();
	Map<Long,Transaction> Transaction = new HashMap();

	static {
		customer.put((long) 10000, new Customer(10000, 1250, "Vaibhav", 827554601, "Nagpur", 5500));
		customer.put((long) 20000, new Customer(20000, 0355, "Shubham", 996942166, "Mumbai", 5000));
		customer.put((long) 30000, new Customer(30000, 2486, "Harshal", 89894733, "Pune", 20000));

	}

	@Override
	public Customer createAccount(Customer cust) throws CustomerException {
		customer.put(cust.getAcNO(), cust);
		System.out.println("Account Successfully created");
		System.out.println(cust);		
		return cust;

	}

	@Override
	public Customer AddMoney(long acc, int pin, int balance) throws CustomerException {
		Customer cust2 = customer.get(acc);
		int currentbalance = cust2.getBalance();
		int totalbalance = currentbalance + balance;
		cust2.setBalance(totalbalance);
		return cust2;
	}

	@Override
	public Customer TransferMoney(long acc, long acc1, int balance) throws CustomerException {
		Customer cus = customer.get(acc);
		Customer cus1 = customer.get(acc1);

		if (cus.getBalance() < balance) {
			System.out.println("Enter amount less than  " + cus.getBalance());
		} else {
			int acc1currentbalance = cus.getBalance() - balance;
			cus.setBalance(acc1currentbalance);

			int acc2currentbalance = cus1.getBalance() + balance;
			cus1.setBalance(acc2currentbalance);

		}
		return cus1;
	}

	@Override
	public ArrayList<Customer> getAccountList() throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getAccount(long acc) throws CustomerException {
		Customer cust = customer.get(acc);
		return cust;
		
	}

	@Override
	public Customer withdraw(long acc, int amount) throws CustomerException {
		Customer cus = customer.get(acc);
		int balance = cus.getBalance();
		int availbalance = balance - amount;
		cus.setBalance(availbalance);
		System.out.println(cus);
		return cus;
	
	}

}
