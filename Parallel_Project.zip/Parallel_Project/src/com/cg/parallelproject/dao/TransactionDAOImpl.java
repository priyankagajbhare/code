package com.cg.parallelproject.dao;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cg.parallelproject.exception.CustomerException;
import com.parallelproject.bean.Transaction;


public class TransactionDAOImpl implements iTransactionDAO {
	Map<Long,Transaction> transact = new HashMap();
	

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
transact.put(trans.getAcno(), trans);
		
		return trans;
	}

	@Override
	public Transaction gettransaction(long acc) throws CustomerException {
Transaction t1 = transact.get(acc);
return t1;
}
}