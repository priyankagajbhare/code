package com.cg.parallelproject.dao;

import java.util.List;

import com.cg.parallelproject.exception.CustomerException;
import com.parallelproject.bean.Transaction;

public interface iTransactionDAO {
	public Transaction addtransaction(Transaction trans) throws CustomerException;
	public Transaction gettransaction(long acc ) throws CustomerException;
}
