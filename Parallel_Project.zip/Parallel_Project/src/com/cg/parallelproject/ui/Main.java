package com.cg.parallelproject.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.parallelproject.exception.CustomerException;
import com.cg.parallelproject.service.CustomerServiceImpl;
import com.cg.parallelproject.service.CustomerValidator;
import com.cg.parallelproject.service.TransactionServiceImpl;
import com.parallelproject.bean.Customer;
import com.parallelproject.bean.Transaction;

public class Main {

	public static void main(String[] args) throws CustomerException {

		long acno;
		int pin;
		int option;
		int option1 = 0;
		int choice;
		Scanner sc = new Scanner(System.in);
		Customer cust = new Customer();
		Transaction trans = new Transaction();
		TransactionServiceImpl service1 = new TransactionServiceImpl();
		CustomerValidator validate = new CustomerValidator();
		CustomerServiceImpl service = new CustomerServiceImpl();
		do {
			System.out.println("Enter the option:->\n1.Create Account\n2.View Account\n3.exit");
			option = sc.nextInt();
			switch (option) {

			case 1:
				try {
					System.out.println("Enter your name");
					String name = sc.next();
					if (validate.validname(name) == false)
						throw new CustomerException("Enter a valid name");
					System.out.println("Enter your account number");
					acno = sc.nextLong();
					System.out.println("Enter your phone number");
					long phone = sc.nextLong();
					if (validate.validphone(Long.toString(phone)) == false)
						throw new CustomerException("Enter valid phone number");
					System.out.println("Enter your pin");
					pin = sc.nextInt();
					Scanner sc1 = new Scanner(System.in);
					System.out.println("Enter your address");
					String address = sc1.nextLine();
					cust.setName(name);
					cust.setAddress(address);
					cust.setAcNO(acno);
					cust.setPhone_number(phone);
					cust.setPin(pin);

					service.createAccount(cust);
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 2:

				System.out.println("Enter the account number ");
				acno = sc.nextLong();
				System.out.println("Enter your pin");
				pin = sc.nextInt();
				Customer cust1 = service.getAccount(acno);
				if (cust1 != null) {
					if (cust1.getPin() == pin) {
						do {
							System.out.println(cust1);
							System.out.println(
									"Enter the option:->\n1.Add Money \n2.Withdraw money \n3.Transfer money \n4.Print Transactions \n5.Show balance\n6.exit");
							option1 = sc.nextInt();
							switch (option1) {
							case 1:
								try {

									System.out.println("Enter the amount you want to add");
									int amount = sc.nextInt();
									service.AddMoney(acno, pin, amount);
									trans.setAcno(acno);
									trans.setAmount(amount);
									trans.setTransactionID((Math.random() * 100));
									trans.setType("Add money");
									service1.addtransaction(trans);
									System.out.println("Amount Added successfully");

								} catch (CustomerException e) {
									System.out.println(e.getMessage());
								}

								break;

							case 2:

								System.out.println("Enter amount you want to withdraw");
								int withdraw = sc.nextInt();
								if (cust1.getBalance() < withdraw) {
									System.out.println("Enter amount less than " + cust1.getBalance());
								} else {
									try {
										service.withdraw(acno, withdraw);
										trans.setAcno(acno);
										trans.setAmount(withdraw);
										trans.setTransactionID((Math.random() * 100));
										trans.setType("Withdraw");
										service1.addtransaction(trans);
									} catch (CustomerException e) {
										e.printStackTrace();
									}
								}
								System.out.println("Amount widthdrawed successfully");
								break;
							case 3:

								System.out.println("Enter the account number you want to transfer");
								long accno = sc.nextLong();
								System.out.println("Enter the amount to be transferred");
								int amount = sc.nextInt();
								if (cust1.getBalance() < amount) {
									System.out.println("Enter amount less than " + cust1.getBalance());
								} else {
									service.TransferMoney(acno, accno, amount);
									trans.setAcno(acno);
									trans.setAmount(amount);
									trans.setTransactionID(((int) (Math.random() * 100000)) % 1000);
									trans.setType("transfer");
									service1.addtransaction(trans);
									System.out.println("Amount transferred successfully");
								}
								break;
							case 4:
								Transaction trans1 = service1.gettransaction(acno);
								if (trans1 == null) {
									System.out.println("No transactions ");
								} else {
									System.out.println(trans1);
								}

								break;
							case 5:
								System.out.println("Current Balance " + cust1.getBalance());

								break;
							case 6:
								System.exit(0);
							}
						} while (option1 != 6);
					} else {
						System.out.println("Enter valid pin");
					}
				} else {
					System.out.println("Enter valid account number ");
				}

				break;
			case 3:
				System.exit(0);

			}

		} while (option != 3);

	}

}
