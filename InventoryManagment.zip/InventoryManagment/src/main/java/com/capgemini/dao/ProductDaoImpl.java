package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.exception.ProductAlreadyExistsException;
import com.capgemini.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao{
	private static EntityManager em;
	
	public ProductDaoImpl() {
		em=JpaUitiles.getEntityManager();
	}
	
	//add product
	public void createProduct(Product product) throws ProductAlreadyExistsException {

		int id = product.getProductId();
		Product tempProduct  =  em.find(Product.class, id);
		// if product already exists, throw exception
		if(tempProduct != null)
			throw new ProductAlreadyExistsException("Product with this id already exists");
		else
		{
			try {
				 em.getTransaction().begin();
			     em.persist(product);
			     em.getTransaction().commit();
		
			}
			catch(Exception e)
			{
				throw new ProductAlreadyExistsException("Product with this id already exists");
			}
		}
	}
	
	//read product
	public Product readProduct(int productId) {
		em.getTransaction().begin();
		Product product=em.find(Product.class, productId);
		em.getTransaction().commit();
		return product;
		
	}
	
	//read all products
	public List<Product> readAllProducts() {
		TypedQuery<Product> query=em.createQuery("select p from Product p", Product.class);
		List<Product> admin=query.getResultList();
		return admin;
	}
	
	//update product
	public boolean updateProduct(Product product) {
		em.getTransaction().begin();
		em.merge(product);
		em.getTransaction().commit();
		return true;
	}
	
	//delete product
	public boolean deleteProduct(int productId) {
		Product product = em.find(Product.class, productId);
		em.getTransaction().begin();
		em.remove(product);
		em.getTransaction().commit();
		return true;
	}
	

}
		
	

	
	
	

