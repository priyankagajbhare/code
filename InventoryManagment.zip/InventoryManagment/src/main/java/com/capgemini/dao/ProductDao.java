package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public interface ProductDao {
 public void createProduct(Product product);
 public Product readProduct(int accessId);
 public List<Product> readAllProducts();
 public boolean updateProduct(Product product);
 public boolean deleteProduct(int productId);
 
}
