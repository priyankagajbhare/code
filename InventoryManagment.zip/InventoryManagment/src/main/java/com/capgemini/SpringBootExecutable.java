package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*It is spring boot application class which is going to start three annotation
 * @Configuiration,@Component-scan and @ AutoEnableConfiguiration*/
@SpringBootApplication
public class SpringBootExecutable {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExecutable.class, args);

	}

}
  