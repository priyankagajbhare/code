package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Product;

public interface ProductService {
	public void addProduct(Product product);
	public Product getProduct(int productId);
	public List<Product> getAllProducts();
	public boolean modifyProduct(Product product);
	public boolean removeProduct(int productId);
}
