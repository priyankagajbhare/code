package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.ProductDao;
import com.capgemini.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao dao;
	
	public void addProduct(Product product) {
		dao.createProduct(product);
		
	}
	public Product getProduct(int productId) {
		return dao.readProduct(productId);
	}
	
	public List<Product> getAllProducts() {
		return dao.readAllProducts();
	}
	
	public boolean modifyProduct(Product product) {
		return dao.updateProduct(product);
		
	}
	public boolean removeProduct(int productId) {
		return dao.deleteProduct(productId);
	}
	
}
