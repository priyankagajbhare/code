package com.capgemini.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Products")
public class Product {
	@Id
	@Column(name="Id")
	private int productId;
	@Column(name="Name")
	private String productName;
	@Column(name="Rating")
	private double productRating;
	@Column(name="Category")
	private String catrgory;
	@Column(name="Description")
	private String productDescription;
	@Column(name="Quantity")
	private int productQuantity;
	
	
	//Constructors
	public Product() {
		
	}


	public Product(int productId, String productName, double productRating, String catrgory, String productDescription,
			int productQuantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productRating = productRating;
		this.catrgory = catrgory;
		this.productDescription = productDescription;
		this.productQuantity = productQuantity;
	}

	//Getter Setters
	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public double getProductRating() {
		return productRating;
	}


	public void setProductRating(double productRating) {
		this.productRating = productRating;
	}


	public String getCatrgory() {
		return catrgory;
	}


	public void setCatrgory(String catrgory) {
		this.catrgory = catrgory;
	}


	public String getProductDescription() {
		return productDescription;
	}


	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}


	public int getProductQuantity() {
		return productQuantity;
	}


	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productRating=" + productRating
				+ ", catrgory=" + catrgory + ", productDescription=" + productDescription + ", productQuantity="
				+ productQuantity + "]";
	}
	
	
	
	
}
