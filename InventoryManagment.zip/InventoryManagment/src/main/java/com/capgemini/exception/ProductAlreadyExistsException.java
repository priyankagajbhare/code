package com.capgemini.exception;

public class ProductAlreadyExistsException extends RuntimeException {
	
	public ProductAlreadyExistsException() {
		super();
	}


	public ProductAlreadyExistsException(String string) {
		super(string);
	}

}
