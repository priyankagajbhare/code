package executor.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*
  On one CounterRunnable object 
 */
public class TestExecutorFramework {
	public static Thread mainThread = null;
	
	public static void main(String[] args) {
		mainThread = Thread.currentThread();
		
		CounterRunnable counter1 = new CounterRunnable("Obj1");
		CounterRunnable counter2 = new CounterRunnable("Obj2");
		CounterRunnable counter3 = new CounterRunnable("Obj3");
		CounterRunnable counter4 = new CounterRunnable("Obj4");
		
		/*Thread t1 = new Thread(counter1);
		t1.start();*/
		
		ExecutorService execService = Executors.newFixedThreadPool(3);  //---------->>> it will create 3 threads like above line.
		//ExecutorService execService = Executors.newSingleThreadExecutor();---------->>> it takes more time for the execution.
		
		System.out.println("First execution:");
		execService.execute(counter1);
		
		System.out.println("Second execution:");
		//execService.execute(counter1);
		execService.execute(counter2);
		
		System.out.println("Third execution:");
		//execService.execute(counter1);
		execService.execute(counter3);
		
		System.out.println("Forth execution:");
		//execService.execute(counter1);
		execService.execute(counter4);
		
		execService.shutdown();	
		
/*		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		/*while(true)
		{
			boolean isTerminated = execService.isTerminated();
			if(isTerminated)
			{
				System.out.println("Do 4th Task...");
				System.out.println("End of Main");
				break;
			}
		}
*/	
	}
}