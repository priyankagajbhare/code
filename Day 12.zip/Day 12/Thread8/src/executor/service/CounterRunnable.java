package executor.service;

public class CounterRunnable implements Runnable {
	private int counter = 0;
	private String objName;
	{
		System.out.println("Object created: CounterRunnable");
	}
	
	public CounterRunnable(String name){
		objName = name;
	}
	
	public int increAndGet(){
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return ++counter;
	}
		
	public void run(){
		Thread thisThread = Thread.currentThread();
		String threadName = thisThread.getName();
		for(int i=0; i<5; i++)
			System.out.println(objName+ "|"+threadName+": "+increAndGet());
		
		System.out.println("state of main thread: "+TestExecutorFramework.mainThread.getState());
	}
}
