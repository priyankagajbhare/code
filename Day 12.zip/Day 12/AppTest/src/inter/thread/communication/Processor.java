package inter.thread.communication;

import java.util.Scanner;

public class Processor {
	
	public void produce() throws InterruptedException{
		System.out.println("Produce started...");
		while(true)
		{
			synchronized (this) {
				System.out.println("Producing element...");
				System.out.println("Produer waiting...");
				//Thread.sleep(1000);
				//System.out.println("After 1 sec sleep...");
				wait();// it will release the lock and when notified, it will start from here below
				System.out.println("Producer resumed");
			}
		}		
	}
	public void consume() throws InterruptedException{
		System.out.println("Consume started....");
		Thread.sleep(100);
		while(true)
		{
			/*System.out.println("Please hit return button");
			Scanner scanner = new Scanner(System.in);
			scanner.nextLine();*/	
			synchronized (this) {					
				System.out.println("Consuming the element...");
				notify();// Notify should be ideally last line with in the Your synchronised block/method
				// as we see, wait cannot immediately Run if there lock is not released from with in the sync block
				//Thread.sleep(100);
			}
			Thread.sleep(200);
		}		
	}
}
