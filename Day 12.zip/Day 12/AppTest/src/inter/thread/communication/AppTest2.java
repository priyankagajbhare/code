package inter.thread.communication;

public class AppTest2 {
	public static void main(String[] args) {
		final Processor processor = new Processor();
		Thread t1 = new Thread(new Runnable() {
		
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		});
		Thread t2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				
			}
		});
		
		
	
	}
}
