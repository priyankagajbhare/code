package test;

class MyThread3 implements Runnable{
	@Override
	public void run() {   // Task will be performed
		String name = Thread.currentThread().getName();
		System.out.println("In run(): " + name);
		System.out.println("State of Main Thread after join(): "+Main4.mainThread.getState()); //------->> for calling the 

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Back in execution after sleep.");
		System.out.println("End of run.");
	}
}
public class Main4 {
	static Thread mainThread = null;
	public static void main(String[] args) {
		System.out.println("Start of main.");
		mainThread = Thread.currentThread();
		
		MyThread3 task = new MyThread3();
		Thread th1 = new Thread(task);  // worker
		System.out.println("State of ChildThread after creating thread object: "+th1.getState());
		th1.setName("Child Thread-1");
		th1.start();
		System.out.println("State of ChildThread after calling start(): "+th1.getState());

		try {
			th1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("State of ChildThread after join(): "+th1.getState());
		System.out.println("End of main.");
	}

}
