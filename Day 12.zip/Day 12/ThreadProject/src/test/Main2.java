package test;

class MyThread1 extends Thread {

	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		System.out.println("In run(): " + name);
	}
}

public class Main2 {
	public static void main(String[] args) {
		String name = Thread.currentThread().getName();
		System.out.println("In run(): " + name);
		
		MyThread1 th1 = new MyThread1();
		//th1.run();  ----------------->>> this is not correct method to call the run method
		th1.start(); // ------------->>> this is the correct method
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("End of the main.");
	}
}