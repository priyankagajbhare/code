package test;

class MyThread2 implements Runnable{
	@Override
	public void run() {   // Task will be performed
		String name = Thread.currentThread().getName();
		System.out.println("In run(): " + name);
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Back in execution after sleep.");
		System.out.println("End of run.");
	}
}
public class Main3 {
	public static void main(String[] args) {
		System.out.println("Sart of main.");
		MyThread2 task = new MyThread2();
		Thread th1 = new Thread(task);  // worker
		th1.setName("Child Thread-1");
		th1.start();
		
		try {
			th1.join(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("End of main.");
	}

}
