package test;

public class Main1 {
	public static void main(String[] args) {
		Thread th = Thread.currentThread();
		String name = th.getName();
		System.out.println("Currently executing thread is: " + name);

		run();

		System.out.println("End of main.");
	}

	private static void run() {
		String name = Thread.currentThread().getName();
		System.out.println("Thrad in run(): " + name);
	}

}
