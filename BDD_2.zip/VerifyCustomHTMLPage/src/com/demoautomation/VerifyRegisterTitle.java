package com.demoautomation;

import java.util.IllegalFormatException;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class VerifyRegisterTitle {
	WebDriver driver;
	String url = "D:\\Jayant\\BDD Testing\\test.html";
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
	}
	
	@Test
	public void verifyPhoneNumberLength() throws InterruptedException {
		driver.get(url);
		driver.findElement(By.id("phoneno")).sendKeys("123456789");
		String phoneNo = driver.findElement(By.id("phoneno")).getAttribute("value");
		if(phoneNo.length() == 10)
			Assert.assertTrue(true);
		else
		{
			System.out.println("Length of phone number entered:"+phoneNo.length());
			Assert.assertTrue(false);
		}
		
		System.out.println("Length of phone number entered:"+phoneNo.length());
	}
	
	@Test
	public void verifyPhoneNumberData() throws InterruptedException {
		driver.get(url);
		driver.findElement(By.id("phoneno")).sendKeys("12345678ab");
		String phoneNo = driver.findElement(By.id("phoneno")).getAttribute("value");
		boolean flag = false;
		try {
			Long.parseLong(phoneNo);
		}
		catch(NumberFormatException ex)
		{
			flag = true;
			System.out.println("Invalid Characters");
			Assert.assertTrue(false);
		}
		if(flag == false)
		{
			Assert.assertTrue(true);
		}

		System.out.println("Phone number entered:"+phoneNo);
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
}
