package com.scenariowithmap;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VerifyUsingMap {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate the valid url")
	public void navigate_the_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium jar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter the username{string}")
	public void enter_the_username(String username) {
	    driver.findElement(By.id("email")).sendKeys(username);
	}


	@Then("click the submit button")
	public void click_the_submit_button() {
		 driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter valid user details")
	public void enter_valid_user_details(DataTable datamaps) throws InterruptedException {
		for(Map<Object,Object> values: datamaps.asMaps(String.class, String.class)) {
		
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(values.get("Firstname").toString());
		//enter last name
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(values.get("Lastname").toString());
		//email address
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(values.get("EmailAddress").toString());
		//contact
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(values.get("PhoneNumber").toString());
		//password
		driver.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys(values.get("Password").toString());
		//confirm password
		driver.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys(values.get("ConfirmPassword").toString());
		}
		
	   
	}

	@Then("close our browser")
	public void close_our_browser() {
	  
	}



}
