package com.scenariowithlist;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.seleniumhq.jetty9.util.security.Credential;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VarifyUserDetailWithList {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate to valid url")
	public void navigate_to_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium jar\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	    
	}

	@Then("enter valid username")
	public void enter_valid_username(DataTable credential) {
		List<List<String>> data=credential.cells();
		driver.findElement(By.id("email")).sendKeys(data.get(0).get(0));
	    
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	    
	}

	@Then("enter user detail fields")
	public void enter_user_detail_fields(DataTable userDetails) throws InterruptedException {
		
		List<List<String>> userData=userDetails.cells();
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(userData.get(0).get(0));
		//enter last name
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(userData.get(0).get(1));
		//email address
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(userData.get(0).get(2));
		//contact
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(userData.get(0).get(3));
		
	   Thread.sleep(3000);
	}

	@Then("close browser")
	public void close_browser() {
	   driver.quit();
	}


}
