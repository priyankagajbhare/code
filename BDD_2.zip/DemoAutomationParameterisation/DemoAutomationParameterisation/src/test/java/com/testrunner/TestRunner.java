package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\resource\\mappingtestdata.feature"}, glue = {"com.scenariowithmap",},
			monochrome=true,
			dryRun=false,
			plugin= {"pretty","html:target/cucumber-html-report",
					"json:target/cucumber-json",
					"pretty:target/cucumber-pretty.txt",
					"usage:target/cucumber-usage-json",
					"junit:target/cucumber-junitresults.xml"
					
}
						

		     
		)
public class TestRunner {

}

/*@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\resource\\listwithtestdata.feature","src\\test\\java\\resource\\scenariowithoutline.feature"}, glue = {"com.scenariowithlist","com.scenariooutline"},
			monochrome=true,
			dryRun=false,
			plugin= {"pretty","html:target/cucumber-html-report",
					"json:target/cucumber-json",
					"pretty:target/cucumber-pretty.txt",
					"usage:target/cucumber-usage-json",
					"junit:target/cucumber-junitresults.xml"
					
}
						

		     
		)
public class TestRunner {

}*/
