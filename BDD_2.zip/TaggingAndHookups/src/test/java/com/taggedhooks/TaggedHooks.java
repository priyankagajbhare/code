package com.taggedhooks;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TaggedHooks {
	
	// Start of Global hooks
	
	@Before(order=0)
	public void setUp() {
		System.out.println("Launch the chrome browser - order=0");
		System.out.println("Enter the url - order=0");
	}
	
	@After(order=0)
	public void tearDown() {
		System.out.println("Close the browser - order=0");
	}
	
	@Before(order=1)
	public void setUp1() {
		System.out.println("Launch the chrome browser - order=1");
		System.out.println("Enter the url - order=1");
	}
	
	@After(order=1)
	public void tearDown1() {
		System.out.println("Close the browser - order=1");
	}
	
	// End of Global Hooks
	
	// Local hooks - 
	@Before("@first or @second")
	public void beforefirstOrSecondScenario() {
		System.out.println("Before first or second scenario");
	}
	
	@After({"@first and @second"})
	public void afterFirstAndSecondScenario() {
		System.out.println("After first and second scenario");
	}
	
	@Given("navigate through valid url")
	public void navigate_through_valid_url() {
		System.out.println("Enter valid url");
	}

	@Then("enter the user name")
	public void enter_the_user_name() {
		System.out.println("Enter user name");
	}

	@Then("click on submit")
	public void click_on_submit() {
		System.out.println("Click on submit");
	}

	@Given("post navigate to registry page verify page")
	public void post_navigate_to_registry_page_verify_page() {
		System.out.println("Navigate to registry page");
	}

	@Then("enter all the mandatory values")
	public void enter_all_the_mandatory_values() {
		System.out.println("Enter all mandatory values");
	}

	@Given("enter new user details")
	public void enter_new_user_details() {
		System.out.println("Enter new user details");
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		System.out.println("Click on submit button");
	}
}
