package com.tagging;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;

public class TaggingTest {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("This is valid login")
	public void this_is_valid_login() {
	}

	@Given("This is invalid login")
	public void this_is_invalid_login() {
	}

	@Given("I logged in using skip sign in button")
	public void i_logged_in_using_skip_sign_in_button() {
	}

	@Given("make registry with all the fields")
	public void make_registry_with_all_the_fields() {
	}

	@Given("make registry with mandatory values")
	public void make_registry_with_mandatory_values() {
	}

	@Given("verify webtable page open")
	public void verify_webtable_page_open() {
	}

	@Given("verify we are at switch to tab")
	public void verify_we_are_at_switch_to_tab() {
	}

	@Given("verify widget tab")
	public void verify_widget_tab() {
	}

	@Given("verify interaction tab is open")
	public void verify_interaction_tab_is_open() {
	}

	@Given("verify video tab is open")
	public void verify_video_tab_is_open() {
	}

	@Given("verify wysiwyg")
	public void verify_wysiwyg() {
	}

	@Given("verify more")
	public void verify_more() {
	}

	@Given("verify practice site")
	public void verify_practice_site() {
	}
}
