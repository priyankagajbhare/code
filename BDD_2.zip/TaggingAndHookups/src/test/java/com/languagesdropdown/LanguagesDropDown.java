package com.languagesdropdown;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LanguagesDropDown {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate through valid url")
	public void navigate_through_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter the user name")
	public void enter_the_user_name() {
		driver.findElement(By.id("email")).sendKeys("ijk@gmail.com");
	}

	@Then("click on submit")
	public void click_on_submit() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("click on language drop down box")
	public void click_on_language_drop_down_box() throws InterruptedException {
		driver.findElement(By.id("msdd")).click();
		Thread.sleep(1000);
	}

	@Then("select a language")
	public void select_a_language() throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='Czech']")).click();
		Thread.sleep(1000);
	}

	@Then("select another language")
	public void select_another_language() throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='English']")).click();
		Thread.sleep(1000);
	}
	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
}
