package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
/*
@CucumberOptions(features = {"src\\test\\java\\resource\\tagging.feature"},
						glue = {"com.tagging"},
						monochrome = true,
						dryRun = false,
						tags = {"@SmokeTest"}
						
						// And Condition
						//tags = {"@SmokeTest", "@RegressionTest"}
						//tags = {"@SmokeTest and @RegressionTest"}
						// OR Condition
						// tags = {"@SmokeTest, @RegressionTest"}
						//tags = {"@SmokeTest or @RegressionTest"}

						// ignore some of the cases
						//tags = {"~@SmokeTest"}
						//tags = {"not @SmokeTest"}

				)
*/
/*
@CucumberOptions(features = {"src\\test\\java\\resource\\hooks.feature"},
						glue = {"com.hooks"},
						monochrome = true,
						dryRun = false
				)
*/
/*
@CucumberOptions(features = {"src\\test\\java\\resource\\taggedhooks.feature"},
						glue = {"com.taggedhooks"},
						monochrome = true,
						dryRun = false
				)
*/

@CucumberOptions(features = {"src\\test\\java\\resource\\languages.feature"},
						glue = {"com.languagesdropdown"},
						monochrome = true,
						dryRun = false
				)

public class TestRunner {

}