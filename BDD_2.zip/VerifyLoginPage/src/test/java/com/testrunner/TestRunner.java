package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
//@CucumberOptions(features = "featurefile", glue="", monochrome=true)
@CucumberOptions(features = "featurefile\\googlesearchtextbox.feature", glue="com.googlesearchtextbox"
			,monochrome=true, dryRun=true)


// Gives Null pointer exception due to 2 driver instances of different classes
//@CucumberOptions(features = "featurefile\\googlesearchpage.feature", glue="com.googlesearch"
//,monochrome=true, dryRun=false)
public class TestRunner {

}
