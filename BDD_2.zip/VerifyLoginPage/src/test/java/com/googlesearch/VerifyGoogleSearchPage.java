package com.googlesearch;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class VerifyGoogleSearchPage {

	WebDriver driver;
	String url = "https://www.google.com/";
	
	@Given("launch chrome browser")
	public void launch_chrome_browser() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
	}

	@When("open google home page")
	public void open_google_home_page() {
		driver.get(url);
	}

	@Then("verify search text box is present")
	public void verify_search_text_box_is_present() {
		boolean result1 = driver.findElement(By.xpath("//input[@title='Search']")).isDisplayed();
		if(result1)
			System.out.println("Search Text Box is present");
		else
			System.out.println("Search Text Box is not present");
		
		//driver.findElement(By.xpath("//input[@title='Search']")).sendKeys("Mantu Kumar");
	}

	@Then("verify google search button is present")
	public void verify_google_search_button_is_present() {
		boolean result2 = driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).isDisplayed();
		if(result2)
			System.out.println("Search Button is present");
		else
			System.out.println("Search Button is not present");
		//driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).click();
	}

	@Then("verify I am feeling lucky button is present")
	public void verify_I_am_feeling_lucky_button_is_present() {
		boolean result3 = driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value=\"I'm Feeling Lucky\"]")).isDisplayed();
		if(result3)
			System.out.println("I am feeling lucky button is present");
		else
			System.out.println("I am feeling lucky button is not present");
	}

	@Then("close the chrome browser")
	public void close_the_chrome_browser() {
		driver.quit();
	}
	
	
}
