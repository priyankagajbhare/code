package com.googlesearch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;

public class VerifyGoogleSearchPageTextBox {
	WebDriver driver1;
	
	@Then("search for the value {string}")
	public void search_for_the_value(String string) {
		driver1.findElement(By.xpath("//input[@title='Search']")).sendKeys(string);
	}
	
	@Then("click on search button")
	public void click_on_search_button() {
		driver1.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).click();
	}
}
