package com.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class LoginTest {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	@Given("navigate through valid url")
	public void navigate_through_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		
		driver.get(url);
	}

	@Then("enter the valid username")
	public void enter_the_valid_username() {
		driver.findElement(By.id("email")).sendKeys("ijk@gmail.com");
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		driver.findElement(By.id("enterimg")).click();
		
	}

	@Then("verify login successful")
	public void verify_login_successful() throws InterruptedException {
		String expectedResult = "Register";
		String actualResult = driver.findElement(By.xpath("//h2[text()='Register']")).getText();
		if(actualResult.equals(expectedResult))
			System.out.println("We are at welcome page");
		else
			System.out.println("Unable to login");
		Thread.sleep(2000);
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}

	@Then("click on skip sign in")
	public void click_on_skip_sign_in() {
		driver.findElement(By.id("btn2")).click();
	}

	@Then("verify title of the page")
	public void verify_title_of_the_page() throws InterruptedException {
		String expectedResult = "Register";
		String actualResult = driver.getTitle();
		
		Assert.assertEquals("Title not verified",expectedResult, actualResult);
		if(actualResult.equals(expectedResult))
			System.out.println("Title verified");
		else
			System.out.println("Title not verified");
		Thread.sleep(2000);
	}
}
