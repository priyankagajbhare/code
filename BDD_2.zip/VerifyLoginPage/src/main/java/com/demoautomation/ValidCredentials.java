package com.demoautomation;

/**
 * Hello world!
 *
 */
public class ValidCredentials 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
