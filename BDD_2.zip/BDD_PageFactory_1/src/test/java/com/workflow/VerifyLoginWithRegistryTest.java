package com.workflow;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.applicationobjects.LoginPageAO;
import com.applicationobjects.RegisterPageAO;
import com.library.LoginPageInitialization;
import com.library.RegisterPageInitialization;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class VerifyLoginWithRegistryTest {
	
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";
	
	LoginPageAO loginPageAO;
	RegisterPageAO registerPageAO;
	
	@Given("login with valid url")
	public void login_with_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter valid username")
	public void enter_valid_username() {
		//driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
		// loginPageAO = new LoginPageAO(driver);
		// loginPageAO.getText_Loginpage_UserName().sendKeys("abc@gmail.com");
	
		System.out.println("Writing into pagefactory - username");
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		// driver.findElement(By.id("enterimg")).click();
		// loginPageAO = new LoginPageAO(driver);
		// loginPageAO.getText_LoginPage_Submit().click();
		
		System.out.println("Writing into pagefactory - click button");
	}

	@Then("verify welcome page")
	public void verify_welcome_page() {
		LoginPageInitialization loginPageInitialization = PageFactory.initElements(driver, LoginPageInitialization.class);
		
		loginPageInitialization.loginWithValidCredentials("abc@gmail.com");
		
		String expectedTitle = "Register";
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title not matched", expectedTitle, actualTitle);
		
		
		System.out.println("Title : "+actualTitle);
	}

	@Then("enter firstname of user")
	public void enter_firstname_of_user() throws InterruptedException {
		//driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Mantuuu");
		//registerPageAO = new RegisterPageAO(driver);
		//registerPageAO.getText_Registerpage_FirstName().sendKeys("Mantuuu");
RegisterPageInitialization registerPageInitialization = PageFactory.initElements(driver, RegisterPageInitialization.class);
		
		registerPageInitialization.fillForm("Mantuuu", "Kumaiir");
		Thread.sleep(2000);
	}

	@Then("enter lastname of user")
	public void enter_lastname_of_user() {
		//driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Kumaiir");
		//registerPageAO = new RegisterPageAO(driver);
		//registerPageAO.getText_Registerpage_FirstName().sendKeys("Kumaiir");
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
}
