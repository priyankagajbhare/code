package com.applicationobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterPageAO {
	WebDriver driver;
	
	public RegisterPageAO(WebDriver driver) {
		this.driver = driver;
	}
	
	// first name
	By firstName = By.xpath("//input[@placeholder='First Name']");
	public WebElement getText_Registerpage_FirstName() {
		return driver.findElement(firstName);
	}
	
	// last name
	By lastName = By.xpath("//input[@placeholder='Last Name']");
	public WebElement getText_RegisterPage_LastName() {
		return driver.findElement(lastName); 
	}
}
