package com.library;

import org.openqa.selenium.WebDriver;

import com.applicationobjects.RegisterPageAO;

public class RegisterPageInitialization extends RegisterPageAO {
	
	public RegisterPageInitialization(WebDriver driver) {
		super(driver);
	}
	
	public void fillForm(String firstName, String lastName) {
		getText_Registerpage_FirstName().sendKeys(firstName);
		getText_RegisterPage_LastName().sendKeys(lastName);
	}
}
