package com.library;

import org.openqa.selenium.WebDriver;

import com.applicationobjects.LoginPageAO;

public class LoginPageInitialization extends LoginPageAO {

	public LoginPageInitialization(WebDriver driver) {
		super(driver);
	}
	
	public void loginWithValidCredentials(String userName) {
		getText_Loginpage_UserName().sendKeys(userName);
		getButton_LoginPage_Submit().click();
	}
	
}
