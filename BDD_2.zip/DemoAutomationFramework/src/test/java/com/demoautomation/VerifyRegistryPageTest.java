package com.demoautomation;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.applicationobjects.LoginPage;
import com.applicationobjects.RegisterPage;
import com.commonvariables.ApplicationConstant;
import com.library.ConfigPropertyReader;
import com.setup.Base;
import com.teardown.Teardown;

public class VerifyRegistryPageTest {
	
	private final static Properties configProperties;
	static {
		configProperties = ConfigPropertyReader.loadPropertiesFromReader("/resource/config.properties");
	}
	
	WebDriver driver;
	String verificationErrors = "";
	Base base = new Base();
	
	@Test
	public void verifyRegisterTitle() throws InterruptedException {
		String expectedTitle = "Register";
		//driver.get(url);
		driver = base.getBrowserLaunch();
		driver.get(configProperties.getProperty("URL"));
		driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.id("enterimg")).click();
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title matched", expectedTitle, actualTitle);
		System.out.println("Title of the application: "+actualTitle);
	}
	
	@Test
	public void verifySkipSignInButton() 
	{
		driver = base.getBrowserLaunch();
		driver.get(configProperties.getProperty("URL"));
		
		// Verify skip Sign in and click
		if(driver.findElement(By.id("btn2")).isDisplayed())
			driver.findElement(By.id("btn2")).click();
		
		// Verify Automation Demo Site text is present
		String expectedText = "Automation";
		String actualText = driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).getText();
		if(actualText.contains(expectedText))
		//if(driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).isDisplayed())
			System.out.println("We are at register page");
		else
			System.out.println("Register page not present");
		
		
		// Verify Radio Button
		boolean result = driver.findElement(By.xpath("//input[@value='FeMale']")).isDisplayed();
		if(result)
			System.out.println("Radio option FeMale present in page");
		else
			System.out.println("Radio option FeMale not present in page");
	}
	
	@Test
	public void fillFormWithMandatoryValuesAndVerifyWebTableTitle() throws InterruptedException
	{
		driver = base.getBrowserLaunch();
		driver.get(configProperties.getProperty("URL"));

		Teardown teardown = new Teardown(driver);
		
		LoginPage loginPage = new LoginPage(driver);
		RegisterPage registerPage = new RegisterPage(driver);
		ApplicationConstant applicationConstant = new ApplicationConstant();
		try {
		
		loginPage.getText_loginPage_UserName().sendKeys(applicationConstant.userName);
		
		loginPage.getButton_loginPage_Submit().click();
		/*
		// Verify skip Sign in and click
		if(driver.findElement(By.id("btn2")).isDisplayed())
			driver.findElement(By.id("btn2")).click();
		*/
		
		// Enter First Name
		registerPage.getText_Register_FirstName().sendKeys(applicationConstant.firstName);
		// Enter Last Name
		registerPage.getText_Register_LastName().sendKeys(applicationConstant.lastName);
		// Enter Email
		registerPage.getText_Register_EmailAddress().sendKeys(applicationConstant.emailAddress);
		registerPage.getText_Register_Telephone().sendKeys(applicationConstant.phoneNumber);
		//driver.findElement(By.name("radiooptions")).sendKeys("Male");
		registerPage.getRadioButton_Register_Male().click();
		
		// Select country
		registerPage.getDropdown_Register_Country().click();
		//driver.findElement(By.id("countries")).sendKeys("India");
		//driver.findElement(By.xpath("//select[@id='countries']//option[@value='India']")).click();;
		//WebElement country = driver.findElement(By.id("countries"));
		//country.findElement(By.xpath("//option[@value='India']")).click();
		
		registerPage.getDropdown_Register_Year().click();
		registerPage.getDropdown_Register_Month().click();
		//WebElement month = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		//month.findElement(By.xpath("//option[@value='June']")).click();
		
		registerPage.getDropdown_Register_Day().click();
		
		registerPage.getText_Register_Password().sendKeys(applicationConstant.password);
		registerPage.getText_Register_ConfirmPassword().sendKeys(applicationConstant.confirmPassword);
		
		registerPage.getButton_Register_SubmitRegisterPage().click();
		Thread.sleep(3000);
		/*
		if(driver.getTitle().equals("Web Table"))
			System.out.println("Form filled successfully");
		else
			System.out.println("Failed "+driver.getTitle());
		*/
		String expectedTitle = "Web Table";;
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title not matched", expectedTitle, actualTitle);
		System.out.println("Title matched.. Title of the application: "+actualTitle);
		}
		catch(Exception ex)
		{
			verificationErrors = ex.getMessage();
			System.out.println("Failed because of "+verificationErrors);
		}
		finally {
			teardown.getCloseBrowser(verificationErrors);
			//teardown.getCloseBrowser("");
		}
	}
}
