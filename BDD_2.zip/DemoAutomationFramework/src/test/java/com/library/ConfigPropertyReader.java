package com.library;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigPropertyReader {
	public static Properties loadPropertiesFromReader(String fileName) {
		Properties properties = null;
		InputStream inputStream = ClassLoader.class.getResourceAsStream(fileName);
		properties = new Properties();
		try {
			properties.load(inputStream);
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
		return properties;
	}
}
