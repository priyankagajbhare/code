package com.setup;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.library.ConfigPropertyReader;

public class Base {
	
	private final static Properties configProperties;
	static {
		configProperties = ConfigPropertyReader.loadPropertiesFromReader("/resource/config.properties");
	}
	
	WebDriver driver;
	
	public WebDriver getBrowserLaunch()
	{
		System.setProperty(configProperties.getProperty("DRIVER"),configProperties.getProperty("DRIVERPATH"));
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		return driver;
	}
}
