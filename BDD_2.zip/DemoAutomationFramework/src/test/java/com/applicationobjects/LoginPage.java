package com.applicationobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public WebElement getText_loginPage_UserName() {
		return driver.findElement(By.id("email"));
	}

	public WebElement getButton_loginPage_Submit() {
		return driver.findElement(By.id("enterimg"));
	}

	public WebElement getButton_loginPage_SkipSignIn() {
		return driver.findElement(By.id("btn2"));
	}
}
