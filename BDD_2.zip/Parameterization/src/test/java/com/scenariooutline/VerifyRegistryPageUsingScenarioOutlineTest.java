package com.scenariooutline;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class VerifyRegistryPageUsingScenarioOutlineTest 
{
	WebDriver driver;
	String url="http://demo.automationtesting.in/Index.html";
	
	@Given("navigate to demoautomation site")
	public void navigate_to_demoautomation_site() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter username {string}")
	public void enter_username(String username) {
		driver.findElement(By.id("email")).sendKeys(username);
	}

	@Then("click on submit button")
	public void click_on_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter firstname {string} field")
	public void enter_firstname_field(String firstname) {
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(firstname);
	}

	@Then("enter lastname {string}")
	public void enter_lastname(String lastname) {
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastname);
	}

	@Then("enter address {string} of the user")
	public void enter_address_of_the_user(String address) throws InterruptedException {
		driver.findElement(By.xpath("//textarea")).sendKeys(address);
		Thread.sleep(1500);
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
}
