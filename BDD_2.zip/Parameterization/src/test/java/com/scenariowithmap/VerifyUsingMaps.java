package com.scenariowithmap;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VerifyUsingMaps {
	WebDriver driver;
	String url = "http://demo.automationtesting.in/Index.html";

	@Given("navigate to valid url")
	public void navigate_to_valid_url() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@Then("enter the {string}")
	public void enter_the(String userName) {
		driver.findElement(By.id("email")).sendKeys(userName);
	}

	@Then("click on the submit button")
	public void click_on_the_submit_button() {
		driver.findElement(By.id("enterimg")).click();
	}

	@Then("enter valid user details")
	public void enter_valid_user_details(DataTable dataMaps) throws InterruptedException {
		for (Map<Object, Object> values : dataMaps.asMaps(String.class, String.class)) { // (keys, data)
			driver.findElement(By.xpath("//input[@placeholder='First Name']"))
					.sendKeys(values.get("FirstName").toString());
			driver.findElement(By.xpath("//input[@placeholder='Last Name']"))
					.sendKeys(values.get("LastName").toString());
			driver.findElement(By.xpath("//input[@type='email']")).sendKeys(values.get("EmailAddress").toString());
			driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(values.get("PhoneNumber").toString());
			driver.findElement(By.id("firstpassword")).sendKeys(values.get("Password").toString());
			driver.findElement(By.id("secondpassword")).sendKeys(values.get("ConfirmPassword").toString());
			driver.findElement(By.id("Button1")).click();
			Thread.sleep(2000);
		}
	}

	@Then("closed the browser")
	public void closed_the_browser() {
		driver.quit();
	}
/*
	@Then("open a new browser")
	public void open_a_new_browser() {
		driver.get(url);
	}
	*/
}
