package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
/*
@CucumberOptions(features = "src\\test\\java\\resource\\scenariowithexamplekeyword.feature", glue="",
monochrome=true, dryRun = false, plugin= {"pretty", "html:target/cucumber-html-report",
										"json:target/cucumber-json",
										"pretty:target/cucumber-pretty.txt",
										"usage:target/cucumber-usage.json",
										"junit:target/cucumber-junitresults.xml"
										})
*/
/*
@CucumberOptions(features = "src\\test\\java\\resource\\listwithtestdata.feature", glue="com.scenariowithlist",
monochrome=true, dryRun = false, plugin= {"pretty", "html:target/cucumber-html-report",
										"json:target/cucumber-json",
										"pretty:target/cucumber-pretty.txt",
										"usage:target/cucumber-usage.json",
										"junit:target/cucumber-junitresults.xml"
										})
*/

@CucumberOptions(features = "src\\test\\java\\resource\\mapwithtestdata.feature", glue="com.scenariowithmap",
monochrome=true, dryRun = false, plugin= {"pretty", "html:target/cucumber-html-report",
										"json:target/cucumber-json",
										"pretty:target/cucumber-pretty.txt",
										"usage:target/cucumber-usage.json",
										"junit:target/cucumber-junitresults.xml"
										},
										strict = true)
// if strict is true then it will fail the execution if there are pending step definitions
// if strict is false then it will run and give true and suggest to add pending step definitions

public class TestRunner {

}
