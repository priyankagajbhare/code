package com.demoautomation;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyAlert {
	public WebDriver driver;
	public String url = "";
	public String verificationError = "";

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		url = "http://demo.automationtesting.in/Index.html";
	}

	@Test
	public void verifyAcceptAlert() {
		try {
			driver.get(url);

			driver.findElement(By.id("email")).sendKeys("saikiran@gmail.com");

			driver.findElement(By.id("enterimg")).click();

			Thread.sleep(500);

			driver.findElement(By.xpath("//li[@class='dropdown']/a[text()='SwitchTo']")).click();
			Thread.sleep(500);

			driver.findElement(By.xpath("//a[text()='Alerts']")).click();

			driver.findElement(By.xpath("//button[contains(text(),'click the button to display an  alert box')]"))
					.click();

			Alert alert = driver.switchTo().alert();
			Thread.sleep(500);

			System.out.println(alert.getText());

			alert.accept();
			Thread.sleep(500);

			if (driver.findElements(By.xpath("//button[contains(text(),'click the button to display an  alert box')]"))
					.size() > 0) {
				System.out.println("We are on main window");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			verificationError = ex.getMessage();
		}
	}

	@After
	public void tierDown() {
		driver.quit();
		String catchError = verificationError.toString();
		if (catchError != "")
			Assert.fail(catchError);
	}
}
