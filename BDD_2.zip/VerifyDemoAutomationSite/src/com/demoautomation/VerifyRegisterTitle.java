package com.demoautomation;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class VerifyRegisterTitle {
	WebDriver driver;
	String url = "";
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Max 30 seconds, if object created before that, it will go forward
		// Will work for each driver.findElement
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		url = "http://demo.automationtesting.in/Index.html";
	}
	
	@Test
	public void verifyRegisterTitle() throws InterruptedException {
		String expectedTitle = "Register";
		driver.get(url);
		driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.id("enterimg")).click();
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title matched", expectedTitle, actualTitle);
		System.out.println("Title of the application: "+actualTitle);
	}
	
	@Test
	public void verifySkipSignInButton() 
	{
		driver.get(url);
		
		// Verify skip Sign in and click
		if(driver.findElement(By.id("btn2")).isDisplayed())
			driver.findElement(By.id("btn2")).click();
		
		// Verify Automation Demo Site text is present
		String expectedText = "Automation";
		String actualText = driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).getText();
		if(actualText.contains(expectedText))
		//if(driver.findElement(By.xpath("//h1[text()='Automation Demo Site ']")).isDisplayed())
			System.out.println("We are at register page");
		else
			System.out.println("Register page not present");
		
		
		// Verify Radio Button
		boolean result = driver.findElement(By.xpath("//input[@value='FeMale']")).isDisplayed();
		if(result)
			System.out.println("Radio option FeMale present in page");
		else
			System.out.println("Radio option FeMale not present in page");
	}
	
	@Test
	public void fillFormWithMandatoryValuesAndVerifyWebTableTitle() throws InterruptedException
	{
		try {
		driver.get(url);
		
		// Verify skip Sign in and click
		if(driver.findElement(By.id("btn2")).isDisplayed())
			driver.findElement(By.id("btn2")).click();
		
		// Enter First Name
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Mantuuu");
		// Enter Last Name
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Kumaiir");
		// Enter Email
		
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("mantu123@gmail.com");
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys("9012356789");
		//driver.findElement(By.name("radiooptions")).sendKeys("Male");
		driver.findElement(By.xpath("//input[@value='Male']")).click();
		
		// Select country
		driver.findElement(By.xpath("//option[@value='India']")).click();
		//driver.findElement(By.id("countries")).sendKeys("India");
		//driver.findElement(By.xpath("//select[@id='countries']//option[@value='India']")).click();;
		//WebElement country = driver.findElement(By.id("countries"));
		//country.findElement(By.xpath("//option[@value='India']")).click();
		
		driver.findElement(By.id("yearbox")).sendKeys("1993");
		driver.findElement(By.xpath("//select[@placeholder='Month']")).sendKeys("June");
		//WebElement month = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		//month.findElement(By.xpath("//option[@value='June']")).click();
		
		driver.findElement(By.id("daybox")).sendKeys("25");
		driver.findElement(By.id("firstpassword")).sendKeys("Abcd@12345");
		driver.findElement(By.id("secondpassword")).sendKeys("Abcd@12345");
		
		driver.findElement(By.id("submitbtn")).click();
		Thread.sleep(4000);
		/*
		if(driver.getTitle().equals("Web Table"))
			System.out.println("Form filled successfully");
		else
			System.out.println("Failed "+driver.getTitle());
		*/
		String expectedTitle = "Web Table";;
		String actualTitle = driver.getTitle();
		Assert.assertEquals("title matched", expectedTitle, actualTitle);
		System.out.println("Title of the application: "+actualTitle);
		}
		catch(Exception ex)
		{
			String verificationErrors = ex.getMessage();
			System.out.println("Failed because of "+verificationErrors);
		}
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
