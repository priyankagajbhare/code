package test;

interface I1{
	abstract public void show1();
}
interface I2{
	abstract public void show2();
}

abstract class X implements I1, I2{
	@Override
	public void show1(){
		System.out.println("show1() of class X");
	}
	
} 
class Y extends X{
	@Override
	public void show2(){
		System.out.println("show2() of class Y");
	}
}
public class Test {
	public static void main(String[] args) {
	I1 ref1 = new Y();
	I2 ref2 = new Y();
	ref1.show1();
	ref2.show2();
	}
}
