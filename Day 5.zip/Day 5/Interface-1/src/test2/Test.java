package test2;

interface I1{
	public void meth1();
}
interface I2{
	public void meth2();
}
interface I3 extends I1, I2{
	public void meth3();
}
class A implements I3{

	@Override
	public void meth1() {
		System.out.println("meth1");
	}

	@Override
	public void meth2() {
		System.out.println("meth2");
	}

	@Override
	public void meth3() {
		System.out.println("meth3");
	}
	public void methA() {
		System.out.println("methA");
	}
	
}
public class Test {
	public static void main(String[] args) {
		I3 ref = new A();
		ref.meth1();
		ref.meth2();
		ref.meth3();
	}
}
