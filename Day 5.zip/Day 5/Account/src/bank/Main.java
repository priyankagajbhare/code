package bank;

public class Main {
	public static void main(String[] args) {
		Account accObj = new Account(5000);
		Customer custObj = new Customer("Shubham", "Holey");
		custObj.setAccount(accObj);
		
		System.out.println("Cust Details Are: ");
		System.out.println("First Name: "+custObj.getfirstName());
		System.out.println("Last Name: "+custObj.getlastName());
		System.out.println("Balance: "+custObj.getAccount().getBalance());
		
	}

}
