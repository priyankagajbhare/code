package org.client;

import org.bank.Account;
import org.bank.Current;
import org.bank.Saving;

public class Main4 {
	public static void main(String[] args) {

		 double random = Math.random();
		System.out.println("Random Number: "+random);
		
		int randomInt = (int)(random * 4);
		System.out.println("Random Int: "+randomInt);
		
		System.out.println("using if-else");
		if(random > 0.5)
		{
			System.out.println("Head");
		}
		else
		{
			System.out.println("Tail"); 
		}
		
		System.out.println("\n"); 

		System.out.println("using ternary operators");
		String coin = (random > 0.5) ? "Head" : "Tail";
		System.out.println(coin);

	}

}
