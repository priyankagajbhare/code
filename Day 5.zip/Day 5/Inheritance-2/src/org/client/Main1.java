package org.client;

import org.bank.Account;
import org.bank.Current;
import org.bank.Saving;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Account acc = new Account(); -------------->>> can't initiate
		Account acc;
		
		acc = new Saving(1000001, "Shubham", 14000.0, 5.7);
		acc.display();
		
		acc = new Current(1000002, "Ankit", 2562166.0, 1000);
		acc.display();
	}

}
