package org.client;

import org.bank.Account;
import org.bank.Current;
import org.bank.Saving;

public class Main5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account accounts[] = new Account[4];
		
		Saving s1 = new Saving(100001, "Shubham", 40000, 4.9);
		Current c1 = new Current(100002, "Ankit", 50000, 2000);
		Saving s2 = new Saving(100003, "Shubham1", 6000, 4.9);
		Current c2 = new Current(100004, "Ankit2", 80000, 2000);
		
		accounts[0] = (Math.random() > 0.5) ? s1 : c1;
		accounts[1] = (Math.random() > 0.5) ? s1 : c1;
		accounts[2] = (Math.random() > 0.5) ? s1 : c1;
		accounts[3] = (Math.random() > 0.5) ? s1 : c1;
		
		for(Account acc: accounts)
		{
			if(acc instanceof Saving)
			{
				System.out.println("\n----Saving Account Details----");
			}
			else if(acc instanceof Current)
			{
				System.out.println("\n----Current Account Details----");
			}
		
			acc.display();
		}
	}

}
