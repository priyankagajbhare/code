package org.client;

public class Main2 {
	public static void main(String[] args) {
		int arr[] = new int[5];
		arr[0] = 100;
		arr[1] = 99;
		arr[2] = 103;
		arr[3] = 204;
		arr[4] = 16;
		
		//arr[5] = -1;
		
		System.out.println("Contetnts from array using traditional for loop");
		for(int i=0; i<5; i++)
		{
			System.out.print(arr[i]+" ");
		}
		
		System.out.print("\n\n");

		System.out.println("Contetnts from array using advance for loop");
		for(int n : arr)
		{
			System.out.print(n+" ");
		}
	}
}
