package org.bank;

public class Saving extends Account {
	private double roi;
	
	public Saving(int accountNumber, String accountHolder, double accountBalance, double roi)
	{
		super(accountNumber, accountHolder, accountBalance);
		this.roi = roi;
	}
	public Saving()
	{
		
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Acount Number: "+super.getAccountNumber());
		System.out.println("Account Holder Name: "+super.getAccountHolder());
		System.out.println("Account Balance: "+super.getAccountBalance());
		System.out.println("Rate of interest: "+this.roi);
	}

}
