package org.bank;

public class Current extends Account 
{
	private double overDraft;
	
	public Current(int accountNumber, String accountHolder, double accountBalance, double overDraft)
	{
		super(accountNumber, accountHolder, accountBalance);
		this.overDraft = overDraft;
	}
	public Current()
	{
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Acount Number: "+super.getAccountNumber());
		System.out.println("Account Holder Name: "+super.getAccountHolder());
		System.out.println("Account Balance: "+super.getAccountBalance());
		System.out.println("Over Draft: "+this.overDraft);
	}
	
}
