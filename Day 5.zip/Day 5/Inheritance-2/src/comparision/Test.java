package comparision;

public class Test {
	 public static void main(String[] args) {
		String password = "cap@123";
		String confirmPassword1 = "cap@123";
		String confirmPassword2 = new "cap@123";

	}

}
