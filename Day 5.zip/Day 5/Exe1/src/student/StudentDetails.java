package student;

import java.util.Scanner;

public class StudentDetails {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Student[] st = new Student[5];
		st[0] = new Student(100, "Shubham", 1023456789, "Python", 14000);
		st[1] = new Student(101, "Aman", 874561230, "Java", 25000);
		st[2] = new Student(102, "Karan", 698521470, "C++", 5000);
		st[3] = new Student(103, "Talha", 210654987, "Ruby", 12000);
		st[4] = new Student(104, "Kedar", 539846120, "Java", 25000);
		
		System.out.println("Select the Course:");
		Scanner sc = new Scanner(System.in);
		String ch = sc.nextLine();
		
		for(int i=0; i<5; i++)
		{
			if(ch.equalsIgnoreCase(st[i].getCourse()));
				{
					st[i].display();
					
				}
			
		}sc.close();
	}

}
