package student;

public class Student 
{
	private int studentId;
	private String name;
	private int contactNo;
	private String course;
	private double fees;
	
	public Student(int studentId, String name, int contactNo, String course, double fees)
	{
		this.studentId = studentId;
		this.name = name;
		this.contactNo = contactNo;
		this.course = course;
		this.fees = fees;
	}
	
	
	public void display()
	{
		System.out.println("\nStudent Details");
		System.out.println("Id: "+studentId);
		System.out.println("Name: "+name);
		System.out.println("Contact: "+contactNo);
		System.out.println("Course Taken: "+course);
		System.out.println("Fees: "+fees);
	}


	public String getCourse() {
		return course;
	}


	public double getFees() {
		return fees;
	}


}
