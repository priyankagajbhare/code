package test3;
class Shape{
	public double area(int radius){
		final float PI = 3.1F;
		double areaCircle = PI * radius * radius;
		return areaCircle;
	}
	public long area(int l, int b){
		long areaRect = l * b;
		return areaRect;
	}
}
public class OverloadingTest {
	public static void main(String[] args) {
		Shape shape = new Shape();
		double area1 = shape.area(5);
		System.out.println("Area of Circle = "+area1);
		
		long area2 = shape.area(10,20);
		System.out.println("Area of Rect = "+area2);

	}

}
