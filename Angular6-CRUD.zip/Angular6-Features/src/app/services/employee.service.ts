import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  getEmployees():any[]{
    return [
      {
        code:'emp101',
        name:'rashmi',
        gender:'female',
        annualSalary:'4000',
        dateOfBirth:'5/17/1985'
      },
      {
        code:'emp102',
        name:'parth',
        gender:'male',
        annualSalary:'4000',
        dateOfBirth:'8/23/1983'
      }
    ]
  }
  constructor() { }
}
