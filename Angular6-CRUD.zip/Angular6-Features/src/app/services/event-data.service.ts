import { Injectable } from '@angular/core';
import { MyEvent } from '../viewmodel/myevent';

@Injectable({
  providedIn: 'root'
})

export class EventDataService {
  events: MyEvent[] = [
    {
      id:101,
      name:'Angular',
      description:'Angular Event',
      speaker:'Rashmi Pawaskar',
      },
    {
      id:102,
      name:'Java',
      description:'Java Event',
      speaker:'Mantu Kumar',
    }
  ]
  getEvents():MyEvent[]{  // return type is optional
    return this.events;
  }

  putEvent(event1: MyEvent)
  {
      event1.id = this.events.length + 1+  100;
      this.events.push(event1);
  }

  deleteEvent(event1: MyEvent)
  {
    let result = confirm("Do you really want to delete "+ event1.name);
    if(result)
    {
      let index = this.events.indexOf(event1);
      return this.events.splice(index, 1);
    }
  }
  constructor() { }
}
