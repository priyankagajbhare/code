import { Injectable } from '@angular/core';
import { Users } from '../viewmodel/users';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  //usersList: Array<Users>[];
  usersList: Users[];
  baseUrl = "/assets/users.json";
  obj: Observable<Users[]>;


  //Method 1: Directly sending JSON data to component (Working)
  
   constructor(private http:HttpClient) {
   }

   getUsers()
   {
     return this.http.get<Users[]>(this.baseUrl);
   }

  /*
  // Get Users By Id
  getUsersById(id: number) {
    return this.http.get<Users>(this.baseUrl + "/" + id);
  }
*/

  //Method 2: Putting JSON data into services array first and then sending that array to component array (Not Working)
  //constructor(private http:HttpClient) {
  //}
/*
  ngOnInit() {
    this.obj = this.http.get<Users[]>(this.baseUrl);
    this.obj.subscribe(data => {
      this.usersList = data;
    });
  }
  */
 /*
  getUsers()
  {
    
    return this.usersList;
  }
  */


//Method 3: Mam's method
/*
  ngOnInit() {
    this.http.get<Users[]>(this.baseUrl).subscribe(data => {
      this.usersList = data;
    });
  }
*/
  
/*
  getUsersFromJson()
  {
    return this.http.get<Users[]>(this.baseUrl);
  }

  getUsers()
  {
    return this.usersList;
  }
/*
  getUsers()
  {
    this.obj = this.http.get<Users[]>(this.baseUrl);
    this.obj.subscribe(data => {
      this.usersList = data;
    });
      return this.usersList;
  }

getUsers()
  {
      return this.http.get<Users[]>(this.baseUrl);
  }
  */
}
