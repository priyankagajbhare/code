import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JsonwithhttpclientComponent } from './jsonwithhttpclient.component';

describe('JsonwithhttpclientComponent', () => {
  let component: JsonwithhttpclientComponent;
  let fixture: ComponentFixture<JsonwithhttpclientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JsonwithhttpclientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JsonwithhttpclientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
