import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Users } from '../viewmodel/users';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { routerNgProbeToken } from '@angular/router/src/router_module';


@Component({
  selector: 'app-jsonwithhttpclient',
  templateUrl: './jsonwithhttpclient.component.html',
  styleUrls: ['./jsonwithhttpclient.component.css']
})
export class JsonwithhttpclientComponent implements OnInit {
  editForm: FormGroup;
  users: Users[];
  userData: Users;
  editUser1: Users;
  userIdIndex: number;
  showEditForm: Boolean;
  showUpdatedTable: Boolean;
  index: number;
  constructor(private _users:UserService, private router:Router, private formBuilder: FormBuilder) { }

   // Method 1: Directly Recieving JSON data and assigning it to array using subscribe method

   ngOnInit() {
     this._users.getUsers().subscribe(data => {
       this.users = data;
     });
   }
  
  addUser(form)
  {
    form.value.id = this.users.length + 1;
    this.users.push(form.value);
    
  }

  deleteUser(user:Users)
  {
    let result = confirm("Do you really want to delete "+ user.firstName + user.lastName);
    if(result)
    {
      let index = this.users.indexOf(user);
      return this.users.splice(index, 1);
    }
  }


editUser(user:Users) {
  this.editUser1 = user;
   this.showEditForm = true;
   this.index = this.users.indexOf(user);
  }

  updateUser(form)
  {
    this.update(form.value);
  }
  update(user1:Users){
    console.log("property index"+this.index);
      user1.id = this.index+1;
      this.users[this.index] = user1;
      console.log(this.users);
      this.showEditForm = false;
      this.router.navigate(['']);
  }

}