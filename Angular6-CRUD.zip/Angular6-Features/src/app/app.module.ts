﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';

import { EmployeeTitlePipe } from './employee-title.pipe';

import { Routes, RouterModule} from '@angular/router';

import { FormsModule, ReactiveFormsModule} from '@angular/forms';

import { JsonwithhttpclientComponent } from './jsonwithhttpclient/jsonwithhttpclient.component';
import { HttpClientModule } from '@angular/common/http';;
import { EditformComponent } from './editform/editform.component'

const appRoutes: Routes = [
    { path : '', component: JsonwithhttpclientComponent}
]

@NgModule({
    imports: [
        BrowserModule,
        RouterModule.forRoot(appRoutes),
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule
    ],
    declarations: [
        AppComponent,
        JsonwithhttpclientComponent,
        EditformComponent],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }