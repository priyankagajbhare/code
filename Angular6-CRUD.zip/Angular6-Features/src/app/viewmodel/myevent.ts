export class MyEvent
{
    id: number;
    name: string;
    description: string;
    speaker: string;

}