export class Users {
    id: number;
    firstName: string;
    lastName: string;
    email: string
}