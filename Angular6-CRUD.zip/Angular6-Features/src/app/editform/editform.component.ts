import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editform',
  templateUrl: './editform.component.html',
  styleUrls: ['./editform.component.css']
})
export class EditformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
