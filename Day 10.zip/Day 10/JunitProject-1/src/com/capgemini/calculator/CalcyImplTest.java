package com.capgemini.calculator;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalcyImplTest {
	private CalcyImpl calcy;
	@Before
	public void setUp() {
		calcy = new CalcyImpl();
	}
	@After
	public void tearDown() {
		calcy = null;
	}
	@Test
	public void testAddShouldReturnSumOfTwoNumbers() throws IllegalParameterException {
		int result = calcy.add(1000,2000);
		assertEquals(3000, result);
	}
	@Test(expected = IllegalParameterException.class)
	public void testAddShouldThrowIllegalParameterExceptionForNegativeInput() throws IllegalParameterException {
		calcy.add(-1000,-2000);
		fail("expecting IllegalParameterException");
	}

	@Test
	public void testSubShouldReturnSubtractionOfTwoNumbers() throws IllegalParameterException {
		int result = calcy.sub(2000,1000);
		assertEquals(1000, result);
	}
	@Test(expected = IllegalParameterException.class)
	public void testSubShouldThrowIllegalParameterExceptionForNegativeInput() throws IllegalParameterException {
		calcy.sub(-1000,-2000);
		fail("expecting IllegalParameterException");

	}


}
