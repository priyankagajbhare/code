package com.capgemini.calculator;

public interface Calcy {
	public int add(int n1, int n2)throws IllegalParameterException;
	public int sub(int n1, int n2)throws IllegalParameterException;
}
