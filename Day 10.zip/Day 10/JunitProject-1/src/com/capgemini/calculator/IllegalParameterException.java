package com.capgemini.calculator;

public class IllegalParameterException extends Exception {

	public IllegalParameterException(String string) {
		super(string);
	}

}
