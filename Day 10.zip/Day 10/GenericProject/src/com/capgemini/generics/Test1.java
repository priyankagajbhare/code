package com.capgemini.generics;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class Test1 {
	public static void main(String[] args) {
		LinkedHashSet<Integer> set = new LinkedHashSet<Integer>();
		// set.add("10");-------------->>>>>>>>> error, to overcome this error refer the below line
		// set.add(Integer.parseInt("10"));
		set.add(1000);
		set.add(5000);

		Iterator<Integer> itr = set.iterator();
		while (itr.hasNext()) {
			// Integer product = (Integer)(itr.next()) * 2;
			int product = itr.next() * 2;
			System.out.println(product);
		}

	}

}
