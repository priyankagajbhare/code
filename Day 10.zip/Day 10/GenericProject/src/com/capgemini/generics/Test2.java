package com.capgemini.generics;

public class Test2<T> {
	public void print(T ref) {
		System.out.println(ref.toString());
	}
	public static void main(String[] args) {
		Test2<Integer> obj1 = new  Test2<>();
		obj1.print(1000);
		
		Test2<String> obj2 = new Test2<> ();
		obj2.print("Capgemini Pune");
	}

}
