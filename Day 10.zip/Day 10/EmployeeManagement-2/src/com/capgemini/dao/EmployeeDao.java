package com.capgemini.dao;

import com.capgemini.dto.Employee;

public interface EmployeeDao {
	public boolean createEmployee(Employee emp);
	public Employee readEmployee(int empId);
	public boolean updateEmployeeSalary(int empId, double updatedSalay);
	public boolean deleteEmployee(int empId);
}