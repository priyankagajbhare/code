package com.capgemini.Emp.ui;

import java.util.Scanner;
import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.dto.Employee;

public class EmpMain {
	public static Scanner sc;
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		EmployeeDao employee = new EmployeeDaoImpl();
		while(true) {
			System.out.println("1. Add Employee Details");
			System.out.println("2. View All Employees");
			System.out.println("3. Delete Employee Details.");
			System.out.println("4. View Salary Slip");
			System.out.println("5. Exit.");
			
			System.out.println("Enter Your Choice:");
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1: 	
				System.out.println("Enter empId: ");
				int id = sc.nextInt();
				System.out.println("Enter empName: ");
				String name = sc.next();
				System.out.println("Enter empSalary: ");
				double salary = sc.nextDouble();
		
		
						
			}
			
		
		
		}
		
	}
	
}
