package com.capgemini.serviceEmployee;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao dao = new EmployeeDaoImpl();
	@Override
	public boolean addEmployee(Employee emp) {
		boolean result = dao.createEmployee(emp);
		return false;
	}

	@Override
	public Employee viewEmployee(int empId) {
		return null;
	}

	@Override
	public boolean incrementEmployeeSalary(int empId, double updatedSalay) {
		return false;
	}

	@Override
	public boolean removeEmployee(int empId) {
		return false;
	}

}
