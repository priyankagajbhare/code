package com.capgemini.serviceEmployee;

import com.capgemini.dto.Employee;

public interface EmployeeService {
	public boolean addEmployee(Employee emp);
	public Employee viewEmployee(int empId);
	public boolean incrementEmployeeSalary(int empId, double updatedSalay);
	public boolean removeEmployee(int empId);
}
